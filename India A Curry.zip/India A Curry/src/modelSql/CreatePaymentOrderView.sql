/**
 * 入金画面用ビュー
 * 　注文コード、注文日時、顧客名、請求金額を持つ
 * Author:  20jz0105
 * Created: 2022/01/15
 */

CREATE OR REPLACE VIEW payment_order_view
AS SELECT o.order_code, o.order_date, c.telephone_no, c.name, c.customer_type, o.usage_reward, 
   (
    SELECT NVL(SUM((NVL(ph.price, p.price) + NVL(s.price, 0)) * od.quantity), 0)
    FROM order_details od
    JOIN products p ON od.product_no = p.product_no
    LEFT JOIN sizes s ON od.size_no = s.size_no
    LEFT JOIN product_histories ph ON EXISTS (SELECT 0
                                              FROM product_histories
                                              WHERE ph.product_no = product_no AND record_date > o.order_date
                                              HAVING ph.record_date = MIN(record_date)) AND p.product_No = ph.product_no
    WHERE od.cancel_type = 0 AND o.order_code = od.order_code
   ) AS total_amount
   FROM orders o
   JOIN customers c ON o.customer_no = c.customer_no
   WHERE o.cancel_type = 0;


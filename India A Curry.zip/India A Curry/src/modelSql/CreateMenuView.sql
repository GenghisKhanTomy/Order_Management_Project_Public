/**
 * メニュー用ビュー
 * Author:  20jz0105
 * Created: 2021/11/22
 */
CREATE OR REPLACE VIEW menu_view
AS SELECT p.product_no || NVL2(s.size_no, '-', '') || s.size_no AS product_no, p.name || s.name AS product_name, p.price + NVL(s.price, 0) AS price, p.type_name
   FROM products p
   LEFT JOIN sizes s ON p.type_name IN ('主食', 'セット') 
   WHERE SYSDATE >= p.sales_start_date AND (SYSDATE <= p.sales_end_date OR p.sales_end_date IS NULL);


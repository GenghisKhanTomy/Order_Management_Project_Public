/**
 * 注文伝票ビュー
 * Author:  20jz0105
 * Created: 2021/12/23
 */

CREATE OR REPLACE VIEW order_voucher_view
AS SELECT o.order_code, od.order_detail_code, o.order_date, o.usage_reward, o.address, c.name AS customer_name, c.telephone_no, c.reward, c.customer_type, od.quantity, od.note,
          p.product_no || NVL2(s.size_no, '-' || s.size_no, '') AS product_no, NVL(ph.name, p.name) || s.name AS product_name, NVL(ph.price, p.price) + NVL(s.price, 0) AS price, p.type_name, NVL(sp.reward_magnification, 1) AS reward_magnification
   FROM orders o
   JOIN customers c ON o.customer_no = c.customer_no
   JOIN order_details od ON o.order_code = od.order_code
   JOIN products p ON od.product_no = p.product_no
   LEFT JOIN sizes s ON od.size_no = s.size_no
   LEFT JOIN special_products sp ON p.product_no = sp.product_no AND SYSDATE BETWEEN sp.special_start_date AND sp.special_end_date
   LEFT JOIN product_histories ph ON EXISTS (SELECT 0
                                             FROM product_histories
                                             WHERE ph.product_no = product_no AND record_date > o.order_date
                                             HAVING ph.record_date = MIN(record_date)) AND p.product_No = ph.product_no
   WHERE o.cancel_type = 0 AND od.cancel_type = 0;


/**
 * サマリーテーブルと、未集計の注文情報の集計結果を返す
 * サマリーに入るのは営業時間内の注文のみ
 * Author:  20jz0105
 * Created: 2022/01/25
 */

CREATE OR REPLACE VIEW sales_summary_related_view
AS SELECT NVL(s.group_date, i.group_date) AS group_date, NVL(s.price, i.price) AS price, NVL(s.days, i.days) AS days,
          NVL(s.year, i.year) AS year, NVL(s.month, i.month) AS month, NVL(s.day, i.day) AS day, NVL(s.hour, i.hour) AS hour
   FROM sales_summary s
   FULL JOIN  (
       SELECT TRUNC(o.order_date, 'HH24') AS group_date, NVL(SUM(((p.price + NVL(s.price, 0)) * od.quantity) * 1.08), 0) AS price, TO_CHAR(order_date, 'DY') AS days,
              TO_NUMBER(TO_CHAR(o.order_date, 'YYYY')) AS year, TO_NUMBER(TO_CHAR(o.order_date, 'MM')) AS month,
              TO_NUMBER(TO_CHAR(o.order_date, 'DD')) AS day, TO_NUMBER(TO_CHAR(o.order_date, 'HH24')) AS hour
       FROM orders o
       JOIN order_details od ON o.order_code = od.order_code
       JOIN products p ON od.product_no = p.product_no
       LEFT JOIN sizes s ON od.size_no = s.size_no
       WHERE o.cancel_type = 0 AND od.cancel_type = 0 AND TRUNC(SYSDATE, 'DD') < o.order_date
       GROUP BY TRUNC(o.order_date, 'HH24'), TO_CHAR(o.order_date, 'DY'), TO_NUMBER(TO_CHAR(o.order_date, 'YYYY')), TO_NUMBER(TO_CHAR(o.order_date, 'MM')), TO_NUMBER(TO_CHAR(o.order_date, 'DD')), TO_NUMBER(TO_CHAR(o.order_date, 'HH24'))
       HAVING NVL(SUM((p.price + NVL(s.price, 0)) * 1.08 * od.quantity), 0) IS NOT NULL
   ) i ON s.group_date = i.group_date
  WHERE NVL(s.hour, i.hour) BETWEEN 10 AND 22

CREATE OR REPLACE VIEW sales_summary_related_view
AS SELECT NVL(s.group_date, i.group_date) AS group_date, NVL(s.price, i.price) AS price, NVL(s.days, i.days) AS days,
          NVL(s.year, i.year) AS year, NVL(s.month, i.month) AS month, NVL(s.day, i.day) AS day, NVL(s.hour, i.hour) AS hour
   FROM sales_summary s
   FULL JOIN  (
       SELECT TRUNC(o.order_date, 'HH24') AS group_date, NVL(SUM(((p.price + NVL(s.price, 0)) * od.quantity) * 1.08), 0) AS price, TO_CHAR(order_date, 'DY') AS days,
              TO_NUMBER(TO_CHAR(o.order_date, 'YYYY')) AS year, TO_NUMBER(TO_CHAR(o.order_date, 'MM')) AS month,
              TO_NUMBER(TO_CHAR(o.order_date, 'DD')) AS day, TO_NUMBER(TO_CHAR(o.order_date, 'HH24')) AS hour
       FROM orders o
       JOIN order_details od ON o.order_code = od.order_code
       JOIN products p ON od.product_no = p.product_no
       LEFT JOIN sizes s ON od.size_no = s.size_no
       WHERE o.cancel_type = 0 AND od.cancel_type = 0 AND TRUNC(SYSDATE, 'DD') < o.order_date AND o.payment_date IS NOT NULL
       GROUP BY TRUNC(o.order_date, 'HH24'), TO_CHAR(o.order_date, 'DY'), TO_NUMBER(TO_CHAR(o.order_date, 'YYYY')), TO_NUMBER(TO_CHAR(o.order_date, 'MM')), TO_NUMBER(TO_CHAR(o.order_date, 'DD')), TO_NUMBER(TO_CHAR(o.order_date, 'HH24'))
       HAVING NVL(SUM((p.price + NVL(s.price, 0)) * 1.08 * od.quantity), 0) IS NOT NULL
   ) i ON s.group_date = i.group_date
  WHERE NVL(s.hour, i.hour) BETWEEN 10 AND 22


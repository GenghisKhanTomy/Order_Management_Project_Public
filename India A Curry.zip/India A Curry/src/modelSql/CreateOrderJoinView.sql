/**
 * 注文状態結合ビュー
 * Author:  20jz0105
 * Created: 2022/01/02
 */
CREATE OR REPLACE VIEW order_join_view
AS SELECT o.order_code, o.order_date, os.cooking_start_date, os.cooking_end_date, os.delivery_start_date, os.delivery_end_date, o.payment_date
   FROM orders o
   JOIN order_status os ON o.order_code = os.order_code
   WHERE o.cancel_type = 0

/**
 * 請求書ビュー
 * 　請求書を作成するのは法人顧客に限る
 * 　法人顧客のためポイントは考慮しない
 * 3000円以上の注文は送料無料
 * 送料は300円
 * Author:  20jz0105
 * Created: 2022/01/17
 */
CREATE OR REPLACE VIEW invoice_view
AS SELECT c.customer_no, c.telephone_no, c.name, ADD_MONTHS(TRUNC(i.order_date, 'MM'), 1) AS billing_date,
   SUM((CASE WHEN i.total_cost >= 3000 THEN i.total_cost ELSE i.total_cost + 300 END)) AS total_finaly_cost
   FROM (
     SELECT o.order_code, o.order_date, o.customer_no, NVL(SUM(TRUNC((NVL(ph.price, p.price) + NVL(s.price, 0)) * 1.08) * od.quantity), 0) AS total_cost
     FROM orders o
     JOIN order_details od ON o.order_code = od.order_code
     JOIN products p ON od.product_no = p.product_no
     LEFT JOIN sizes s ON od.size_no = s.size_no
     LEFT JOIN product_histories ph ON EXISTS (SELECT 0
                                               FROM product_histories
                                               WHERE ph.product_no = product_no AND record_date > o.order_date
                                               HAVING ph.record_date = MIN(record_date)) AND p.product_No = ph.product_no
     WHERE o.cancel_type = 0 AND od.cancel_type = 0 AND o.order_code = od.order_code AND o.payment_date IS NULL AND TRUNC(o.order_date, 'MM') < TRUNC(SYSDATE, 'MM')
     GROUP BY o.order_code, o.order_date, o.customer_no
    ) i
   JOIN customers c ON c.customer_no = i.customer_no
   WHERE c.customer_type = 0
   GROUP BY c.customer_no, c.telephone_no, c.name, ADD_MONTHS(TRUNC(i.order_date, 'MM'), 1)
   ORDER BY ADD_MONTHS(TRUNC(i.order_date, 'MM'), 1);
/**
 * Author:  20jz0105
 * Created: 2022/01/29
 */
CREATE OR REPLACE VIEW order_list_view
AS SELECT o.order_code, o.order_date, o.cooking_start_date, o.cooking_end_date, o.delivery_start_date, o.delivery_end_date, o.payment_date, p.telephone_no,  p.name, p.customer_type, p.usage_reward, p.total_amount
   FROM order_join_view o
   JOIN payment_order_view p ON o.order_code = p.order_code
/**
 * 注文状態テーブルへのINSERTは注文コードのみ可能とするトリガー
 * Author:  20jz0105
 * Created: 2021/12/13
 */
CREATE OR REPLACE TRIGGER insert_order_status_trigger
  BEFORE
  INSERT
  ON order_status
  FOR EACH ROW
BEGIN
  IF :NEW.cooking_start_date IS NOT NULL OR :NEW.cooking_end_date IS NOT NULL OR :NEW.delivery_start_date IS NOT NULL OR :NEW.delivery_end_date IS NOT NULL THEN
    RAISE_APPLICATION_ERROR(-20000, 'エラー:このテーブルは注文コードのみ挿入できます');
  END IF;
END;
/
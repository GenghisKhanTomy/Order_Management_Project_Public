/**
 * 商品明細が更新・削除される場合、商品明細履歴に該当行を挿入する
 * Author:  20jz0105
 * Created: 2021/12/19
 */
CREATE OR REPLACE TRIGGER upd_del_product_detail_trigger
  AFTER 
  UPDATE OR DELETE
  ON product_details
  FOR EACH ROW
BEGIN
  INSERT INTO product_detail_histories
  VALUES(:OLD.product_no, :OLD.product_detail_no, SYSDATE, :OLD.quantity);
END;
/

-- CREATE OR REPLACE TRIGGER upd_del_product_details_trigger
--   AFTER 
--   UPDATE OR DELETE
--   ON product_details
--   FOR EACH ROW
-- BEGIN
--   INSERT INTO product_details_histories
--   VALUES(:OLD.product_no, :OLD.product_detail_no, SYSDATE, :OLD.quantity);
-- END;
-- /
-- 

/**
 * 注文明細が全てキャンセルになったら注文そのものもキャンセルするトリガー
 *   自己参照を行うために複合型トリガーとする
 * Author:  20jz0105
 * Created: 2022/01/15
 */
CREATE OR REPLACE TRIGGER update_order_details_trigger
  FOR UPDATE ON order_details
  COMPOUND TRIGGER
  t_cnt NUMBER := -1;
  t_order_code NUMBER := -1;
  t_cancel_type NUMBER := 0;

  AFTER EACH ROW IS
  BEGIN
    IF :NEW.cancel_type != 0 THEN
      t_order_code := :NEW.order_code;
      t_cancel_type := :NEW.cancel_type;
    END IF;
  END AFTER EACH ROW;

  AFTER STATEMENT IS
  BEGIN
    IF t_cancel_type != 0 AND t_order_code >= 0 THEN
      SELECT COUNT(*) INTO t_cnt FROM order_details WHERE order_code = t_order_code AND cancel_type = 0; 
      IF t_cnt = 0 THEN
        UPDATE orders SET cancel_type = 1 WHERE order_code = t_order_code AND cancel_type = 0;
      END IF;
    END IF;
  END AFTER STATEMENT;

END update_order_details_trigger;
/

  

/**
 * 没となったトリガー
 * 理由：AFTERトリガーの実行タイミングはコミット前なので自律型では更新した値を参照できないため
 */
/**
 * 注文明細が全てキャンセルになったら注文そのものもキャンセルするトリガー
 *   自己参照を行うために自律型トリガーとする
 *   PRAGMA AUTONOMOUS_TRANSACTION;で自律型トランザクションの宣言
 * Author:  20jz0105
 * Created: 2022/01/02
 */
-- CREATE OR REPLACE TRIGGER update_order_details_trigger
--   AFTER
--   UPDATE
--   ON order_details
--   FOR EACH ROW
-- DECLARE
--   PRAGMA AUTONOMOUS_TRANSACTION;
--   cnt NUMBER;
-- BEGIN
--   IF :NEW.cancel_type != 0 THEN
--     SELECT COUNT(*) INTO cnt FROM order_details WHERE order_code = :NEW.order_code AND cancel_type = 0;
--     IF cnt = 0 THEN
--       UPDATE orders SET cancel_type = 1 WHERE order_code = :NEW.order_code;
--       COMMIT;
--     END IF;
--   END IF;
-- END;
-- /
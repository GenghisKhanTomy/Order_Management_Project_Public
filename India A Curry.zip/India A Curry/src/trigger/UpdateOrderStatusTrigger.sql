/**
 * 注文状態テーブルの更新の際に、現在の状態が正しいか判定する
 * 一度に複数列の更新はさせない
 * Author:  20jz0105
 * Created: 2021/12/13
 */
CREATE OR REPLACE TRIGGER update_order_status_trigger
  BEFORE
  UPDATE
  ON order_status
  FOR EACH ROW
DECLARE
  cnt NUMBER;
  errflag NUMBER := 1;
BEGIN
  SELECT COUNT(*) INTO cnt FROM orders WHERE order_code = :NEW.order_code AND payment_date IS NULL AND cancel_type = 0;--未入金かつ、取り消されていない注文の取得
  IF cnt = 1 THEN --主キーで検索しているため、数は0か1になる
    IF :OLD.cooking_start_date IS NULL AND :NEW.cooking_end_date IS NULL AND :NEW.delivery_start_date IS NULL AND :NEW.delivery_end_date IS NULL THEN
      errflag := 0;
    ELSIF :NEW.cooking_start_date IS NOT NULL AND :OLD.cooking_end_date IS NULL AND :NEW.delivery_start_date IS NULL AND :NEW.delivery_end_date IS NULL THEN
      IF :OLD.cooking_start_date = :NEW.cooking_start_date OR :NEW.cooking_end_date IS NULL THEN
        errflag := 0;
      END IF;
    ELSIF :NEW.cooking_start_date IS NOT NULL AND :NEW.cooking_end_date IS NOT NULL AND :OLD.delivery_start_date IS NULL AND :NEW.delivery_end_date IS NULL THEN
      IF :OLD.cooking_start_date = :NEW.cooking_start_date AND (:OLD.cooking_end_date = :NEW.cooking_end_date OR :NEW.delivery_start_date IS NULL) THEN
        errflag := 0;
      END IF;
    ELSIF :NEW.cooking_start_date IS NOT NULL AND :NEW.cooking_end_date IS NOT NULL AND :NEW.delivery_start_date IS NOT NULL AND :OLD.delivery_end_date IS NULL THEN
      IF :OLD.cooking_start_date = :NEW.cooking_start_date AND :OLD.cooking_end_date = :NEW.cooking_end_date AND (:OLD.delivery_start_date = :NEW.delivery_start_date OR :NEW.delivery_end_date IS NULL) THEN
        errflag := 0;
      END IF;
    ELSIF :NEW.cooking_start_date IS NOT NULL AND :NEW.cooking_end_date IS NOT NULL AND :NEW.delivery_start_date IS NOT NULL AND :OLD.delivery_end_date IS NOT NULL THEN
      IF :OLD.cooking_start_date = :NEW.cooking_start_date AND :OLD.cooking_end_date = :NEW.cooking_end_date AND :OLD.delivery_start_date = :NEW.delivery_start_date THEN
        errflag := 0;
      END IF;
    END IF;

    IF errflag != 0 THEN
      RAISE_APPLICATION_ERROR(-20000, 'エラー:一度に複数の列を更新できません');
    END IF;
  ELSE
    RAISE_APPLICATION_ERROR(-20000, 'エラー:その注文状態は更新できません');
  END IF;
END;
/


-- CREATE OR REPLACE TRIGGER trigger_update_order_status
--  BEFORE
--  UPDATE
--  ON order_status
--  FOR EACH ROW
-- DECLARE
--   cnt NUMBER;
-- BEGIN
--   IF :OLD.cooking_start_date <> :NEW.cooking_start_date OR :OLD.cooking_start_date IS NULL THEN
--     IF :NEW.cooking_end_date IS NOT NULL THEN
--       RAISE_APPLICATION_ERROR(-20000, 'エラー:状態が正しくありません');
--     END IF;
--   ELSIF :OLD.cooking_end_date <> :NEW.cooking_end_date THEN
--     IF :NEW.cooking_start_date IS NULL OR :NEW.delivery_start_date IS NOT NULL THEN
--       RAISE_APPLICATION_ERROR(-20000, 'エラー発生');
--     END IF;
--   ELSIF :OLD.delivery_start_date <> :NEW.delivery_start_date THEN
--     IF :NEW.cooking_end_date IS NULL OR :NEW.delivery_end_date IS NOT NULL THEN
--       RAISE_APPLICATION_ERROR(-20000, 'エラー発生');
--     END IF;
--   ELSIF :OLD.delivery_end_date <> :NEW.delivery_end_date THEN
--     IF :NEW.cooking_start_date IS NULL THEN
--       RAISE_APPLICATION_ERROR(-20000, 'エラー発生');
--     ELSE
--       SELECT COUNT(*) INTO cnt FROM orders WHERE order_code = :NEW.order_code AND payment_date IS NOT NULL;
--       IF cnt = 1 THEN
--         RAISE_APPLICATION_ERROR(-20000, 'エラー発生');
--       END IF;
--     END IF;
--   END IF;
-- END;
-- /


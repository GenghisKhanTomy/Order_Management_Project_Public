/**
 * 入金されたら自動的にポイントを加算するトリガー
 * 未完成・未使用
 * Author:  20jz0105
 * Created: 2022/02/16
 */
-- CREATE OR REPLACE TRIGGER update_customer_reward_trigger
--   AFTER 
--   UPDATE
--   ON orders
--   FOR EACH ROW
-- BEGIN
--   IF :OLD.payment_date IS NULL AND :NEW.payment_date IS NOT NULL THEN
--     UPDATE customers
--     SET reward = reward + (SELECT SUM(reward_magnification))
--     VALUES(:OLD.product_no, SYSDATE, :OLD.name, :OLD.type_name, :OLD.price, :OLD.sales_start_date, :OLD.sales_end_date, :OLD.set_type);
--   END IF;
-- END;
-- /
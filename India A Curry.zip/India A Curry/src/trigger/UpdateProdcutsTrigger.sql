/**
 * トリガー定義
 * productテーブルの販売終了年月日列、販売開始していない販売開始年月日が更新される場合を除き、productテーブルが更新・削除される際に、自動的にprodcut_historyテーブルに更新前データを挿入する
 * Author:  20jz0105
 * Created: 2021/12/19
 */
CREATE OR REPLACE TRIGGER update_products_trigger
  AFTER 
  UPDATE
  ON products
  FOR EACH ROW
BEGIN
  INSERT INTO product_histories
  VALUES(:OLD.product_no, SYSDATE, :OLD.name, :OLD.type_name, :OLD.price, :OLD.sales_start_date, :OLD.sales_end_date, :OLD.set_type);
END;
/

-- CREATE OR REPLACE TRIGGER update_delete_products_trigger
--   AFTER 
--   UPDATE OR DELETE
--   ON products
--   FOR EACH ROW
-- DECLARE
--   flag NUMBER := 0;
-- BEGIN
--   IF updating THEN
--     IF :OLD.product_no != :NEW.product_no OR :OLD.name != :NEW.name OR :OLD.type_name != :NEW.type_name OR :OLD.price != :NEW.price OR :OLD.set_type != :NEW.set_type OR :OLD.sales_start_date <= SYSDATE AND :OLD.sales_start_date != :NEW.sales_start_date THEN
--       flag := 1;
--     END IF;
--   ELSE
--     flag := 1;
--   END IF;
-- 
--   IF flag = 1 THEN
--     INSERT INTO product_histories
--     VALUES(:OLD.product_no, SYSDATE, :OLD.name, :OLD.type_name, :OLD.price, :OLD.sales_start_date, :OLD.sales_end_date, :OLD.set_type);
--   END IF;
-- END;
-- /


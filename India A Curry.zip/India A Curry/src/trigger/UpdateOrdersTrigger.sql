/**
 * 注文がキャンセルされたら、自動的に該当注文の注文明細もキャンセルするトリガー
 * 　注文明細側のトリガーで注文テーブルが参照されるため、複合型トリガーにする
 * Author:  20jz0105
 * Created: 2022/01/15
 */
CREATE OR REPLACE TRIGGER update_order_trigger
  FOR UPDATE ON orders
  COMPOUND TRIGGER
  t_order_code NUMBER := -1;
  t_cancel_type NUMBER := 0;

  AFTER EACH ROW IS
  BEGIN
    IF :NEW.cancel_type != 0 THEN
      t_order_code := :NEW.order_code;
      t_cancel_type := :NEW.cancel_type;
    END IF;
  END AFTER EACH ROW;

  AFTER STATEMENT IS
  BEGIN
    IF t_cancel_type != 0 AND t_order_code >= 0 THEN
      UPDATE order_details SET cancel_type = 1 WHERE order_code = t_order_code AND cancel_type = 0;
    END IF;
  END AFTER STATEMENT;

END update_order_trigger;
/

/**
 * 没となったトリガー
 */
/**
 * 注文がキャンセルされたら、自動的に該当注文の注文明細もキャンセルするトリガー
 * Author:  20jz0105
 * Created: 2022/01/02
 */
CREATE OR REPLACE TRIGGER update_order_trigger
  AFTER
  UPDATE
  ON orders
  FOR EACH ROW
BEGIN
  IF :NEW.cancel_type != 0 THEN
    UPDATE order_details SET cancel_type = 1 WHERE order_code = :NEW.order_code AND cancel_type = 0;
  END IF;
END;
/

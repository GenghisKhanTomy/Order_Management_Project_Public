/**
 * トリガー定義
 * orderテーブルに行が挿入されると自動的にorder_statusテーブルにも挿入する
 * Author:  20jz0105
 * Created: 2021/12/09
 */
CREATE OR REPLACE TRIGGER insert_order_trigger
  AFTER 
  INSERT
  ON orders
  FOR EACH ROW
BEGIN
  INSERT INTO order_status(order_code) VALUES(:NEW.order_code);
END;
/



/*トリガー定義 テスト用
CREATE OR REPLACE TRIGGER testTrigger
 AFTER 
 INSERT
 ON test
 FOR EACH ROW
BEGIN
 INSERT INTO test2 VALUES(:NEW.id);
END;
*/
/*トリガー解説
CREATE OR REPLACE TRIGGER testTrigger //作成又は上書き　この名前で作成
 AFTER       //対象のデータベースが更新された後に実行　BEFOREなら更新前　INSTEAD OFは更新をせずにトリガーのみ実行する
 INSERT     //INSERT処理による更新で実行　UPDATE、DELETEも選択でき、複数の場合は OR で区切る
 ON test    //対象テーブル
 FOR EACH ROW       //1行単位で更新されるたびに実行　これがないと1文単位になる
BEGIN   //プログラム開始
                                    //PL/SQLを記述する
 INSERT INTO test2 VALUES(:NEW.id); //test2テーブルにtestテーブルへの更新後データ（testテーブルに挿入されたデータ)のid列のデータ）を挿入　更新後は:NEW、更新前は:OLDで参照できる
                                    //基本的にSQL文は記述できる
                                    //IF文もかける　例: IF INSERTING THEN 　インサート処理であればtrue、条件式には :NEW.id = 10 などの数値比較もできる ちなみにブロック構成はif, [elsif, else], end　ifである
END;    //プログラム終了
*/

/*PL/SQLメモ
show errorでコンパイルエラーは出せる
*/
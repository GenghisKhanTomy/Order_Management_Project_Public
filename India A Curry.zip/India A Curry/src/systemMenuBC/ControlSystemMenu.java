package systemMenuBC;

import DAO.CustomerDAO;
import aggregateBC.ControlAggregate;
import editEmployeeBC.ControlEditEmployee;
import editProductBC.ControlEditProduct;
import employeeListBC.ControlEmployeeList;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.util.List;
import loginBC.ControlLogin;
import model.Customer;
import model.Employee;
import orderListBC.ControlOrderList;
import registerEmployeeBC.ControlRegisterEmployee;
import registerOrderBC.ControlRegisterOrder;
import registerProductBC.ControlRegisterProduct;
import registerSpecialProductBC.ControlRegisterSpecialProduct;
import registerindCorpCustomerBC.ControlCorpCustomer;
import orderStatusBC.ControlOrderStatus;
import paymentBC.ControlPayment;
import productListBC.ControlProductList;

/**
 *システム全体へのハブ画面.
 * 【注意】importやフィールド、コンストラクタの設定、起動メソッドの作成は各種機能単位で完成してから実装して下さい。
 * 【手順】
 *  ①import, フィールド、コンストラクタの設定
 *  ②関数名 awaken(+機能名)を作成する
 * @author とよA
 */
public class ControlSystemMenu {
    private ControlEditEmployee controlEditEmployee;
    private ControlEditProduct controlEditProduct;
    private ControlRegisterEmployee controlRegisterEmployee;
    private ControlRegisterOrder controlRegisterOrder;
    private ControlRegisterProduct controlRegisterProduct;
    private ControlRegisterSpecialProduct contorolRegisterSpecialProduct;
    private ControlCorpCustomer controlCorpCustomer;
    private ControlOrderStatus controlOrderStatus;
    private ControlPayment controlPayment;
    private ControlAggregate controlAggregate;
    private ControlOrderList controlOrderList;
    private ControlEmployeeList controlEmployeeList;
    private ControlProductList controlProductList;
    private BoundarySystemMenu boundarySystemMenu;
    
    private ControlLogin controlLogin;
    private CustomerDAO customerDAO;
    private Employee employee;

    public ControlSystemMenu() {        
        controlEditEmployee = new ControlEditEmployee();
        controlEditProduct = new ControlEditProduct();
        controlRegisterEmployee = new ControlRegisterEmployee();
        controlRegisterOrder = new ControlRegisterOrder();
        controlRegisterProduct = new ControlRegisterProduct();
        contorolRegisterSpecialProduct = new ControlRegisterSpecialProduct();
        controlCorpCustomer = new ControlCorpCustomer();
        controlOrderStatus = new ControlOrderStatus();
        controlPayment = new ControlPayment();
        controlAggregate = new ControlAggregate();
        controlOrderList = new ControlOrderList();
        controlEmployeeList = new ControlEmployeeList();
        controlProductList = new ControlProductList();
        boundarySystemMenu = new BoundarySystemMenu();
        
        customerDAO = new CustomerDAO();
    }

    public void setControlLogin(ControlLogin controlLogin) {
        this.controlLogin = controlLogin;
    }
        
    public void setEmployee(Employee employee) {
        this.employee = employee;
        boundarySystemMenu.showEmployee(employee);
        controlRegisterOrder.setEmployee(employee);
        controlOrderStatus.setEmployee(employee);
        controlOrderList.setEmployee(employee);
        controlEditEmployee.setLoginEmployee(employee);
    }
        
    
    /**
     * 画面起動メソッド.
     */
    public void start() {
        boundarySystemMenu.setControl(this);
        boundarySystemMenu.setVisible(true);
    }
    /**
     * ログイン画面への帰還メソッド.
     */
    public void exit() {
        boundarySystemMenu.setVisible(false);
        controlLogin.exitContents();
    }
    
    /**
     * 各種画面用のexitメソッド.
     */   
    public void exitContents() {
        boundarySystemMenu.setVisible(true);
    }
    
    public static void main(String[] args) {
        new ControlSystemMenu().start();
    }
    
    /**
     * システムメニューのコントール保存メソッド.
     * @param controlSystemMenu システムメニューのコントロール
     */
    /*
    public void setControlSystemMenu(ControlSystemMenu controlSystemMenu) {
        this.controlSystemMenu = controlSystemMenu;
    }
    */
    /**
     * システムメニューへの帰還メソッド.
     */
    /*
    public void exit() {
        .setVisible(false);
        super.getControlSystemMenu().exitContents();
    }
    
    boundarySystemMenu.setVisible(false);
    contorol.setControlSystemMenu(this);
    contorol.start();
    */

    /**
     * 従業員登録画面の起動メソッド.
     */
    void awakenEmployeeRegister() {
        boundarySystemMenu.setVisible(false);
        controlRegisterEmployee.setControlSystemMenu(this);
        controlRegisterEmployee.start();
    }

    /**
     * 従業員情報変更画面の起動メソッド.
     */
    void awakenEmployeeEditor() {
        boundarySystemMenu.setVisible(false);
        controlEditEmployee.setControlSystemMenu(this);
        controlEditEmployee.setReturnButtonVisble();
        controlEditEmployee.start();
    }
    /**
     * 従業員一覧画面の起動メソッド.
     * @author 20jz0105
     */
    void awakenEmployeeList() {
        boundarySystemMenu.setVisible(false);
        controlEmployeeList.setControlSystemMenu(this);
        controlEmployeeList.setControlEditEmployee(controlEditEmployee);
        controlEditEmployee.setControlEmployeeList(controlEmployeeList);
        controlEmployeeList.start();
    }    
    
    /**
     * 注文登録画面の起動メソッド.
     */
    void awakenOrderRegister() {
        boundarySystemMenu.setVisible(false);
        controlRegisterOrder.setControlSystemMenu(this);
        controlRegisterOrder.start();
    }
    /**
     * 注文状態画面の起動メソッド.
     */
    void awakenOrderStatus() {
        boundarySystemMenu.setVisible(false);
        controlOrderStatus.setControlPayment(controlPayment);
        controlPayment.setControlOrderStatus(controlOrderStatus);
        controlOrderStatus.setControlSystemMenu(this);
        controlOrderStatus.setReturnButtonVisble();
        controlOrderStatus.start();
    }
    /**
     * 注文一覧画面の起動メソッド.
     * @author 20jz0105
     */
    void awakenOrderList() {
        boundarySystemMenu.setVisible(false);
        controlOrderList.setControlSystemMenu(this);
        controlOrderList.setControlOrderStatus(controlOrderStatus);
        controlOrderStatus.setControlOrderList(controlOrderList);
        controlOrderStatus.setControlPayment(controlPayment);
        controlPayment.setControlOrderStatus(controlOrderStatus);
        controlOrderList.start();
    }    
    /**
     * 商品登録画面の起動メソッド.
     */
    void awakenRegisterProduct() {
        boundarySystemMenu.setVisible(false);
        controlRegisterProduct.setControlSystemMenu(this);
        controlRegisterProduct.start();
    }

    /**
     * 商品編集画面の起動メソッド.
     */
    void awakenProductEditor() {
        boundarySystemMenu.setVisible(false);
        controlEditProduct.setControlSystemMenu(this);
        controlEditProduct.setReturnButtonVisble();
        controlEditProduct.startSelect();
    }
    
    /**
     * 特別商品登録画面の起動メソッド.
     */
    void awakenSpecialRegisterProduct() {
        boundarySystemMenu.setVisible(false);
        contorolRegisterSpecialProduct.setControlSystemMenu(this);
        contorolRegisterSpecialProduct.start();
    }
    /**
     * 商品一覧画面の起動メソッド.
     * @author 20jz0105
     */
    void awakenProductList() {
        boundarySystemMenu.setVisible(false);        
        controlProductList.setControlSystemMenu(this);
        controlProductList.setControlEditProduct(controlEditProduct);
        controlEditProduct.setControlProductList(controlProductList);
        controlProductList.start();
    }
 
    /**
     * 法人顧客登録画面の起動メソッド.
     */
    void awakenCustomerCorpRegister() {
        boundarySystemMenu.setVisible(false);
        controlCorpCustomer.setControlSystemMenu(this);
        controlCorpCustomer.start();
    }
    
    /**
     * 入金画面の起動メソッド.
     */
    void awakenPayment() {
        boundarySystemMenu.setVisible(false);
        controlPayment.setControlSystemMenu(this);
        controlPayment.setReturnButtonVisble();
        controlPayment.start();
    }
    /**
     * 売上グラフ表示画面の起動メソッド.
     */
    void awakenAggregate() {
        boundarySystemMenu.setVisible(false);
        controlAggregate.setControlSystemMenu(this);
        controlAggregate.start();
    }

    /**
     * 引数で指定されたファイルに、顧客データリストを保存する.
     * @author 20jz0105
     */
    public void saveCustomerList() {
        boundarySystemMenu.saveNewFile();
        if (!"".equals(boundarySystemMenu.getCurrentFileFullPathName())) {
            try {
                List<Customer> customerList = customerDAO.dbSearchCustomerAll();       
                if (customerList.size() > 0) {
    //                BufferedWriter bw = new BufferedWriter(new FileWriter(boundarySystemMenu.getCurrentFileFullPathName()));//UTF保存
                    BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(boundarySystemMenu.getCurrentFileFullPathName()), Charset.forName("Shift-JIS")));//Sjis保存

                    bw.write(String.format("%s%n", customerList.get(0).getColumnNameAll()));
                    for (Customer customer : customerList) {
                        bw.write(String.format("%s%n", customer.getColumnAll()));
                    }
                    bw.close();
                }
            }
            catch (IOException e) {
                System.err.println("ファイルを保存できません [" + boundarySystemMenu.getCurrentFileFullPathName() + "]");
            }            
        }
    }
}

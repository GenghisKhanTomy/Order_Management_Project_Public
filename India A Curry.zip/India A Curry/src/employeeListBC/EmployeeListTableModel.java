package employeeListBC;

import javax.swing.table.DefaultTableModel;

/**
 *
 * @author 20jz0105
 */
public class EmployeeListTableModel extends DefaultTableModel {
    private int employeeNoColumn;
    private int employeeNameColumn;
    private int TELColumn;
    private int jobTypeColumn;
    private int showDetailColumn;
    
    public EmployeeListTableModel(Object[] os, int i) {
        super(os, i);
        for (int column = 0; column < getColumnCount(); column++) {
            if ("従業員番号".equals(getColumnName(column))) {
                setEmployeeNoColumn(column);
            }
            else if ("従業員名".equals(getColumnName(column))) {
                setEmployeeNameColumn(column);
            }
            else if ("電話番号".equals(getColumnName(column))) {
                setTELColumn(column);
            }
            else if ("役職".equals(getColumnName(column))) {
                setJobTypeColumn(column);
            }
            else if ("詳細".equals(getColumnName(column))) {
                setShowDetailColumn(column);
            }
        }
    }
    @Override
    public boolean isCellEditable(int row, int column) {
        return column == getShowDetailColumn();   
    }
    public int getEmployeeNoColumn() {
        return employeeNoColumn;
    }

    public int getEmployeeNameColumn() {
        return employeeNameColumn;
    }

    public int getTELColumn() {
        return TELColumn;
    }

    public int getJobTypeColumn() {
        return jobTypeColumn;
    }

    public int getShowDetailColumn() {
        return showDetailColumn;
    }

    public void setEmployeeNoColumn(int employeeNoColumn) {
        this.employeeNoColumn = employeeNoColumn;
    }

    public void setEmployeeNameColumn(int employeeNameColumn) {
        this.employeeNameColumn = employeeNameColumn;
    }

    public void setTELColumn(int TELColumn) {
        this.TELColumn = TELColumn;
    }

    public void setJobTypeColumn(int jobTypeColumn) {
        this.jobTypeColumn = jobTypeColumn;
    }

    public void setShowDetailColumn(int showDetailColumn) {
        this.showDetailColumn = showDetailColumn;
    }
    
}

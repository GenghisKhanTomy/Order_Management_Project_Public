package employeeListBC;

import javax.swing.JCheckBox;
import javax.swing.JOptionPane;

/**
 *
 * @author 20jz0105
 */
public class EmployeeListButtonEditor extends bcSuper.ButtonEditor {
    private BoundaryEmployeeList boundaryEmployeeList;
    
    public EmployeeListButtonEditor(JCheckBox checkBox, BoundaryEmployeeList boundaryEmployeeList) {
        super(checkBox);
        setBoundaryEmployeeList(boundaryEmployeeList);
    }

    public void setBoundaryEmployeeList(BoundaryEmployeeList boundaryEmployeeList) {
        this.boundaryEmployeeList = boundaryEmployeeList;
    }
    
    @Override
    public Object getCellEditorValue() {
        if (isPushed) {
            if ( boundaryEmployeeList.showConfirmYesNo("詳細に移動しますか？") == JOptionPane.YES_OPTION) {
                 boundaryEmployeeList.showDetail();
            }
        }
        isPushed = false;
        return label;
    }
    
}

package employeeListBC;

import DAO.EmployeeDAO;
import editEmployeeBC.ControlEditEmployee;
import java.util.List;
import model.Employee;

/**
 * 従業員一覧コントロール
 * @author 20jz0105
 */
public class ControlEmployeeList extends bcSuper.ControlSuper {
    private BoundaryEmployeeList boundaryEmployeeList;
    private ControlEditEmployee controlEditEmployee;
    private List<Employee> employeeList;
    private EmployeeDAO employeeDAO;
    private String searchWord;//帰還時の再検索用
    
    public ControlEmployeeList() {
        boundaryEmployeeList = new BoundaryEmployeeList();
        employeeDAO = new EmployeeDAO();
    }

    public void setControlEditEmployee(ControlEditEmployee controlEditEmployee) {
        this.controlEditEmployee = controlEditEmployee;
    }
    
    /**
     * 画面起動メソッド.
     */
    public void start() {
        boundaryEmployeeList.setControlEmployeeList(this);
        boundaryEmployeeList.clear();
        fetchEmployeeList("");
        boundaryEmployeeList.setVisible(true);        
    }
    /**
     * システムメニューへの帰還メソッド.
     */
    public void exit() {
        boundaryEmployeeList.setVisible(false);
        boundaryEmployeeList.clear();
        super.getControlSystemMenu().exitContents();        
    }
    /**
     * 従業員確認・変更画面からの帰還メソッド.
     */
    public void exitContents() {
        fetchEmployeeList(searchWord);
        boundaryEmployeeList.setVisible(true);
    }
    /**
     * ログイン画面への帰還メソッド.
     */
    public void exitLogout() {
        boundaryEmployeeList.setVisible(false);
        boundaryEmployeeList.clear();
        super.getControlSystemMenu().exit();
    }
    /**
     * 従業員のリストを検索して取得する
     * @param searchWord 検索ワード
     */
    public void fetchEmployeeList(String searchWord) {        
        employeeList = employeeDAO.dbSearchContunueEmployeeNoLikeORNameLike(searchWord);
        boundaryEmployeeList.clearEmployee();
        for (Employee employee : employeeList) {
            boundaryEmployeeList.appendEmployee(new Object[]{employee.getEmployeeNo(), employee.getEmployeeName(),
                                            employee.getTEL(), employee.isJobType() ? "マネージャー" : "従業員", "詳細を表示"});
        }
        this.searchWord = searchWord;
    }
    /**
     * 選択された従業員の詳細を表示.
     * @param employeeNo
     */
    public void awakenEmployeeList(String employeeNo) {
        controlEditEmployee.fetchEmployee(employeeNo);
        controlEditEmployee.setEnableAll(true);
        boundaryEmployeeList.setVisible(false);        
        controlEditEmployee.setReturnEmployeeListButtonVisble();
        controlEditEmployee.start();
    }

    public static void main(String[] args) {
        new ControlEmployeeList().start();
    }
}

package model;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 注文伝票ビュークラス.
 * @author 20jz0105
 */
public class OrderVoucherView {
    private int orderCode;          //注文コード
    private Timestamp orderTimestamp;   //注文年月日時分
    private int usageReward;    //利用ポイント
    private String address;     //配達先住所
    private String customerName;    //顧客名
    private String customerTEL; //顧客電話番号
    private int customerReward; //現在の顧客のポイント
    private boolean customerType;   //顧客区分  true:個人 / false:法人
        
    private Map<String, List<OrderVoucherDetail>> orderVoucherDetailMap;  //注文伝票の明細を格納したカテゴリマップ

    private int totalAmount;//注文金額
    private int addedReward;//付与ポイント
    
    public OrderVoucherView() {
        CreateOrderVoucherDetailMap();
        setTotalAmount(-1);
        setAddedReward(-1);
    }

    public OrderVoucherView(int orderCode, Timestamp orderTimestamp, int usageReward, String address, String customerName, String customerTEL, int customerReward, boolean customerType) {
        setInit(orderCode, orderTimestamp, usageReward, address, customerName, customerTEL, customerReward, customerType);
        CreateOrderVoucherDetailMap();
        setTotalAmount(-1);
        setAddedReward(-1);
    }
    
    public OrderVoucherView(int orderCode, Timestamp orderTimestamp, int usageReward, String address, String customerName, String customerTEL, int customerReward, boolean customerType, Map<String, List<OrderVoucherDetail>> orderVoucherDetailMap) {
        setInit(orderCode, orderTimestamp, usageReward, address, customerName, customerTEL, customerReward, customerType);
        setOrderVoucherDetailMap(orderVoucherDetailMap);
        setTotalAmount(-1);
        setAddedReward(-1);
    }

    @Override
    public String toString() {
        return getOrderCode() + ", " + getOrderTimestamp() + ", " + getUsageReward() + ", "  + getAddress() + ", " + getCustomerName() + ", "
                + getCustomerTEL() + ", " + getCustomerReward() + ", " + isCustomerType() + ", orderVoucherDetailMap[" + getOrderVoucherDetailMap() + "]";
    }
       
    public void print() {
        System.out.print(toString());
    }
    
    public void println() {
        print();
        System.out.println("");
    }
    
    public int getOrderCode() {
        return orderCode;
    }

    public Timestamp getOrderTimestamp() {
        return orderTimestamp;
    }

    public int getUsageReward() {
        return usageReward;
    }

    public String getAddress() {
        return address;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getCustomerTEL() {
        return customerTEL;
    }

    public int getCustomerReward() {
        return customerReward;
    }

    public boolean isCustomerType() {
        return customerType;
    }

    public Map<String, List<OrderVoucherDetail>> getOrderVoucherDetailMap() {
        return orderVoucherDetailMap;
    }

    /**
     * 合計金額を返す.
     * 　未計算なら合計金額を算出する
     * @return 合計金額
     */
    public int getTotalAmount() {
        if (totalAmount == -1) {
            setTotalAmount();
        }
        return totalAmount;
    }
    
    /**
     * 付与ポイントを返す.
     * 　未計算なら付与ポイントを算出する
     * @return 付与ポイント
     */    
    public int getAddedReward() {
        if (addedReward == -1) {
            setAddedReward();
        }
        return addedReward;
    }
    
    /**
     * 税込み合計金額を返す.
     * @return 税込み合計金額
     */
    public int getTaxTotalAmount() {
        return (int)(getTotalAmount() * (1 + constant.MoneyRelation.TAX));
    }
    /**
     * 消費税額を返す.
     * @return 消費税額
     */
    public int getTaxAmount() {        
        return (int)(getTotalAmount() * constant.MoneyRelation.TAX);
    }
    /**
     * 配達金額を返す.
     * 　配達金額は合計金額が3000円以上なら無料、3000円未満なら300円（定数クラス参照）
     * @return 配達金額
     */
    public int getDeliveryAmount() {
        return constant.MoneyRelation.getDeliveryAmount(getTaxTotalAmount());
    }
    /**
     * 請求金額を返す.
     * 　請求金額 = 税込み合計金額 + 配達金額 - 利用ポイント
     * @return 請求金額
     */
    public int getFinalyCost() {
        return getTaxTotalAmount() + getDeliveryAmount() - getUsageReward();
    }
    
    public void setOrderCode(int orderCode) {
        this.orderCode = orderCode;
    }

    public void setOrderTimestamp(Timestamp orderTimestamp) {
        this.orderTimestamp = orderTimestamp;
    }

    public void setUsageReward(int usageReward) {
        this.usageReward = usageReward;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void setCustomerTEL(String customerTEL) {
        this.customerTEL = customerTEL;
    }

    public void setCustomerReward(int customerReward) {
        this.customerReward = customerReward;
    }

    public void setCustomerType(boolean customerType) {
        this.customerType = customerType;
    }

    public void setOrderVoucherDetailMap(Map<String, List<OrderVoucherDetail>> orderVoucherDetailMap) {
        this.orderVoucherDetailMap = orderVoucherDetailMap;
    }

    public void setTotalAmount(int totalAmount) {
        this.totalAmount = totalAmount;
    }

    /**
     * 合計金額を求めてセットする.
     */
    public void setTotalAmount() {
        int totalAmount = 0;
        for (Map.Entry<String, List<OrderVoucherDetail>> entry : orderVoucherDetailMap.entrySet()) {
            for (OrderVoucherDetail orderVoucherDetail : entry.getValue()) {
                totalAmount += orderVoucherDetail.getSubTotal();
            }            
        }
        setTotalAmount(totalAmount);
    }

    public void setAddedReward(int addedReward) {
        this.addedReward = addedReward;
    }
    /**
     * 付与ポイントを求めてセットする.
     */
    public void setAddedReward() {
        double addedReward = 0.0;
        for (Map.Entry<String, List<OrderVoucherDetail>> entry : orderVoucherDetailMap.entrySet()) {
            for (OrderVoucherDetail orderVoucherDetail : entry.getValue()) {
                addedReward += orderVoucherDetail.getDoubleAddedReward();
            }            
        }
        setAddedReward((int)addedReward);
    }
    
    public void setInit(int orderCode, Timestamp orderTimestamp, int usageReward, String address, String customerName, String customerTEL, int customerReward, boolean customerType) {
        setOrderCode(orderCode);
        setOrderTimestamp(orderTimestamp);
        setUsageReward(usageReward);
        setAddress(address);
        setCustomerName(customerName);
        setCustomerTEL(customerTEL);
        setCustomerReward(customerReward);
        setCustomerType(customerType);
    }
    
    public void CreateOrderVoucherDetailMap() {
        orderVoucherDetailMap = new HashMap<>();
    }

    public static void main(String[] args) {
        System.out.println(new OrderVoucherView());
        System.out.println(new OrderVoucherView(1, Timestamp.valueOf(LocalDateTime.now()), 0, "月", "扇谷", "012-3456-7890", 0, false));
        System.out.println(new OrderVoucherView(2, Timestamp.valueOf(LocalDateTime.now()), 10, "日本電子専門学校7号館", "豊福", "111-2222-3333", 100, true, new HashMap<>()));
    }    
}

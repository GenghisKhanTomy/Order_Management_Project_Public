package model;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * 特別商品テーブル
 * @author 20jz0105
 */
public class SpecialProduct {
    private Product product;
    private float rewardMagnification;
    private Date specialSalesStartDate;
    private Date specialSalesEndDate;

    public SpecialProduct() {
    }

    public SpecialProduct(Product product, float rewardMagnification, Date specialSalesStartDate, Date specialSalesEndDate) {
        this.product = product;
        this.rewardMagnification = rewardMagnification;
        this.specialSalesStartDate = specialSalesStartDate;
        this.specialSalesEndDate = specialSalesEndDate;
    }

    @Override
    public String toString() {
        return "product[" + getProduct() + ", " + getRewardMagnification() + ", " + getSpecialSalesStartDate() + ", " + getSpecialSalesEndDate();
    }
    
    public void print() {
        System.out.print(toString());
    }
    
    public void println() {
        print();
        System.out.println("");
    }
    
    public Product getProduct() {
        return product;
    }

    public float getRewardMagnification() {
        return rewardMagnification;
    }

    public Date getSpecialSalesStartDate() {
        return specialSalesStartDate;
    }

    public Date getSpecialSalesEndDate() {
        return specialSalesEndDate;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public void setRewardMagnification(float rewardMagnification) {
        this.rewardMagnification = rewardMagnification;
    }

    public void setSpecialSalesStartDate(Date specialSalesStartDate) {
        this.specialSalesStartDate = specialSalesStartDate;
    }

    public void setSpecialSalesEndDate(Date specialSalesEndDate) {
        this.specialSalesEndDate = specialSalesEndDate;
    }
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        List<SpecialProduct> specialProducts = new ArrayList<>();
        
        specialProducts.add(new SpecialProduct());
        specialProducts.add(new SpecialProduct(null, 0, Date.valueOf("1999-10-10"), Date.valueOf("2019-10-10")));
        specialProducts.add(new SpecialProduct(new Product(), 0, Date.valueOf(LocalDate.now()), null));
        
        for (SpecialProduct specialProduct : specialProducts) {
            specialProduct.println();
        }
    }
}

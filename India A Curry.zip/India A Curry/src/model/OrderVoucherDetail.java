package model;

/**
 * 注文伝票
 * @author 20jz0105
 */
public class OrderVoucherDetail {
    private int orderDetailCode;    //注文明細番号 現在未使用
//    private String typeName;   //商品カテゴリ
    
    private String productNo;   //商品番号+サイズ番号
    private String productName; //商品名+サイズ
    private int quantity;   //個数
    private int price;  //単価
    private double rewardMagnification; //ポイント倍率
    private String note;    //備考ノート    

    public OrderVoucherDetail() {
    }

    public OrderVoucherDetail(int orderDetailCode, String productNo, String productName, int quantity, int price, double rewardMagnification, String note) {
        setOrderDetailCode(orderDetailCode);
        setProductNo(productNo);
        setProductName(productName);
        setQuantity(quantity);
        setPrice(price);
        setRewardMagnification(rewardMagnification);
        setNote(note);
    }

    @Override
    public String toString() {
        return getOrderDetailCode() + ", " + getProductNo() + ", " + getProductName() + ", " + getQuantity() + ", " + getPrice() + ", " + getRewardMagnification() + ", " + getNote();
    }

    public void print() {
        System.out.print(toString());
    }
    
    public void println() {
        print();
        System.out.println("");
    }

    public int getOrderDetailCode() {
        return orderDetailCode;
    }

    public String getProductNo() {
        return productNo;
    }

    public String getProductName() {
        return productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getPrice() {
        return price;
    }
    
    public int getTaxPrice() {
        return (int)(price * 1.08);
    }
    
    public int getTax() {
        return (int)(price * 0.08);        
    }

    public double getRewardMagnification() {
        return rewardMagnification;
    }

    public String getNote() {
        return note == null ? "" : note;
    }
    /**
     * 商品の単価×注文数を返す.
     * @return 単価×注文数
     */
    public int getSubTotal() {
        return  getPrice() * getQuantity();
    }
    /**
     * 商品の税込み単価×注文数を返す.
     * @return 税込み単価×注文数
     */
    public int getTaxSubTotal() {
        return  getTaxPrice() * getQuantity();
    }
    /**
     * 商品の付与ポイントを返す.
     * 　小数点込みで返す
     * @return 付与ポイント
     */
    public double getDoubleAddedReward() {
        return getTaxSubTotal() * getRewardMagnification() / 100;
    }
    /**
     * 商品の付与ポイントを返す.
     * 　整数で返す
     * @return 付与ポイント
     */
    public int getIntAddedReward() {
        return (int)(getTaxSubTotal() * getRewardMagnification() / 100);
    }

    public void setOrderDetailCode(int orderDetailCode) {
        this.orderDetailCode = orderDetailCode;
    }

    public void setProductNo(String productNo) {
        this.productNo = productNo;
    }
        
    public void setProductName(String productName) {
        this.productName = productName;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setPrice(int price) {
        this.price = price;
    }


    
    public void setRewardMagnification(double rewardMagnification) {
        this.rewardMagnification = rewardMagnification;
    }

    public void setNote(String note) {
        this.note = note;
    }
    

    public static void main(String[] args) {
        System.out.println(new OrderVoucherDetail());
        System.out.println(new OrderVoucherDetail(1, "P0001", "ポークカレー", 1, 500, 1 ,"memo"));
    }
}

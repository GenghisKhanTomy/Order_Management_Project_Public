package model;

import java.util.List;
import java.util.ArrayList;

/**
 * メニュービュークラス
 * @author 20jz0105
 */
public class MenuView {
    private String productNo;   //商品番号(商品番号+サイズ名)
    private String productName; //商品名(商品名+サイズ名)
    private int price;          //金額(商品価格+サイズ価格)
    private String categoryName;    //区分名前

    public MenuView() {
        ;
    }
    
    public MenuView(String productNo, String productName, int price, String typeName) {
        setProductNo(productNo);
        setProductName(productName);
        setPrice(price);
        setCategoryName(typeName);
    }

    @Override
    public String toString() {
        return getProductNo() + ", " + getProductName() + ", " + getPrice() + ", " + getCategoryName();
    }
        
    public void print() {
        System.out.print(toString());
    }
    
    public void println() {
        print();
        System.out.println("");
    }
    

    public String getProductNo() {
        return productNo;
    }

    public String getProductName() {
        return productName;
    }

    public int getPrice() {
        return price;
    }
    
    public int getTaxPrice() {
        return (int)(getPrice() * (1 + constant.MoneyRelation.TAX));
    }

    public int getTax() {
        return (int)(getPrice() * constant.MoneyRelation.TAX);
    }
    
    public String getCategoryName() {
        return categoryName;
    }

    public void setProductNo(String productNo) {
        this.productNo = productNo;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public void setPrice(int price) {
        this.price = price;
    }
    
    public void setCategoryName(String typeName) {
        this.categoryName = typeName;
    }
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        List<MenuView> menuViews = new ArrayList<>();
        
        menuViews.add(new MenuView("P001L", "ライスL", 400, "主食"));
        menuViews.add(new MenuView("P002M", "ポークカレーM", 500 , "カレー"));
        menuViews.add(new MenuView("P003M", "ポークカレーセットM", 800, "セット"));
        
        for (MenuView menuView : menuViews) {
            menuView.println();
        }
        
    }
}

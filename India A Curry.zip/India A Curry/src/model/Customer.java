package model;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;

/**
 * 顧客テーブルクラス
 * @author 20jz0105
 */
public class Customer {
    private String customerNo;//顧客番号
    private String customerTEL;//電話番号
    private String customerAddress;//住所
    private String customerName;//名前
    private int customerReward;//ポイント
    private boolean customerType;//顧客区分　true:個人　false:法人
//    private String customerFrequentlyProduct;//最頻注文商品番号
    private Product customerFrequentlyProduct;//最頻注文商品
    private String anotherAddress;//配達先住所

    public Customer() {
    }
    
    public Customer(String customerTEL, String customerAddress, String customerName, boolean customerType) {
        setCustomerTEL(customerTEL);
        setCustomerAddress(customerAddress);
        setCustomerName(customerName);
        setCustomerType(customerType);
    }
    /**
     * 顧客登録用コンストラクタ
     * @param customerNo
     * @param customerTEL
     * @param customerAddress
     * @param customerName
     * @param customerType 
     */
    public Customer(String customerNo, String customerTEL, String customerAddress, String customerName, boolean customerType) {
        setCustomerNo(customerNo);
        setCustomerTEL(customerTEL);
        setCustomerAddress(customerAddress);
        setCustomerName(customerName);
        setCustomerType(customerType);
    }
    

    public Customer(String customerTEL, String customerAddress, String customerName, int customerReward, boolean customerType, Product customerFrequentlyProduct, String anotherAddress) {

        setCustomerTEL(customerTEL);
        setCustomerAddress(customerAddress);
        setCustomerName(customerName);
        setCustomerReward(customerReward);
        setCustomerType(customerType);
        setCustomerFrequentlyProduct(customerFrequentlyProduct);
        setAnotherAddress(anotherAddress);    
    }

    public Customer(String customerNo, String customerTEL, String customerAddress, String customerName, int customerReward, boolean customerType, Product customerFrequentlyProduct, String anotherAddress) {
        setCustomerNo(customerNo);
        setCustomerTEL(customerTEL);
        setCustomerAddress(customerAddress);
        setCustomerName(customerName);
        setCustomerReward(customerReward);
        setCustomerType(customerType);
        setCustomerFrequentlyProduct(customerFrequentlyProduct);
        setAnotherAddress(anotherAddress);    
    }

    
    
    @Override
    public String toString() {
        return getCustomerNo() + ", " +  getCustomerTEL() + ", " + getCustomerAddress() + ", " + getCustomerName() + ", " + getCustomerReward() + ", " + isCustomerType() + ", customerFrequentlyProduct[" + getCustomerFrequentlyProduct() + "], " + getAnotherAddress();
    }
    
    public void print() {
        System.out.print(toString());
    }
    
    public void println() {
        print();
        System.out.println("");
    }

    public void setCustomerNo(String customerNo) {
        this.customerNo = customerNo;
    }

    public void setCustomerTEL(String customerTEL) {
        this.customerTEL = customerTEL;
    }

    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void setCustomerReward(int customerReward) {
        this.customerReward = customerReward;
    }

    public void setCustomerType(boolean customerType) {
        this.customerType = customerType;
    }

    public void setCustomerFrequentlyProduct(Product customerFrequentlyProduct) {
        this.customerFrequentlyProduct = customerFrequentlyProduct;
    }

    public void setAnotherAddress(String anotherAddress) {
        this.anotherAddress = anotherAddress;
    }

    public String getCustomerNo() {
        return customerNo;
    }

    
    public String getCustomerTEL() {
        return customerTEL;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public String getCustomerName() {
        return customerName;
    }

    public int getCustomerReward() {
        return customerReward;
    }

    /**
     * 顧客区分のゲッター.
     * @return true:個人   false:法人
     */
    public boolean isCustomerType() {
        return customerType;
    }

    public Product getCustomerFrequentlyProduct() {
        return customerFrequentlyProduct;
    }

    public String getAnotherAddress() {
        return anotherAddress;
    }
    
    public String getColumnNameAll() {
        return "顧客番号, 名前, 電話番号, 住所, ポイント, 配達先住所, 顧客区分, 最頻注文商品番号";
    }
    
    public String getColumnAll() {
        return (getCustomerNo() + ", " + getCustomerName() + ", " + getCustomerTEL() + ", " + getCustomerAddress() + ", " + getCustomerReward() + ", " + (getAnotherAddress() != null ? getAnotherAddress() : "") + ", " + isCustomerType() + ", ") + (getCustomerFrequentlyProduct() != null ? getCustomerFrequentlyProduct().getProductNo() : "");
    }
    
    public static void main(String[] args) {
        List<Customer> customers = new ArrayList<>();
        
        customers.add(new Customer("03-3363-7761", "東京都新宿区百人町1-25-4", "日本電子専門学校", 0, false, null, "i専門職大学"));
        customers.add(new Customer("03-1234-5678", "東京都墨田区文花1-18-13", "iU 情報経営イノベーション専門職大学", 0, false, new Product(), ""));
        customers.add(new Customer("080-1414-2135", "月", "ルート2", 0, true, new Product("P001", "name", "カレー", 0, Date.valueOf(LocalDate.now()), null, false), "1241教室"));

        for (Customer customer : customers) {
            customer.println();
        }
    }

    
}

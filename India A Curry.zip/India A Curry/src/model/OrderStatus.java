package model;

import java.sql.Timestamp;
import java.util.List;
import java.util.ArrayList;


/**
 * 注文状態テーブルクラス
 * @author 20jz0105
 */
public class OrderStatus {
    private Order order;                    //注文オブジェクト
    private int orderAmount;                //注文状態　記録日時を参照する添え字でもある
    private Timestamp[] recordTimestampArray;//各種状態の記録日時　0:調理開始 1:調理終了 2:配達開始 3:配達終了

    public OrderStatus() {
        ;
    }

    public OrderStatus(Order order) {
        this(order, 0, new Timestamp[4]);
    }    
    
    public OrderStatus(Order order, int orderAmount, Timestamp[] recordDatetimeArray) {
        setOrder(order);
        setOrderAmount(orderAmount);
        setRecordDatetimeArray(recordDatetimeArray);
    }

    @Override
    public String toString() {
        return "order[" + getOrder()+ "], " + getOrderAmount()+ ", RecordDatetimeArray[" + getRecordDatetimeArray() + "], " + getOrderAmount(getOrderAmount());
    }
    
    public void print() {
        System.out.print(toString());
    }
    
    public void println() {
        print();
        System.out.println("");
    }
    
    public Order getOrder() {
        return order;
    }

    public int getOrderAmount() {
        return orderAmount;
    }

    public Timestamp[] getRecordDatetimeArray() {
        return recordTimestampArray;
    }
    
    public Timestamp getOrderAmount(int orderAmount) {
        return recordTimestampArray != null? recordTimestampArray[orderAmount] : null; //NullPointerException回避のため三項演算子
    }

    public void setOrder(Order order) {
        this.order = order;        
    }

    public void setOrderAmount(int orderAmount) {
        this.orderAmount = orderAmount;
    }

    public void setRecordDatetimeArray(Timestamp[] recordDatetimeArray) {
        this.recordTimestampArray = recordDatetimeArray;
    }
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        List<OrderStatus> orderStatuses = new ArrayList<>();
        
        orderStatuses.add(new OrderStatus(null));
        orderStatuses.add(new OrderStatus(new Order()));
        orderStatuses.add(new OrderStatus(new Order(), 0, new Timestamp[4]));
        
        for (OrderStatus orderStatus : orderStatuses) {
            orderStatus.println();
        }
    }
    
}

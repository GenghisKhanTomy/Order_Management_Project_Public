package model;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * 売上サマリーテーブル
 * @author 20jz0105
 */
public class SalesSummary {
    private Timestamp groupDate;
    private int price;
    private char days;
    private int year;
    private int month;
    private int day;
    private int hour;


    public SalesSummary(Timestamp groupDate, int price, char days, int year, int month, int day, int hour) {
        setGroupDate(groupDate);
        setPrice(price);
        setDays(days);
        setYear(year);
        setMonth(month);
        setDay(day);
        setHour(hour);
    }

    @Override
    public String toString() {
        return getGroupDate() + ", " + getPrice() + ", " + getDays() + ", " + getYear() + ", " + getMonth() + ", " + getDay() + ", " + getHour();
    }
    
    public void print() {
        System.out.print(toString());
    }
    
    public void println() {
        print();
        System.out.println("");
    }
    
    public Timestamp getGroupDate() {
        return groupDate;
    }

    public int getPrice() {
        return price;
    }

    public char getDays() {
        return days;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public int getDay() {
        return day;
    }

    public int getHour() {
        return hour;
    }
    
    /**
     * 集計データは変更されては困るのでセッターはprivate
     */
    private void setGroupDate(Timestamp groupDate) {
        this.groupDate = groupDate;
    }

    private void setPrice(int price) {
        this.price = price;
    }

    private void setDays(char days) {
        this.days = days;
    }

    private void setYear(int year) {
        this.year = year;
    }

    private void setMonth(int month) {
        this.month = month;
    }

    private void setDay(int day) {
        this.day = day;
    }

    private void setHour(int hour) {
        this.hour = hour;
    }
    
    public static void main(String[] args) {
        List<SalesSummary> salesSummarys = new ArrayList<>();
        salesSummarys.add(new SalesSummary(Timestamp.valueOf(LocalDateTime.now()), 0, '月', 1, 2, 10, 18));
        salesSummarys.add(new SalesSummary(Timestamp.valueOf(LocalDateTime.now()), 0, '日', 2002, 1, 30, 24));
        salesSummarys.add(new SalesSummary(null, 120, '水', 1999, 1, 1, 1));

        for (SalesSummary salesSummary : salesSummarys) {
            salesSummary.println();
        }

    }
}

package model;

import constant.OrderStatusList;
import java.sql.Timestamp;

/**
 * 注文一覧画面用クラス.
 * @author 20jz0105
 */
public class OrderListView {
    private int orderCode;                      //注文コード
    private Timestamp orderTimestamp;           //注文年月日時分
    private Timestamp cookingStartTimestamp;    //調理開始年月日時分
    private Timestamp cookingEndTimestamp;      //調理終了年月日時分
    private Timestamp deliveryStartTimestamp;   //配達開始年月日時分
    private Timestamp deliveryEndTimestamp;     //配達終了年月日時分
    private Timestamp paymentTimestamp;         //入金年月日時分
    private String cutomerTEL;//電話番号
    private boolean customerType;//顧客区分　true:個人　false:法人    
    private String cutomerName;//顧客名
    private int usageReward;//利用ポイント
    private int totalAmount;//合計金額

    public OrderListView() {
    }


    public OrderListView(int orderCode, Timestamp orderTimestamp, Timestamp cookingStartTimestamp, Timestamp cookingEndTimestamp, Timestamp deliveryStartTimestamp, Timestamp deliveryEndTimestamp, Timestamp paymentTimestamp, String cutomerTEL, boolean customerType, String cutomerName, int usageReward, int totalAmount) {
        setOrderCode(orderCode);
        setOrderTimestamp(orderTimestamp);
        setCookingStartTimestamp(cookingStartTimestamp);
        setCookingEndTimestamp(cookingEndTimestamp);
        setDeliveryStartTimestamp(deliveryStartTimestamp);
        setDeliveryEndTimestamp(deliveryEndTimestamp);
        setPaymentTimestamp(paymentTimestamp);
        setCutomerTEL(cutomerTEL);
        setCutomerName(cutomerName);
        setCustomerType(customerType);
        setUsageReward(usageReward);
        setTotalAmount(totalAmount);
    }
    
    
    @Override
    public String toString() {
        return getOrderCode() + ", " +  getOrderTimestamp() + ", " + getCookingStartTimestamp() + ", " + getCookingEndTimestamp() + ", " + getDeliveryStartTimestamp()+ ", " + getDeliveryEndTimestamp() + ", " + getPaymentTimestamp() + ", " + getCutomerTEL() + ", " + getCutomerName() + ", " + isCustomerType() + ", " + getUsageReward() + ", " + getTotalAmount();
    }
    
    public void print() {
        System.out.print(toString());
    }
    
    public void println() {
        print();
        System.out.println("");
    }

    public int getOrderCode() {
        return orderCode;
    }

    public Timestamp getOrderTimestamp() {
        return orderTimestamp;
    }

    public Timestamp getCookingStartTimestamp() {
        return cookingStartTimestamp;
    }

    public Timestamp getCookingEndTimestamp() {
        return cookingEndTimestamp;
    }

    public Timestamp getDeliveryStartTimestamp() {
        return deliveryStartTimestamp;
    }

    public Timestamp getDeliveryEndTimestamp() {
        return deliveryEndTimestamp;
    }

    public Timestamp getPaymentTimestamp() {
        return paymentTimestamp;
    }

    public String getCutomerTEL() {
        return cutomerTEL;
    }

    public boolean isCustomerType() {
        return customerType;
    }

    public String getCutomerName() {
        return cutomerName;
    }

    public int getUsageReward() {
        return usageReward;
    }

    public int getTotalAmount() {
        return totalAmount;
    }
    public int getTaxTotalAmount() {
        return (int)(totalAmount * (1 + constant.MoneyRelation.TAX));
    }    
    /**
     * 配達金額を返す.
     * 　配達金額は合計金額が3000円以上なら無料、3000円未満なら300円
     * @return 配達金額
     */
    public int getDeliveryAmount() {
        int deliveryAmount = 300;
        if (getTaxTotalAmount() >= 3000) {
            deliveryAmount = 0;
        }
        return deliveryAmount;
    }
    /**
     * 請求金額を返す.
     * 　請求金額 = 税込み合計金額 + 配達金額 - 利用ポイント
     * @return 請求金額
     */
    public int getFinalyCost() {
        return getTaxTotalAmount() + getDeliveryAmount() - getUsageReward();
    }
    /**
     * 現在の注文状態をint型で返す.
     * @return 注文状態
     */
    public int getIntOrderStatus() {
        int orderStatus;
        if (getPaymentTimestamp() != null) {
            orderStatus = OrderStatusList.PAID;
        }
        else if (getDeliveryEndTimestamp() != null) {
            orderStatus = OrderStatusList.DELIVERY_END;
        }
        else if (getDeliveryStartTimestamp() != null) {
            orderStatus = OrderStatusList.DELIVERY_START;
        }
        else if (getCookingEndTimestamp() != null) {
            orderStatus = OrderStatusList.COOKING_END;
        }
        else if (getCookingStartTimestamp() != null) {
            orderStatus = OrderStatusList.COOKING_START;
        }
        else if (getOrderTimestamp() != null) {
            orderStatus = OrderStatusList.ORDER_ACCEPTED;
        }
        else {
            orderStatus = OrderStatusList.ERROR;
        }
        return orderStatus;
    }
    /**
     * 指定された状態の年月日時分を返す.
     * @param orderStatus 注文状態
     * @return 年月日時分の情報
     */
    public Timestamp getTimestamp(int orderStatus) {
        Timestamp timestamp;
        switch (orderStatus) {
            case OrderStatusList.COOKING_START:
                timestamp = getCookingStartTimestamp();
                break;
            case OrderStatusList.COOKING_END:
                timestamp = getCookingEndTimestamp();
                break;
            case OrderStatusList.DELIVERY_START:
                timestamp = getDeliveryStartTimestamp();
                break;
            case OrderStatusList.DELIVERY_END:
                timestamp = getDeliveryEndTimestamp();
                break;
            case OrderStatusList.PAID:
                timestamp = getPaymentTimestamp();
                break;
            case OrderStatusList.ORDER_ACCEPTED:
                timestamp = getOrderTimestamp();
                break;
            default:
                timestamp = null;
                break;
        }
        return timestamp;        
    }
    public void setOrderCode(int orderCode) {
        this.orderCode = orderCode;
    }

    public void setOrderTimestamp(Timestamp orderTimestamp) {
        this.orderTimestamp = orderTimestamp;
    }

    public void setCookingStartTimestamp(Timestamp cookingStartTimestamp) {
        this.cookingStartTimestamp = cookingStartTimestamp;
    }

    public void setCookingEndTimestamp(Timestamp cookingEndTimestamp) {
        this.cookingEndTimestamp = cookingEndTimestamp;
    }

    public void setDeliveryStartTimestamp(Timestamp deliveryStartTimestamp) {
        this.deliveryStartTimestamp = deliveryStartTimestamp;
    }

    public void setDeliveryEndTimestamp(Timestamp deliveryEndTimestamp) {
        this.deliveryEndTimestamp = deliveryEndTimestamp;
    }

    public void setPaymentTimestamp(Timestamp paymentTimestamp) {
        this.paymentTimestamp = paymentTimestamp;
    }

    public void setCutomerTEL(String cutomerTEL) {
        this.cutomerTEL = cutomerTEL;
    }

    public void setCustomerType(boolean customerType) {
        this.customerType = customerType;
    }

    public void setCutomerName(String cutomerName) {
        this.cutomerName = cutomerName;
    }

    public void setUsageReward(int usageReward) {
        this.usageReward = usageReward;
    }

    public void setTotalAmount(int totalAmount) {
        this.totalAmount = totalAmount;
    }
}

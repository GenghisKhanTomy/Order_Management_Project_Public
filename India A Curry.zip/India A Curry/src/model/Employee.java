package model;

import DAO.DualDAO;
import java.sql.Date;
import java.time.LocalDate;

import java.util.List;
import java.util.ArrayList;


/**
 * 従業員テーブルクラス
 * @author 20jz0132
 */
public class Employee {
    //filed
    private String employeeNo;          //従業員番号
    private String employeeName;                //名前
    private String password;            //パスワード
    private int sex;                    //性別 1 -> 男 2 -> 女 3 -> その他
    private Date birthDate;             //誕生日
    private String TEL;               //電話番号
    private String address;             //住所
    private boolean jobType;            //役職区分 True -> マネージャー False -> 一般従業員
    private boolean continueServiceType;//勤続区分 True -> 在籍中       False -> 在籍してないっすわ
    
    //constructor
    public Employee() {
        
    }

    public Employee(String employeeName, int sex, Date birthDate, String TEL, String address, boolean jobType) {
        this(employeeName, "", sex, birthDate, TEL, address, jobType);
    }
    
    
    
    public Employee(String employeeName, String password, int sex, Date birthDate, String TEL, String address, boolean jobType) {
        this(String.format("%05d", new DualDAO().dbSearchSeqEmployeeNextVal()), employeeName, password, sex, birthDate, TEL, address, jobType);
    }
    
    public Employee(String employeeNo, String employeeName, String password, int sex, Date birthDate, String TEL, String address, boolean jobType) {
        setEmployeeNo(employeeNo);
        setEmployeeName(employeeName);
        setPassword(password);
        setSex(sex);
        setBirthDate(birthDate);
        setTEL(TEL);
        setAddress(address);
        setJobType(jobType);
    }
    
    public Employee(String employeeNo, String employeeName, String password, int sex, Date birthDate, String TEL, String address, boolean jobType, boolean continueServiceType) {
        setEmployeeNo(employeeNo);
        setEmployeeName(employeeName);
        setPassword(password);
        setSex(sex);
        setBirthDate(birthDate);
        setTEL(TEL);
        setAddress(address);
        setJobType(jobType);
        setContinueServiceType(continueServiceType);
    }
    
    //setter
    public void setEmployeeNo(String employeeNo) {
        this.employeeNo = employeeNo;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public void setTEL(String telNo) {
        this.TEL = telNo;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setJobType(boolean jobType) {
        this.jobType = jobType;
    }

    public void setContinueServiceType(boolean continueServiceType) {
        this.continueServiceType = continueServiceType;
    }
    
    //getter
    public String getEmployeeNo() {
        return employeeNo;
    }

    public String getEmployeeName() {
        return employeeName;
    }

//    private String getPassword() {
    public String getPassword() {//privateだとINSERT時に使えない、publicにしてハッシュ化した値を持つのはどうか？
        return password;
    }

    public int getSex() {
        return sex;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public String getTEL() {
        return TEL;
    }

    public String getAddress() {
        return address;
    }

    public boolean isJobType() {
        return jobType;
    }

    public boolean isContinueServiceType() {
        return continueServiceType;
    }
    
    @Override
    public String toString() {
       // String employeeName, String password, int sex, Date birthDate, String telNo, String address, int jobType, int continueServiceType
        return getEmployeeNo() + ", " + getEmployeeName() + ", " + getPassword() + ", " + getSex() + ", " + getBirthDate() + ", " + getTEL() + ", " + getAddress() + ", " + isJobType() + ", " + isContinueServiceType();
    }
    
    public void print() {
        System.out.print(toString());
    }
    
    public void println() {
        print();
        System.out.println("");
    }
    
    
    public static void main(String[] args) {
        List<Employee> employees = new ArrayList<>();
        
       // String name, String password, int sex, Date birthDate, String telNo, String address, int jobType, int continueServiceType
        employees.add(new Employee("E100", "豊福", "toyofuku", 1, Date.valueOf("1800-10-01"), "080-xxxx-yyyy", "東京都千代田区1-2-3", true, true));
        employees.add(new Employee("M003", "都", "miyako", 0, Date.valueOf("2100-01-02"), "050-aaaa-bbbb", "東京都千代田区1-2-3", false, false));
        employees.add(new Employee("E005", "木戸", "kido", 1, Date.valueOf(LocalDate.now()), "070-ccccc-zzzz", "東京都千代田区1-2-3", false, true));
        
        for (Employee employee : employees) {
            employee.print();
//            System.out.println(" : 一致確認(send -> toyofuku)" + employee.equalPassword("toyofuku"));
        }
    }
    
    
    /**
     * 以下非推奨メソッド
     * @author 20jz0105
     */
    /*
    public void setJobType(int jobType) {
        this.jobType = jobType == 1;
    }

    public void setContinueServiceType(int continueServiceType) {
        this.continueServiceType = continueServiceType == 1;
    }*/
    
    /**
     * 受け取ったパスワードが、このインスタンスのパスワードと一致するか
     * @param password
     * @return true -> 一致 / false -> 不一致
     */
    /*
    public boolean equalPassword(String password) {
        return password.equals(this.password);
    }*/
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import java.util.List;

/**
 * 請求書リストクラス
 * @author 20jz0105
 */
public class InvoiceView {
    private String customerNo;//顧客番号
    private String customerTEL;//電話番号
    private String customerName;//名前
    private List<InvoiceDetail> invoiceViewList;//請求書クラスのリスト

    public InvoiceView() {
        invoiceViewList = new ArrayList<>();
    }

    public InvoiceView(String customerNo, String customerTEL, String customerName) {
        this(customerNo, customerTEL, customerName, new ArrayList<>());
    }
    
    public InvoiceView(String customerNo, String customerTEL, String customerName, List<InvoiceDetail> invoiceViewList) {
        setCustomerTEL(customerTEL);
        setCustomerName(customerName);
        setInvoiceViewList(invoiceViewList);
    }
    
    @Override
    public String toString() {
        return getCustomerNo() + ", " +  getCustomerTEL() + ", " + getCustomerName() + ", invoiceList[" + getInvoiceViewList() + "]";
    }
       
    public void print() {
        System.out.print(toString());
    }
    
    public void println() {
        print();
        System.out.println("");
    }

    public String getCustomerNo() {
        return customerNo;
    }
    
    public String getCustomerTEL() {
        return customerTEL;
    }

    public String getCustomerName() {
        return customerName;
    }

    public List<InvoiceDetail> getInvoiceViewList() {
        return invoiceViewList;
    }

    public void setCustomerNo(String customerNo) {
        this.customerNo = customerNo;
    }

    public void setCustomerTEL(String customerTEL) {
        this.customerTEL = customerTEL;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void setInvoiceViewList(List<InvoiceDetail> invoiceViewList) {
        this.invoiceViewList = invoiceViewList;
    }
    
    public void addInvoiceDetail(InvoiceDetail invoiceDetail) {
        getInvoiceViewList().add(invoiceDetail);
    }

    public static void main(String[] args) {
        System.out.println(new InvoiceView());
        System.out.println(new InvoiceView("C123", "TEL", "NAME", new ArrayList<>()));
    }
    
    
}

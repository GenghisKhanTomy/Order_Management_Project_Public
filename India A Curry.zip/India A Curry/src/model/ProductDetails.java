package model;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * 商品明細テーブル
 * @author 20jz0105
 */
public class ProductDetails {
    private Product product;        //商品
    private Product productDetail;  //商品明細番号
    private int quantity;           //個数

    public ProductDetails() {
    }

    public ProductDetails(Product prodcut, Product productDetail, int quantity) {
        setProdcut(prodcut);
        setProductDetail(productDetail);
        setQuantity(quantity);
    }

    @Override
    public String toString() {
        return "product[" + getProdcut() + "], " + getProductDetail() + ", " + getQuantity();
    }

    public void print() {
        System.out.print(toString());
    }
    
    public void println() {
        print();
        System.out.println("");
    }
    
    public Product getProdcut() {
        return product;
    }

    public Product getProductDetail() {
        return productDetail;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setProdcut(Product prodcut) {
        this.product = prodcut;
    }

    public void setProductDetail(Product productDetail) {
        this.productDetail = productDetail;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public static void main(String[] args) {
        List<ProductDetails> productDetailses = new ArrayList<>();
        
        productDetailses.add(new ProductDetails());
        productDetailses.add(new ProductDetails(new Product(), new Product(), 1));
        productDetailses.add(new ProductDetails(new Product("P00007", "ビーフカレー", "カレー", 0, Date.valueOf(LocalDate.now()), null, false), new Product("P001", "", "", 0, null, null, false), 1));

        for (ProductDetails productDetails : productDetailses) {
            productDetails.println();
        }
    }
}
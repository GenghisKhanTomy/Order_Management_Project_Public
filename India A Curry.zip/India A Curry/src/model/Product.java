package model;

import DAO.DualDAO;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * 商品テーブルクラス
 * @author 20jz0105
 */
public class Product {
    private String productNo;   //商品番号
    private String productName; //商品名
    private String typeName;    //区分名 定義域:主食, カレー, サイド, トッピング, セット
    private int price;          //金額
    private Date productSalesStartDate; //販売開始年月日
    private Date prodcutSalesEndDate;   //販売終了年月日
    private boolean productType;        //セット商品区分  true:セット商品　false:単独商品
//    private DualDAO dualDAO;
    
    public Product() {
        ;
    }    

    /**
     * 商品詳細追加のために作成
     * @author 20jz0132
     * @param productNo 
     */
    public Product(String productNo) {
        setProductNo(productNo);
    }
    
    /**
     * 商品追加のために作成.
     * また、商品番号を登録する際に商品番号はdualDAO..dbSearchSeqProductNextVal()から取得する。
     *  //注文や従業員と統一化が図れていない.この方法なら外部でDualDAOを呼ぶ必要はないが、必要ないときにもシーケンスを進めてしまう可能性がある
     * @author 20jz0132
     * @param productName
     * @param typeName
     * @param price
     * @param productSalesStartDate
     * @param prodcutSalesEndDate
     * @param productType 
     */
    public Product(String productName, String typeName, int price, Date productSalesStartDate, Date prodcutSalesEndDate, boolean productType) {
        this(new DualDAO().dbSearchSeqProductNextVal(), productName, typeName, price, productSalesStartDate, prodcutSalesEndDate, productType);
        

//        dualDAO = new DualDAO();
//        setProductNo(dualDAO.dbSearchSeqProductNextVal());
//        setProductName(productName);
//        setTypeName(typeName);
//        setPrice(price);
//        setProductSalesStartDate(productSalesStartDate);
//        setProdcutSalesEndDate(prodcutSalesEndDate);
//        setProductType(productType);
    }
    
    /**
     * 商品上記constructorに伴い、内部処理を整理(1/13)
     * @author 20jz0132
     * @param productNo
     * @param productName
     * @param typeName
     * @param price
     * @param productSalesStartDate
     * @param prodcutSalesEndDate
     * @param productType 
     */
    public Product(String productNo, String productName, String typeName, int price, Date productSalesStartDate, Date prodcutSalesEndDate, boolean productType) {
        setProductNo(productNo);
        setProductName(productName);
        setTypeName(typeName);
        setPrice(price);
        setProductSalesStartDate(productSalesStartDate);
        setProdcutSalesEndDate(prodcutSalesEndDate);
        setProductType(productType);

//        this(productName, typeName, price, productSalesStartDate, prodcutSalesEndDate, productType);
//        setProductNo(productNo);
    }

    @Override
    public String toString() {
        return getProductNo() + ", " + getProductName() + ", " + getTypeName() + ", " + getPrice() + ", " + getProductSalesStartDate() + ", " + getProdcutSalesEndDate() + ", " + isProductType();
    }

    public void print() {
        System.out.print(toString());
    }
    
    public void println() {
        print();
        System.out.println("");
    }

    public String getProductNo() {
        return productNo;
    }

    public String getProductName() {
        return productName;
    }

    public String getTypeName() {
        return typeName;
    }

    public int getPrice() {
        return price;
    }
    
    public int getTaxPrice() {
        return (int)(price * 1.08);
    }
    
    public int getTax() {
        return (int)(price * 0.08);
    }

    public Date getProductSalesStartDate() {
        return productSalesStartDate;
    }

    public Date getProdcutSalesEndDate() {
        return prodcutSalesEndDate;
    }

    public boolean isProductType() {
        return productType;
    }

    public int getProductType() { //0以外:セット商品　0:単独商品
        return productType ? 1 : 0;
    }

    public void setProductNo(String productNo) {
        this.productNo = productNo;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void setProductSalesStartDate(Date productSalesStartDate) {
        this.productSalesStartDate = productSalesStartDate;
    }

    public void setProdcutSalesEndDate(Date prodcutSalesEndDate) {
        this.prodcutSalesEndDate = prodcutSalesEndDate;
    }

    public void setProductType(boolean productType) {
        this.productType = productType;
    }
    /**
     * (非推奨)int引数の商品のタイプをbooleanでセットする.
     * @deprecated
     * @param productType 0以外:セット商品　0:単独商品
     */
    public void setProductType(int productType) {
        this.productType = productType != 0 ? true : false;
    }
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        List<Product> products = new ArrayList<>();
        
        products.add(new Product());
        products.add(new Product("P001", "ライス", "主食", 300, Date.valueOf(LocalDate.now()) , null, false));
        products.add(new Product("P002", "ポークカレーセット", "セット", 800, Date.valueOf("1999-10-10"), Date.valueOf(LocalDate.now()), true));
        
        for (Product product : products) {
            product.println();
        }
    }
}

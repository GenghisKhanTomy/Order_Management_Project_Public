package model;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * 注文明細テーブルクラス
 * @author 20jz0105
 */
public class OrderDetail {
    private Order order;            //注文
    private int orderDetailCode;   //注文明細番号
    private int quantity;           //個数
    private Product product;        //商品
    private Size size;              //サイズ
    private boolean cancelType;     //取消区分  
    private String note;         //備考ノート

    public OrderDetail() {
        ;
    }

    public OrderDetail(Order order, int orderDetailCode, int quantity, Product product, Size size, String note) {
        setOrder(order);
        setOrderDetailCode(orderDetailCode);
        setQuantity(quantity);
        setProduct(product);
        setSize(size);   
        setNote(note);
    }
    
    public OrderDetail(Order order, int orderDetailCode, int quantity, Product product, Size size, int cancelType, String note) {
        setOrder(order);
        setOrderDetailCode(orderDetailCode);
        setQuantity(quantity);
        setProduct(product);
        setSize(size);
        setCancelType(cancelType);
        setNote(note);
    }

    @Override
    public String toString() {
        return "order[" + getOrder() + "], " + getOrderDetailCode() + ", " + getQuantity() + ", product[" + getProduct() + "], size[" + getSize() + "], " + isCancelType() + ", " + getNote();
    }
    
    public void print() {
        System.out.print(toString());
    }
    
    public void println() {
        print();
        System.out.println("");
    }

    public Order getOrder() {
        return order;
    }

    public int getOrderDetailCode() {
        return orderDetailCode;
    }

    public int getQuantity() {
        return quantity;
    }

    public Product getProduct() {
        return product;
    }

    public Size getSize() {
        return size;
    }

    public boolean isCancelType() {
        return cancelType;
    }

    public String getNote() {
        return note;
    }

    
    
    public void setOrder(Order order) {
        this.order = order;
    }

    public void setOrderDetailCode(int orderDetailCode) {
        this.orderDetailCode = orderDetailCode;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public void setSize(Size size) {
        this.size = size;
    }

    public void setCancelType(boolean cancelType) {
        this.cancelType = cancelType;
    }

    public void setNote(String comment) {
        this.note = comment;
    }
    
    
    /**
     * 非推奨メソッド.
     * @param cancelType 0以外:取消された　0:取消されてない
     */
    public void setCancelType(int cancelType) {
        this.cancelType = cancelType != 0 ? true : false;
    }    
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        List<OrderDetail> orderDetailses = new ArrayList<>();
        
        orderDetailses.add(new OrderDetail());
        orderDetailses.add(new OrderDetail(null, 0, 0, new Product(), new Size(), 0, ""));
        orderDetailses.add(new OrderDetail(new Order(0, null, 0, Timestamp.valueOf(LocalDateTime.now()), 0, new Customer(), null, new ArrayList<OrderDetail>(), null, "火星"), 0, 0, new Product(), null, 0, "テスト"));
                
        for (OrderDetail orderDetails : orderDetailses) {
            orderDetails.println();
        }
    }
}

package model;

import java.util.ArrayList;
import java.util.List;

/**
 * サイズテーブルクラス
 * @author 20jz0105
 */
public class Size {
    private String sizeNo;      //サイズ番号
    private String sizeName;    //サイズ名前
    private int price;          //価格
    
    public Size() {
        ;
    }

    public Size(String sizeNo, String sizeName, int price) {
        setSizeNo(sizeNo);
        setSizeName(sizeName);
        setPrice(price);
        
    }

    @Override
    public String toString() {
        return getSizeNo() + ", " + getSizeName() + ", " + getPrice();
    }
    
    public void print() {
        System.out.print(toString());
    }
    
    public void println() {
        print();
        System.out.println("");
    }
    
    public String getSizeNo() {
        return sizeNo;
    }

    public String getSizeName() {
        return sizeName;
    }

    public int getPrice() {
        return price;
    }

    public void setSizeNo(String sizeNo) {
        this.sizeNo = sizeNo;
    }

    public void setSizeName(String sizeName) {
        this.sizeName = sizeName;
    }

    public void setPrice(int price) {
        this.price = price;
    }
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        List<Size> sizes = new ArrayList<>();
        sizes.add(new Size());
        sizes.add(new Size("S01", "S", -50));
        sizes.add(new Size("S03", "L", 100));
        
        for (Size size : sizes) {
            size.println();
        }
    }
}

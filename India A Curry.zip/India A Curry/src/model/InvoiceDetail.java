package model;

import java.sql.Date;
import java.time.LocalDate;

/**
 * 請求書クラス
 * 　請求書リストクラスに保持される前提で電話番号と名前は持たない
 * @author 20jz0105
 */
public class InvoiceDetail {
    private Date billingDate;
    private int totalFinalyCost;

    public InvoiceDetail() {
    }

    public InvoiceDetail(Date billingDate, int totalFinalyCost) {
        setTotalFinalyCost(totalFinalyCost);
        setBillingDate(billingDate);
    }
    
    @Override
    public String toString() {
        return getBillingDate() + ", " + getTotalFinalyCost();
    }
       
    public void print() {
        System.out.print(toString());
    }
    
    public void println() {
        print();
        System.out.println("");
    }


    public Date getBillingDate() {
        return billingDate;
    }
    
    public LocalDate getBillingLocalDate() {
        return getBillingDate().toLocalDate();
    }

    public int getTotalFinalyCost() {
        return totalFinalyCost;
    }
    
    public Date getLimitDate() {
        return Date.valueOf(getLimitLocalDate());
    }
    
    public LocalDate getLimitLocalDate() {
        return getBillingDate().toLocalDate().plusMonths(1);
    }
    


    public void setBillingDate(Date billingDate) {
        this.billingDate = billingDate;
    }

    public void setTotalFinalyCost(int totalFinalyCost) {
        this.totalFinalyCost = totalFinalyCost;
    }
    
    public static void main(String[] args) {
        System.out.println(new InvoiceDetail());
        System.out.println(new InvoiceDetail(Date.valueOf(LocalDate.now()), 57514));
    }
}

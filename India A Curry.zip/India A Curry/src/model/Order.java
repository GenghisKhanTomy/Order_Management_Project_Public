package model;

import DAO.DualDAO;
import java.sql.Timestamp;
import java.time.LocalDateTime;

import java.util.List;
import java.util.ArrayList;

/**
 * 注文テーブル
 * @author 20jz0105
 */
public class Order {
    private int orderCode;          //注文コード
    private Timestamp orderTimestamp;     //注文年月日+時刻　DB上ではDate
    private int usageReward;        //利用ポイント
    private Timestamp paymentTimestamp;   //入金年月日+時刻　DB上ではDate
    private boolean cancelType;    //取消区分 true:取消された false:取消されてない
    private Customer customer;      //顧客
    private Employee employee;      //従業員
    private List<OrderDetail> orderDetailsList;  //注文明細
    private OrderStatus orderStatus;    //注文状態
    private String address;  //配達先住所  DB上では住所
    
    public Order() {
    }
    
    public Order(Timestamp orderTimestamp, int usageReward, Customer customer, Employee employee, String address) {
        this(new DualDAO().dbSearchSeqOrderNextVal(), orderTimestamp, usageReward, customer, employee, address);
    }
    /**
     * 注文データ登録用コンストラクタ. 
     * @param orderCode
     * @param orderTimestamp
     * @param usageReward
     * @param customer
     * @param employee 
     * @param address 
     */
    public Order(int orderCode, Timestamp orderTimestamp, int usageReward, Customer customer, Employee employee, String address) {
        setOrderCode(orderCode);
        setOrderTimestamp(orderTimestamp);
        setUsageReward(usageReward);
        setCustomer(customer);
        setEmployee(employee);
        setAddress(address);
    }


    public Order(int orderCode, Timestamp orderTimestamp, int usageReward, Timestamp paymentTimestamp, int cancelType, Customer customer, Employee employee, List<OrderDetail> orderDetailsList, OrderStatus orderStatus, String address) {
        setOrderCode(orderCode);
        setOrderTimestamp(orderTimestamp);
        setUsageReward(usageReward);
        setPaymentTimestamp(paymentTimestamp);
        setCancelType(cancelType);
        setCustomer(customer);
        setEmployee(employee);
        setOrderDetailsList(orderDetailsList);
        setOrderStatus(orderStatus);
        setAddress(address);
    }

    @Override
    public String toString() {
        return getOrderCode() + ", " + getOrderTimestamp() + ", " + getUsageReward() + ", " + getPaymentTimestamp() + ", " + isCancelType() + ", customer[" + getCustomer() + "], emploee[" + getEmployee() + "], orderDetails[" + getOrderDetailsList() + "], orderStatus[" + getOrderStatus() + "], " + getAddress();
    }
    
    public void print() {
        System.out.print(toString());
    }
    
    public void println() {
        print();
        System.out.println("");
    }

    public int getOrderCode() {
        return orderCode;
    }

    public Timestamp getOrderTimestamp() {
        return orderTimestamp;
    }

    public int getUsageReward() {
        return usageReward;
    }

    public Timestamp getPaymentTimestamp() {
        return paymentTimestamp;
    }

    public boolean isCancelType() {
        return cancelType;
    }


    public Customer getCustomer() {
        return customer;
    }

    public Employee getEmployee() {
        return employee;
    }

    public List<OrderDetail> getOrderDetailsList() {
        return orderDetailsList;
    }

    public OrderStatus getOrderStatus() {
        return orderStatus;
    }

    public String getAddress() {
        return address;
    }

    public void setOrderCode(int orderCode) {
        this.orderCode = orderCode;
    }

    public void setOrderTimestamp(Timestamp orderTimestamp) {
        this.orderTimestamp = orderTimestamp;
    }

    public void setUsageReward(int usageReward) {
        this.usageReward = usageReward;
    }

    public void setPaymentTimestamp(Timestamp paymentTimestamp) {
        this.paymentTimestamp = paymentTimestamp;
    }

    public void setCancelType(boolean cancelType) {
        this.cancelType = cancelType;
    }
    
    
    /**
     * 非推奨メソッド.
     * @param cancelType 1:取消された　0:取消されてない
     */
    public void setCancelType(int cancelType) {
        this.cancelType = cancelType != 0 ? true : false;
    }
    
    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public void setOrderDetailsList(List<OrderDetail> orderDetailsList) {
        this.orderDetailsList = orderDetailsList;
    }

    public void setOrderStatus(OrderStatus orderStatus) {
        this.orderStatus = orderStatus;
    }

    public void setAddress(String anotherAddress) {
        this.address = anotherAddress;
    }
    
    
    /**
     * 注文明細リストに注文明細を追加.
     * @param orderDetails 
     */
    public void addOrderDetails(OrderDetail orderDetails) {
        orderDetailsList.add(orderDetails);
    }
    /**
     * 注文明細リストから指定した注文明細を削除.
     * @param orderDetails 
     */
    public void removeOrderDetails(OrderDetail orderDetails) {
        orderDetailsList.remove(orderDetails);
    }

    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        List<Order> orderes = new ArrayList<>();
        
        orderes.add(new Order(1, Timestamp.valueOf(LocalDateTime.now()), 0, Timestamp.valueOf("2021-01-12 19:00:56"), 0, null, null, new ArrayList<OrderDetail>(), new OrderStatus(), ""));
        orderes.add(new Order(0x15, Timestamp.valueOf("2020-10-10 20:21:0"), 0, Timestamp.valueOf("2020-11-27 5:30:21"), 1, new Customer(), null, new ArrayList<>(), null, "宇宙"));
        orderes.add(new Order(20, Timestamp.valueOf(LocalDateTime.now()), 0, Timestamp.valueOf(LocalDateTime.now()), 0, new Customer("080-1414-2135", "月", "ルート2", 0, true, new Product(), "1241教室"), new Employee(), null, new OrderStatus(), "日本電子"));
        
        for (Order order : orderes) {
            order.println();
        }
        
//        Order t = new Order();            
//        OrderStatus a = new OrderStatus(t);
//        t.setOrderStatus(a);
//        t.println();          //互いにhs-aなのでStackOverflowErrorになる
    }
}

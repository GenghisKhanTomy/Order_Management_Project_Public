package constant;

/**
 * カテゴリ一覧を持つクラス.
 * @author 20jz0105
 */
public class CategoryList {
    public static final String ALL = "-----";
    public static final String MAIN = "主食";
    public static final String CURRY = "カレー";
    public static final String SET = "セット";
    public static final String TOPPING = "トッピング";
    public static final String SIDE = "サイド";
    
    private CategoryList() {
        
    }
    /**
     * サイズの存在する商品か判定する.
     * @param category
     * @return 
     */
    public static boolean isSizeExists(String category) {
        return MAIN.equals(category) || SET.equals(category);
    }
    public static String[] getCategoryList() {
        return new String[] {MAIN, CURRY, SET, TOPPING, SIDE};
    }
    public static String[] getNonSetCategoryList() {
        return new String[] {MAIN, CURRY, TOPPING, SIDE};
    }
    
}

package constant;

/**
 * 注文状態を数値で表したフィールドを持つクラス
 * @author 20jz0105
 */
public class OrderStatusList {
    public static final int ERROR = -1;
    public static final int ORDER_ACCEPTED = 0;    //受付完了
    public static final int COOKING_START = 1;  //調理開始
    public static final int COOKING_END = 2;    //調理終了
    public static final int DELIVERY_START = 3; //配達開始
    public static final int DELIVERY_END = 4;   //配達終了
    public static final int PAID = 5;    //入金済

    private OrderStatusList() {        
    }
    
    public static String getStringOrderStatus(int orderStatus) {
        String stringOrderStatus;
        switch(orderStatus) {
            case ORDER_ACCEPTED:
                stringOrderStatus = "受付完了";
                break;
            case COOKING_START:
                stringOrderStatus = "調理開始";
                break;
            case COOKING_END:
                stringOrderStatus = "調理終了";
                break;
            case DELIVERY_START:
                stringOrderStatus = "配達開始";
                break;
            case DELIVERY_END:
                stringOrderStatus = "配達終了";
                break;
            case PAID:
                stringOrderStatus = "入金済";
                break;
            default:
                stringOrderStatus = "ERROR";
                break;
        }
        return stringOrderStatus;
    }
    
    public static int getNextOrderStatus(int orderStatus) {
        return orderStatus + 1;
    }
    
    public static int getPrevOrderStatus(int orderStatus) {
        return orderStatus - 1;
    }
    
    public static boolean judgeState(int orderStatus) {
        return ORDER_ACCEPTED <= orderStatus && orderStatus <= PAID;
    }
}

package constant;

/**
 * お金周りの定数を保持するクラス
 * @author 20jz0105
 */
public class MoneyRelation {
    public static final double TAX = 0.08;
    public static final int MIN_ORDER_AMOUNT = 1500;
    public static final int DELIVERY_AMOUNT = 300;
    public static final int BORDER_DELIVERY_FREE = 3000;
    
    public static int getDeliveryAmount(int totalAmount) {
        return totalAmount >= BORDER_DELIVERY_FREE ? 0 : DELIVERY_AMOUNT;
    }
}

package constant;

/**
 * 税率を保持するクラス
 * @author 20jz0105
 */
public class DefineTax {
    public static final double TAX = 0.08;
    
    
}

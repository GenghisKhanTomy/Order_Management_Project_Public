package registerOrderBC;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.table.DefaultTableModel;

/**
 * 注文用テーブルモデル.
 * @author 20jz0105
 */
public class OrderDetailsTableModel extends DefaultTableModel {
    private int productNoColumn;
    private int categoryColumn;
    private int productNameColumn;
    private int priceColumn;
    private int quantityColumn;
    private int subTotalColumn;
    private int noteColumn;
    private int checkColumn;
    private BoundaryRegisterOrder boundaryRegisterOrder;

    public OrderDetailsTableModel(Object[] os, int i) {
        super(os, i);
        for (int column = 0; column < getColumnCount(); column++) {
            if ("".equals(getColumnClass(column))) {
                setCheckColumn(column);
            }
            else if ("商品番号".equals(getColumnName(column))) {
                setProductNoColumn(column);
            }
            else if ("カテゴリ".equals(getColumnName(column))) {
                setCategoryColumn(column);
            }
            else if ("商品名".equals(getColumnName(column))) {
                setProductNameColumn(column);
            }
            else if ("単価".equals(getColumnName(column))) {
                setPriceColumn(column);
            }
            else if ("個数".equals(getColumnName(column))) {
                setQuantityColumn(column);
            }
            else if ("金額".equals(getColumnName(column))) {
                setSubTotalColumn(column);
            }
            else if ("備考ノート".equals(getColumnName(column))) {
                setNoteColumn(column);
            }
        }
    }

    public int getProductNoColumn() {
        return productNoColumn;
    }
    
    public int getPriceColumn() {
        return priceColumn;
    }

    public int getQuantityColumn() {
        return quantityColumn;
    }

    public int getSubTotalColumn() {
        return subTotalColumn;
    }
    
    public int getNoteColumn() {
        return noteColumn;
    }

    public int getProductNameColumn() {
        return productNameColumn;
    }

    public int getCategoryColumn() {
        return categoryColumn;
    }

    public int getCheckColumn() {
        return checkColumn;
    }

    public void setProductNoColumn(int productNoColumn) {
        this.productNoColumn = productNoColumn;
    }
    
    public void setPriceColumn(int price) {
        this.priceColumn = price;
    }
    
    public void setQuantityColumn(int quantityColumn) {
        this.quantityColumn = quantityColumn;
    }

    public void setSubTotalColumn(int subTotalColumn) {
        this.subTotalColumn = subTotalColumn;
    }
    
    public void setNoteColumn(int noteColumn) {
        this.noteColumn = noteColumn;
    }
    
    public void setBoundaryRegisterOrder(BoundaryRegisterOrder boundaryRegisterOrder) {
        this.boundaryRegisterOrder = boundaryRegisterOrder;
    }

    public void setProductNameColumn(int productNameColumn) {
        this.productNameColumn = productNameColumn;
    }

    public void setCategoryColumn(int categoryColumn) {
        this.categoryColumn = categoryColumn;
    }

    public void setCheckColumn(int checkColumn) {
        this.checkColumn = checkColumn;
    }
    
    @Override
    public Class<?> getColumnClass(int column) {
         return column == getCheckColumn() ? Boolean.class : super.getColumnClass(column);
    }
        
    @Override
    public boolean isCellEditable(int row, int column) {
        return column == getQuantityColumn() || column == getNoteColumn() || column == getCheckColumn();
    }
    
    @Override
    public void setValueAt(Object aValue, int row, int column) {
        if (column == getQuantityColumn()) {
            Pattern p = Pattern.compile("^[1-9]\\d*$");
            Matcher m = p.matcher(aValue.toString());
            if (m.matches()) {
                int val = Integer.parseInt(aValue.toString());
                if (val > 9999) {
                    val = 9999;
                }
                super.setValueAt(val, row, column);
                super.setValueAt(val * (int)getValueAt(row, getPriceColumn()), row, getSubTotalColumn());
                boundaryRegisterOrder.calculateTotalAmount();
            }
        }
        else {
            super.setValueAt(aValue, row, column);
        }
    }    

}

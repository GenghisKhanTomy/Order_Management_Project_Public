package registerOrderBC;

import DAO.CustomerDAO;
import DAO.DBManager;
import DAO.DualDAO;
import DAO.MenuViewDAO;
import DAO.OrderDAO;
import DAO.OrderDetailDAO;
import DAO.OrderVoucherViewDAO;
import DAO.ProductDAO;
import DAO.SizeDAO;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import model.Customer;
import model.Employee;
import model.MenuView;
import model.Order;
import model.OrderDetail;
import model.Product;
import model.Size;

/**
 * 注文画面のコントロール
 * @author 20jz0105
 */
public class ControlRegisterOrder extends bcSuper.ControlSuper{
    private BoundaryRegisterOrder boundaryRegisterOrder;
    private BoundaryEditCustomer boundaryEditCustomer;
    private BoundaryEditAddress boundaryEditAddress;
    private BoundaryRegisterIvidualCustomer boundaryRegisterindIvidualCustomer;
    private BoundaryOrderVoucher boundaryOrderVoucher;
    private MenuViewDAO menuViewDAO;
    private List<MenuView> menuViewList;
    private CustomerDAO customerDAO;
    private Customer customer;
    private OrderDAO orderDAO;
    private OrderDetailDAO orderDetailDAO;
    private DualDAO dualDAO;
    private ProductDAO productDAO;
    private SizeDAO sizeDAO;
    private Employee employee;
    private List<Size> sizeList;
    private OrderVoucherViewDAO orderVoucherViewDAO;
    
    /**
     * コンストラクタ.
     */
    public ControlRegisterOrder() {
        boundaryRegisterOrder = new BoundaryRegisterOrder();
        menuViewDAO = new MenuViewDAO();
        customerDAO = new CustomerDAO();
        menuViewList = new ArrayList<>();
        orderDAO = new OrderDAO();
        orderDetailDAO = new OrderDetailDAO();
        dualDAO = new DualDAO();
        productDAO = new ProductDAO();
        sizeDAO = new SizeDAO();
        orderVoucherViewDAO = new OrderVoucherViewDAO();
        
        employee = new Employee();

    }

    public List<Size> getSizeList() {
        return sizeList;
    }
    
    public Size getSize(String name) {
        Size retSize = null;
        for (Size size : sizeList) {
            if (size.getSizeName() == name) {
                retSize = size;
                break;
            }                        
        }
        return retSize;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }
        
    /**
     * 画面起動メソッド.
     */
    public void start() {
        boundaryRegisterOrder.setControl(this);
        sizeList = sizeDAO.dbSearchSizeAll();
        boundaryRegisterOrder.initMenuComboBox();
        boundaryRegisterOrder.setVisibleEditCustomer(employee.isJobType());
        boundaryRegisterOrder.setVisible(true);        
    }
    
    /**
     * システムメニューへの帰還メソッド.
     * @author 20jz0132
     */
    public void exit() {
        boundaryRegisterOrder.setVisible(false);
        boundaryRegisterOrder.clearProductOrder();
        super.getControlSystemMenu().exitContents();
    }
    /**
     * ログイン画面への帰還メソッド.
     */
    public void exitLogout() {
        boundaryRegisterOrder.setVisible(false);
        boundaryRegisterOrder.clearProductOrder();
        super.getControlSystemMenu().exit();
    }
    /**
     * 顧客情報を検索する.
     * @param tel 検索に用いる電話番号
     */
    public void fetchCustomer(String tel) {
        Customer tmpCustomer = customerDAO.dbSearchCustomerTEL(tel);
        if (tmpCustomer != null) {
            customer = tmpCustomer;
            boundaryRegisterOrder.showCustomer(customer);        
        }
        else {
            boundaryRegisterOrder.showErrorDialog("電話番号[" + tel + "]の顧客は登録されていません");
            boundaryRegisterOrder.focusTelNumber();
        }
    }
    /**
     * 配達先住所を入力するダイアログを表示する.
     * 　ダイアログに入力された住所を今回の配達先として更新する
     */
    public void modifyToAnotherAddress() {
        if (boundaryEditAddress == null) {
            boundaryEditAddress = new BoundaryEditAddress(boundaryRegisterOrder, true);
            boundaryEditAddress.setControlRegisterOrder(this);
        }
        boundaryEditAddress.setTextFieldAnotherAddress(customer.getAnotherAddress());
        boundaryEditAddress.setState(false);
        boundaryEditAddress.setVisible(true);
        if (boundaryEditAddress.isState()) {
            boundaryRegisterOrder.modifyCustomerAddress(boundaryEditAddress.getTextFieldAnotherAddress());
        }
    }
    /**
     * 変更する顧客情報を入力するダイアログを表示する.
     * 　ダイアログに入力された情報を基に顧客情報を更新する
     */
    public void updataCustomer() {
        if (boundaryEditCustomer == null) {
            boundaryEditCustomer = new BoundaryEditCustomer(boundaryRegisterOrder, true);
            boundaryEditCustomer.setControlRegisterOrder(this);
        }
        boundaryEditCustomer.setTextCustomerAddress(customer.getCustomerAddress());
        boundaryEditCustomer.setTextCustomerName(customer.getCustomerName());
        boundaryEditCustomer.setTextCustomerTEL(customer.getCustomerTEL());
        boundaryEditCustomer.setState(false);
        boundaryEditCustomer.setVisible(true);
        if (boundaryEditCustomer.isState()) {
            String name = boundaryEditCustomer.getTextCustomerName();
            String TEL = boundaryEditCustomer.getTextCustomerTEL();
            String address = boundaryEditCustomer.getTextCustomerAddress();
            if (customerDAO.dbUpdateNameTELAddress(customer.getCustomerNo(), name, TEL, address) == 1) {                
                boundaryEditCustomer.clearDialog();
                boundaryRegisterOrder.showPlainDialog("顧客情報を変更しました");
                customer.setCustomerName(name);
                customer.setCustomerTEL(TEL);
                customer.setCustomerAddress(address);
                boundaryRegisterOrder.showCustomerTel(customer.getCustomerTEL());
                boundaryRegisterOrder.showCustomer(customer);
            }
            else {
                boundaryRegisterOrder.showErrorDialog("顧客情報の変更に失敗しました");
            }
        }
    }
    /**
     * 登録する顧客情報を入力するダイアログを表示する.
     * 　ダイアログに入力された情報を基に顧客クラスを生成し、DBに登録する
     */
    public void registerIvidualCustomer() {
        if (boundaryRegisterindIvidualCustomer == null) {
            boundaryRegisterindIvidualCustomer = new BoundaryRegisterIvidualCustomer(boundaryRegisterOrder, true);
            boundaryRegisterindIvidualCustomer.setControlRegisterOrder(this);
        }
        boundaryRegisterindIvidualCustomer.setState(false);
        boundaryRegisterindIvidualCustomer.setTelNumber(boundaryRegisterOrder.getTelNumber());
        boundaryRegisterindIvidualCustomer.setVisible(true);
        if (boundaryRegisterindIvidualCustomer.isState()) {
            String customerNo = dualDAO.dbSearchSeqCustomerNextVal();
            String name = boundaryRegisterindIvidualCustomer.getTextCustomerName();
            String TEL = boundaryRegisterindIvidualCustomer.getTextCustomerTEL();
            String address = boundaryRegisterindIvidualCustomer.getTextCustomerAddress();
            Customer tmpCustomer = new Customer(customerNo, TEL, address, name, true);
            if (customerDAO.dbInsertCustomer(tmpCustomer) == 1) {                
                boundaryRegisterindIvidualCustomer.clearDialog();
                boundaryRegisterOrder.showPlainDialog("顧客を登録しました");
                customer = tmpCustomer;
                boundaryRegisterOrder.showCustomerTel(customer.getCustomerTEL());
                boundaryRegisterOrder.showCustomer(customer);

            }
            else {
                boundaryRegisterOrder.showErrorDialog("顧客の登録に失敗しました");
            }

        }
    }
    /**
     * メニューを検索する.
     * @param searchWord 検索ワード
     * @param categoryName  検索カテゴリ
     */
    public void fetchMenu(String searchWord, String categoryName) {
        boundaryRegisterOrder.removeAllMenu();
        
        if (constant.CategoryList.ALL.equals(categoryName) || categoryName == null) {
            menuViewList = menuViewDAO.dbSearchMenuViewNoLikeORNameLike(searchWord);
        }
        else {
            menuViewList = menuViewDAO.dbSearchMenuViewNoLikeORNameLikeType(searchWord, categoryName);        
        }
        for (MenuView menuView : menuViewList) {
            boundaryRegisterOrder.appendMenu(menuView);
        }
    }
    
    void fetchMenu(String categoryName) {
        boundaryRegisterOrder.removeAllMenu();
        
        if (constant.CategoryList.ALL.equals(categoryName)) {
            menuViewList = menuViewDAO.dbSearchMenuViewAll();
        }
        else {
            menuViewList = menuViewDAO.dbSearchMenuViewType(categoryName);
        }
        
        for (MenuView menuView : menuViewList) {
            boundaryRegisterOrder.appendMenu(menuView);
        }
    }
    
    /**
     * 既に最頻商品が注文リストにあるかを探索する.
     * @param size  サイズ情報
     * @param orderDetailsTableModel    注文リスト（テーブルモデル）
     * @return 
     */
    public int getFrequentlyProductExists(Size size, OrderDetailsTableModel orderDetailsTableModel) {
        String prodctNo = customer.getCustomerFrequentlyProduct().getProductNo() + (size != null ? "-" + size.getSizeNo() : "");
        return getProductExists(prodctNo, orderDetailsTableModel);
    }
    /**
     * 既にその商品番号が注文リストにあるかを探索する.
     * @param productNo 商品番号
     * @param orderDetailsTableModel    注文リスト（テーブルモデル）
     * @return 存在する場合は行番号を、存在しない場合は-1を返す
     */
    public int getProductExists(String productNo, OrderDetailsTableModel orderDetailsTableModel) {
        int size = orderDetailsTableModel.getRowCount();
        int idx;
        boolean existsFlag = false;
        for (idx = 0; idx < size; idx++) {
            if (productNo.equals(orderDetailsTableModel.getValueAt(idx, orderDetailsTableModel.getProductNoColumn()))) {
                existsFlag = true;
                break;
            }                
        }
        if (!existsFlag) {
            idx = -1;
        }
        return idx;
    }
    
    /**
     * 商品を注文リストに追加.
     * @param menuView   メニュー情報
     * @param quantity  個数
     */
    public void appendProductOrder(MenuView menuView, int quantity) {
        Object[] rowData = {false, menuView.getProductNo(), menuView.getCategoryName(), menuView.getProductName(),
                            menuView.getTaxPrice(), quantity, 
                            menuView.getTaxPrice() * quantity, ""};
        
        boundaryRegisterOrder.appendProductOrder(rowData, menuView.getTax());
        boundaryRegisterOrder.calculateTotalAmount();
        boundaryRegisterOrder.calculateTaxAmount();
    }

    /**
     * 注文リストの個数の更新及び、それに伴う金額の更新を行う.
     * @param row               行番号
     * @param quantityColumn    個数列の列番号
     * @param quantity          個数
     */
    public void updateProductQuantityOrder(int row, int quantityColumn, int quantity) {
        boundaryRegisterOrder.updateProductOrder(quantity, row, quantityColumn);
        boundaryRegisterOrder.calculateTotalAmount();
    }
    /**
     * 利用ポイントの更新に伴う請求金額の計算を行う.
     */
    public void updateUsedReward() {
        boundaryRegisterOrder.calculateFinalyCost();
    }
    
    /**
     * 最頻商品を注文リストに追加.
     * @param size      サイズ情報
     * @param quantity  個数
     */
    public void appendFrequentlyProductOrder(Size size, int quantity) {        
        MenuView menuView = new MenuView(customer.getCustomerFrequentlyProduct().getProductNo() + (size != null ? "-" + size.getSizeNo() : ""),
                                        customer.getCustomerFrequentlyProduct().getProductName() + (size != null ? size.getSizeName() : ""),
                                         customer.getCustomerFrequentlyProduct().getPrice() + (size != null ? size.getPrice() : 0), customer.getCustomerFrequentlyProduct().getTypeName());
        appendProductOrder(menuView, quantity);
    }
    
    /**
     * 注文リストから指定された行を削除.
     * 　複数削除可能
     * @param deleteRowList 削除する行番号が格納された配列
     */
    public void removeProductOrder(List<Integer> deleteRowList) {
        int size = deleteRowList.size();
        for (int i = size - 1; i >= 0; i--) {
            boundaryRegisterOrder.removeProductOrder(deleteRowList.get(i));
            
        }
        boundaryRegisterOrder.reorganizationTaxMap();
        boundaryRegisterOrder.calculateTotalAmount();
    }
    /**
     * 注文を確定し、注文・注文明細をそれぞれDBに登録する.
     * @param orderDetailsTableModel    注文リスト（テーブルモデル）
     * @param usageReward               利用ポイント
     */
    public void detarmineOrder(OrderDetailsTableModel orderDetailsTableModel, int usageReward, String address) {
        Order order = null;
        try {
            /**
             * 注文作成.
             */
            order = createOrder(usageReward, address);

            /**
             * 注文明細.
             */
            List<OrderDetail> orderDetailList = createOrderDetails(order, orderDetailsTableModel);

            /**
             * DBへの登録処理.
             */
            if (orderDAO.dbInsertOrder(order) != 1) {
                throw new Exception();
            }
            for (OrderDetail orderDetail : orderDetailList) {
                if (orderDetailDAO.dbInsertOrderDetails(orderDetail) != 1) {
                    throw  new Exception();
                }
            }
            if (!address.equals(customer.getCustomerAddress())) {
                customerDAO.dbUpdateAnotherAddress(customer.getCustomerTEL(), address);
            }
            customerDAO.dbUpdateAddReward(customer.getCustomerTEL(), -usageReward);
            boundaryRegisterOrder.showPlainDialog("注文の登録が正常に完了しました");
            if (boundaryOrderVoucher == null) {
                boundaryOrderVoucher = new BoundaryOrderVoucher(boundaryRegisterOrder, true);                
            }
            boundaryOrderVoucher.showOrderVoucherView(orderVoucherViewDAO.dbSearchOrderCode(order.getOrderCode()));
            boundaryOrderVoucher.setVisible(true);
            customer = null;
            boundaryRegisterOrder.clearProductOrder();
            
        }
        catch (Exception e) {
            if (DBManager.getDBManager().getConnection() != null) {
                if (orderDAO != null && order != null) {
                    orderDAO.dbUpdateCancelType(order.getOrderCode(), true);
                }
            }
            boundaryRegisterOrder.showErrorDialog("注文の登録に失敗しました");
        }            
    }
    /**
     * 注文オブジェクトを生成する.
     * @param usageReward   利用ポイント
     * @param address 配達先住所
     * @return 
     */
    public Order createOrder(int usageReward, String address) {
        int orderCode = dualDAO.dbSearchSeqOrderNextVal();
        Timestamp orderDate = Timestamp.valueOf(LocalDateTime.now());
        return new Order(orderCode, orderDate, usageReward, customer, employee, address);
    }
    /**
     * 注文明細オブジェクトのリストを生成する
     * @param order 注文オブジェクト
     * @param orderDetailsTableModel    注文リスト（テーブルモデル）
     * @return 注文明細のリスト
     */
    public List<OrderDetail> createOrderDetails(Order order, OrderDetailsTableModel orderDetailsTableModel) {
        List<OrderDetail> orderDetailseList = new ArrayList<>();
        int rowSize = orderDetailsTableModel.getRowCount();
        String[] array;
        String productNo;
        String sizeNo;
        int quantity;
        String note;
        Product product;
        Size size;
        for (int i = 0; i < rowSize; i++) {
            array = orderDetailsTableModel.getValueAt(i, orderDetailsTableModel.getProductNoColumn()).toString().split("-");
            productNo = array[0];
            if (array.length >= 2) {
                sizeNo = array[1];
            }
            else {
                sizeNo = "";
            }
            quantity = (int)orderDetailsTableModel.getValueAt(i, orderDetailsTableModel.getQuantityColumn());
            note = orderDetailsTableModel.getValueAt(i, orderDetailsTableModel.getNoteColumn()).toString();

            /**
             * 商品情報とサイズ情報をそれぞれ取得してorderDetailsクラスを生成する.
             */
            product = productDAO.dbSearchSaleNo(productNo);
            size = sizeDAO.dbSearchSizeNo(sizeNo);
            orderDetailseList.add(new OrderDetail(order, i + 1, quantity, product, size, note));
                        
        }
        return orderDetailseList;
    }
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        new ControlRegisterOrder().start();
    }
    
    /**
     * 以下非推奨メソッド.
     */
    /**
     * 注文リストを更新.
     * @param value     更新する値
     * @param row       行番号
     * @param column    列番号
     */
    /*
    public void updateProductOrder(int value, int row, int column) {
       boundaryRegisterOrder.updateProductOrder(value, row, column);
    }
    */
}

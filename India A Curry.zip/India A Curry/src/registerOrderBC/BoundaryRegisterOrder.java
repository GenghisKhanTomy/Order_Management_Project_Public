package registerOrderBC;

import dateTimeLabel.DateTimeLabel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableCellRenderer;
import model.Customer;
import model.MenuView;
import model.Size;

/**
 *
 * @author 20jz0132
 */
public class BoundaryRegisterOrder extends bcSuper.BoundarySuper {
    private ControlRegisterOrder controlRegisterOrder;
    private OrderDetailsTableModel orderDetailsTableModel;
    private List<MenuView> menuViewList;
    private Map<Integer, Integer> taxMap;
    private String telNumber;
    private List<Integer> deleteRowList;
    
    /**
     * Creates new form BoundaryRegisterOrder
     */
    public BoundaryRegisterOrder() {
        initComponents();
        setTitle("Indoor A Curry 注文登録");
        jLabelErrorMessage.setText("<html><p style='color : red;'>合計金額が" + constant.MoneyRelation.MIN_ORDER_AMOUNT + "円未満のため注文できません</p></html>");
        menuViewList = new ArrayList<>();
        taxMap = new HashMap<>();
        deleteRowList = new ArrayList<>();
        initTableModel();
        initCustomer();
        initSearch();
        initCategory();
        initCost();        
        setMinimumSize(getSize());//画面サイズの最小値設定
        jTextFieldTelNumber.requestFocusInWindow();
        setIcon(jLabelIcon);
        setLocationRelativeTo(this);
    }

    public void setControl(ControlRegisterOrder controlRegisterOrder) {
        this.controlRegisterOrder = controlRegisterOrder;
    }
    public void setVisibleEditCustomer(boolean tf) {
        jButtonEditCustomer.setVisible(tf);        
    }

    String getTelNumber() {
        return telNumber;
    }

    void setTelNumber(String telNumber) {
        this.telNumber = telNumber;
    }
    
    
    /**
     * 顧客情報が係る画面情報の初期化.
     * @author 20jz0105
     */
    public void initCustomer() {
        jTextFieldTelNumber.setText("");
        jLabelName.setText("");
        jLabelAddress.setText("");
        jButtonChangeAddress.setEnabled(false);
        jButtonEditCustomer.setEnabled(false);
        jLabelFrequencyProductName.setText("");
        jLabelConsumeReward.setText("0");
        SpinnerNumberModel spinnerNumberModel = (SpinnerNumberModel)jSpinnerReward.getModel();
        spinnerNumberModel.setMaximum(0);
        jComboBoxSize.removeAllItems();
        jComboBoxSize.setEnabled(false);
        jSpinnerCount.setEnabled(false);
        jSpinnerReward.setEnabled(false);
        jButtonAddFrequencyProduct.setEnabled(false);
    }
    /**
     * 請求金額に係る画面情報の初期化.
     * @author 20jz0105
     */
    public void initCost() {
        jLabelPrice.setText("0");
        jLabelTax.setText("0");
        jLabelDeliveryAmount.setText(Integer.toString(constant.MoneyRelation.DELIVERY_AMOUNT));
        jLabelCost.setText(Integer.toString(constant.MoneyRelation.DELIVERY_AMOUNT));
        jButtonDetarmineOrder.setEnabled(false);
    }
    
    /**
     * テーブルモデルの初期化と表との連携.
     * @author 20jz0105
     */
    public void initTableModel() {
        
        String[] heading = {"", "商品番号", "カテゴリ", "商品名", "単価", "個数", "金額", "備考ノート"};
        orderDetailsTableModel = new OrderDetailsTableModel(heading, 0);
        orderDetailsTableModel.setBoundaryRegisterOrder(this);
        jTableOrder.getTableHeader().setFont(jTableOrder.getFont());
        jTableOrder.setModel(orderDetailsTableModel);
        DefaultTableCellRenderer rightCellRenderer = new DefaultTableCellRenderer();
        rightCellRenderer.setHorizontalAlignment(JLabel.RIGHT);

        jTableOrder.getColumnModel().getColumn(orderDetailsTableModel.getPriceColumn()).setCellRenderer(rightCellRenderer);
        jTableOrder.getColumnModel().getColumn(orderDetailsTableModel.getQuantityColumn()).setCellRenderer(rightCellRenderer);
        jTableOrder.getColumnModel().getColumn(orderDetailsTableModel.getSubTotalColumn()).setCellRenderer(rightCellRenderer);

        jTableOrder.getColumnModel().getColumn(orderDetailsTableModel.getCheckColumn()).setPreferredWidth(20);
        jTableOrder.getColumnModel().getColumn(orderDetailsTableModel.getProductNoColumn()).setPreferredWidth(80);
        jTableOrder.getColumnModel().getColumn(orderDetailsTableModel.getCategoryColumn()).setPreferredWidth(60);
        jTableOrder.getColumnModel().getColumn(orderDetailsTableModel.getProductNameColumn()).setPreferredWidth(150);
        jTableOrder.getColumnModel().getColumn(orderDetailsTableModel.getPriceColumn()).setPreferredWidth(60);
        jTableOrder.getColumnModel().getColumn(orderDetailsTableModel.getQuantityColumn()).setPreferredWidth(40);
        jTableOrder.getColumnModel().getColumn(orderDetailsTableModel.getSubTotalColumn()).setPreferredWidth(50);
        jTableOrder.getColumnModel().getColumn(orderDetailsTableModel.getNoteColumn()).setPreferredWidth(300);
    }
    
    /**
     * 商品検索関連の初期化.
     * 　検索結果（メニュー）の初期化にはcontrolを用いる都合上別メソッドにする
     * @author 20jz0105
     */
    public void initSearch() {
        initWordTextField();
        jTextFieldSearchedKeyword.setEnabled(false);
        jSpinnerProductCount.setEnabled(false);
        jButtonSearchProduct.setEnabled(false);
        jComboBoxSearchResult.setEnabled(false);
        jComboBoxProductCategory.setEnabled(false);
        jButtonAddProduct.setEnabled(false);
        jButtonRemoveProduct.setEnabled(false);

    }
    /**
     * カテゴリコンボボックス初期化.
     */
    public void initCategory() {
        jComboBoxProductCategory.removeAllItems();
        jComboBoxProductCategory.addItem(constant.CategoryList.ALL);
        String[] categoryNames = constant.CategoryList.getCategoryList();
        for (String categoryName : categoryNames) {
            jComboBoxProductCategory.addItem(categoryName);
        }        
    }
    
    /**
     * メニューコンボボックス初期化.
     * @author 20jz0105
     */
    public void initMenuComboBox() {
        controlRegisterOrder.fetchMenu("", null);
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PCustomer = new javax.swing.JPanel();
        LTelNumber = new javax.swing.JLabel();
        jTextFieldTelNumber = new javax.swing.JTextField();
        jButtonSearchCustomer = new javax.swing.JButton();
        LBorder1 = new javax.swing.JLabel();
        LCustName = new javax.swing.JLabel();
        jLabelName = new javax.swing.JLabel();
        jButtonRegisterCustomer = new javax.swing.JButton();
        LAddress = new javax.swing.JLabel();
        jLabelAddress = new javax.swing.JLabel();
        jButtonChangeAddress = new javax.swing.JButton();
        LFreqProduct = new javax.swing.JLabel();
        jLabelFrequencyProductName = new javax.swing.JLabel();
        jButtonAddFrequencyProduct = new javax.swing.JButton();
        LProductNumber = new javax.swing.JLabel();
        jSpinnerCount = new javax.swing.JSpinner();
        jComboBoxSize = new javax.swing.JComboBox<>();
        LSize = new javax.swing.JLabel();
        jButtonEditCustomer = new javax.swing.JButton();
        PHeader = new javax.swing.JPanel();
        jButtonReturnPage = new javax.swing.JButton();
        LTitle = new javax.swing.JLabel();
        LTimer = new DateTimeLabel("yyyy/MM/dd HH:mm:ss");
        jLabelIcon = new javax.swing.JLabel();
        PRegisterOrder = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableOrder = new javax.swing.JTable();
        LBorder3 = new javax.swing.JLabel();
        jButtonRemoveProduct = new javax.swing.JButton();
        LSearchResult = new javax.swing.JLabel();
        jComboBoxSearchResult = new javax.swing.JComboBox<>();
        LProductCount = new javax.swing.JLabel();
        jButtonAddProduct = new javax.swing.JButton();
        LBorder2 = new javax.swing.JLabel();
        jSpinnerProductCount = new javax.swing.JSpinner();
        PCategorySearch = new javax.swing.JPanel();
        jComboBoxProductCategory = new javax.swing.JComboBox<>();
        LProductCategory = new javax.swing.JLabel();
        PKeywordSearch = new javax.swing.JPanel();
        LSearchProduct = new javax.swing.JLabel();
        jTextFieldSearchedKeyword = new javax.swing.JTextField();
        jButtonSearchProduct = new javax.swing.JButton();
        PSummary = new javax.swing.JPanel();
        LSumFee = new javax.swing.JLabel();
        jLabelPrice = new javax.swing.JLabel();
        LTax = new javax.swing.JLabel();
        jLabelTax = new javax.swing.JLabel();
        LDeliveryAmount = new javax.swing.JLabel();
        jLabelDeliveryAmount = new javax.swing.JLabel();
        LConsumeReward = new javax.swing.JLabel();
        jLabelConsumeReward = new javax.swing.JLabel();
        LReward = new javax.swing.JLabel();
        jSpinnerReward = new javax.swing.JSpinner();
        jButtonDetarmineOrder = new javax.swing.JButton();
        jLabelCost = new javax.swing.JLabel();
        LCost = new javax.swing.JLabel();
        jLabelErrorMessage = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("注文登録画面");
        setMinimumSize(new java.awt.Dimension(1500, 600));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        PCustomer.setBackground(new java.awt.Color(255, 255, 255));
        PCustomer.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        LTelNumber.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        LTelNumber.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LTelNumber.setText("電話番号");

        jTextFieldTelNumber.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jTextFieldTelNumber.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jTextFieldTelNumber.setText("0000");
        jTextFieldTelNumber.setNextFocusableComponent(jButtonSearchCustomer);

        jButtonSearchCustomer.setFont(new java.awt.Font("MS UI Gothic", 0, 14)); // NOI18N
        jButtonSearchCustomer.setText("顧客情報の検索");
        jButtonSearchCustomer.setNextFocusableComponent(jButtonRegisterCustomer);
        jButtonSearchCustomer.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jButtonSearchCustomerFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jButtonSearchCustomerFocusLost(evt);
            }
        });
        jButtonSearchCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSearchCustomerActionPerformed(evt);
            }
        });

        LBorder1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));

        LCustName.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        LCustName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LCustName.setText("顧客名");

        jLabelName.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabelName.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabelName.setAutoscrolls(true);
        jLabelName.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jButtonRegisterCustomer.setFont(new java.awt.Font("MS UI Gothic", 0, 14)); // NOI18N
        jButtonRegisterCustomer.setText("顧客の新規登録");
        jButtonRegisterCustomer.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jButtonRegisterCustomerFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jButtonRegisterCustomerFocusLost(evt);
            }
        });
        jButtonRegisterCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRegisterCustomerActionPerformed(evt);
            }
        });

        LAddress.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        LAddress.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LAddress.setText("住所");

        jLabelAddress.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabelAddress.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabelAddress.setAutoscrolls(true);
        jLabelAddress.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jButtonChangeAddress.setFont(new java.awt.Font("MS UI Gothic", 0, 14)); // NOI18N
        jButtonChangeAddress.setText("配達先の変更");
        jButtonChangeAddress.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jButtonChangeAddressFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jButtonChangeAddressFocusLost(evt);
            }
        });
        jButtonChangeAddress.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonChangeAddressActionPerformed(evt);
            }
        });

        LFreqProduct.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        LFreqProduct.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LFreqProduct.setText("よく頼む商品");

        jLabelFrequencyProductName.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabelFrequencyProductName.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabelFrequencyProductName.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jButtonAddFrequencyProduct.setFont(new java.awt.Font("MS UI Gothic", 0, 16)); // NOI18N
        jButtonAddFrequencyProduct.setText("商品に追加");
        jButtonAddFrequencyProduct.setNextFocusableComponent(jTextFieldSearchedKeyword);
        jButtonAddFrequencyProduct.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jButtonAddFrequencyProductFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jButtonAddFrequencyProductFocusLost(evt);
            }
        });
        jButtonAddFrequencyProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAddFrequencyProductActionPerformed(evt);
            }
        });

        LProductNumber.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        LProductNumber.setText("個数");

        jSpinnerCount.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jSpinnerCount.setModel(new javax.swing.SpinnerNumberModel(1, 1, 100, 1));
        jSpinnerCount.setName(""); // NOI18N

        jComboBoxSize.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jComboBoxSize.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "S", "M", "L" }));

        LSize.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        LSize.setText("サイズ");

        jButtonEditCustomer.setFont(new java.awt.Font("MS UI Gothic", 0, 14)); // NOI18N
        jButtonEditCustomer.setText("顧客情報の変更");
        jButtonEditCustomer.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jButtonEditCustomerFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jButtonEditCustomerFocusLost(evt);
            }
        });
        jButtonEditCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEditCustomerActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PCustomerLayout = new javax.swing.GroupLayout(PCustomer);
        PCustomer.setLayout(PCustomerLayout);
        PCustomerLayout.setHorizontalGroup(
            PCustomerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(LBorder1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(PCustomerLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PCustomerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PCustomerLayout.createSequentialGroup()
                        .addGroup(PCustomerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PCustomerLayout.createSequentialGroup()
                                .addComponent(jButtonRegisterCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(203, 203, 203))
                            .addGroup(PCustomerLayout.createSequentialGroup()
                                .addComponent(LTelNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextFieldTelNumber)
                                .addGap(18, 18, 18)
                                .addComponent(jButtonSearchCustomer, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap())
                    .addGroup(PCustomerLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(PCustomerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PCustomerLayout.createSequentialGroup()
                                .addComponent(LSize, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(18, 18, 18)
                                .addComponent(jComboBoxSize, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(18, 18, Short.MAX_VALUE)
                                .addComponent(LProductNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jSpinnerCount))
                            .addGroup(PCustomerLayout.createSequentialGroup()
                                .addComponent(LFreqProduct)
                                .addGap(4, 4, 4)
                                .addComponent(jLabelFrequencyProductName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(PCustomerLayout.createSequentialGroup()
                                .addComponent(jButtonEditCustomer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(145, 145, 145)
                                .addGroup(PCustomerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jButtonAddFrequencyProduct, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(PCustomerLayout.createSequentialGroup()
                                        .addGap(4, 4, 4)
                                        .addComponent(jButtonChangeAddress, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                        .addGap(23, 23, 23))
                    .addGroup(PCustomerLayout.createSequentialGroup()
                        .addGroup(PCustomerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(LCustName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(LAddress, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(PCustomerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabelAddress, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap())))
        );
        PCustomerLayout.setVerticalGroup(
            PCustomerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PCustomerLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(PCustomerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LTelNumber)
                    .addComponent(jTextFieldTelNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonSearchCustomer))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButtonRegisterCustomer)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(LBorder1)
                .addGap(18, 18, Short.MAX_VALUE)
                .addGroup(PCustomerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(LCustName)
                    .addComponent(jLabelName, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(PCustomerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelAddress, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LAddress))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(PCustomerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonChangeAddress, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButtonEditCustomer))
                .addGap(59, 59, 59)
                .addGroup(PCustomerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabelFrequencyProductName, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LFreqProduct))
                .addGap(18, 18, 18)
                .addGroup(PCustomerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jSpinnerCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LProductNumber)
                    .addComponent(jComboBoxSize, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LSize, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jButtonAddFrequencyProduct, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(43, 43, 43))
        );

        jButtonChangeAddress.getAccessibleContext().setAccessibleDescription("");

        PHeader.setBackground(new java.awt.Color(204, 255, 255));
        PHeader.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jButtonReturnPage.setText("メニュー画面に戻る");
        jButtonReturnPage.setNextFocusableComponent(jTextFieldTelNumber);
        jButtonReturnPage.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jButtonReturnPageFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jButtonReturnPageFocusLost(evt);
            }
        });
        jButtonReturnPage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonReturnPageActionPerformed(evt);
            }
        });

        LTitle.setBackground(new java.awt.Color(255, 255, 255));
        LTitle.setFont(new java.awt.Font("MS UI Gothic", 0, 24)); // NOI18N
        LTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LTitle.setText("注文登録");
        LTitle.setOpaque(true);

        LTimer.setBackground(new java.awt.Color(204, 204, 255));
        LTimer.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        LTimer.setText("yyyy年 mm月 ");

        jLabelIcon.setText("jLabel1");

        javax.swing.GroupLayout PHeaderLayout = new javax.swing.GroupLayout(PHeader);
        PHeader.setLayout(PHeaderLayout);
        PHeaderLayout.setHorizontalGroup(
            PHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PHeaderLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(LTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(106, 106, 106)
                .addGroup(PHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(LTimer)
                    .addComponent(jButtonReturnPage))
                .addGap(18, 18, 18))
        );
        PHeaderLayout.setVerticalGroup(
            PHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PHeaderLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabelIcon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, PHeaderLayout.createSequentialGroup()
                        .addComponent(jButtonReturnPage)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(LTimer))
                    .addComponent(LTitle, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE))
                .addContainerGap())
        );

        PRegisterOrder.setBackground(new java.awt.Color(255, 204, 153));
        PRegisterOrder.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        PRegisterOrder.setRequestFocusEnabled(false);

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        jTableOrder.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jTableOrder.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTableOrder.setRowHeight(20);
        jScrollPane1.setViewportView(jTableOrder);

        LBorder3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));

        jButtonRemoveProduct.setFont(new java.awt.Font("MS UI Gothic", 0, 14)); // NOI18N
        jButtonRemoveProduct.setText("チェックした注文の削除");
        jButtonRemoveProduct.setNextFocusableComponent(jSpinnerReward);
        jButtonRemoveProduct.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jButtonRemoveProductFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jButtonRemoveProductFocusLost(evt);
            }
        });
        jButtonRemoveProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRemoveProductActionPerformed(evt);
            }
        });

        LSearchResult.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        LSearchResult.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LSearchResult.setText("検索結果");

        jComboBoxSearchResult.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N

        LProductCount.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        LProductCount.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LProductCount.setText("個数");

        jButtonAddProduct.setFont(new java.awt.Font("MS UI Gothic", 0, 14)); // NOI18N
        jButtonAddProduct.setText("登録");
        jButtonAddProduct.setNextFocusableComponent(jButtonRemoveProduct);
        jButtonAddProduct.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jButtonAddProductFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jButtonAddProductFocusLost(evt);
            }
        });
        jButtonAddProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAddProductActionPerformed(evt);
            }
        });

        LBorder2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 153, 0)));

        jSpinnerProductCount.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jSpinnerProductCount.setModel(new javax.swing.SpinnerNumberModel(1, 1, 100, 1));

        PCategorySearch.setBackground(new java.awt.Color(255, 153, 102));
        PCategorySearch.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jComboBoxProductCategory.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jComboBoxProductCategory.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBoxProductCategory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxProductCategoryActionPerformed(evt);
            }
        });

        LProductCategory.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        LProductCategory.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LProductCategory.setText("カテゴリを選んで検索");

        javax.swing.GroupLayout PCategorySearchLayout = new javax.swing.GroupLayout(PCategorySearch);
        PCategorySearch.setLayout(PCategorySearchLayout);
        PCategorySearchLayout.setHorizontalGroup(
            PCategorySearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PCategorySearchLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(LProductCategory)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 43, Short.MAX_VALUE)
                .addComponent(jComboBoxProductCategory, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        PCategorySearchLayout.setVerticalGroup(
            PCategorySearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PCategorySearchLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(PCategorySearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBoxProductCategory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LProductCategory, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        PKeywordSearch.setBackground(new java.awt.Color(255, 153, 102));
        PKeywordSearch.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        LSearchProduct.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        LSearchProduct.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LSearchProduct.setText("商品名・番号で検索");

        jTextFieldSearchedKeyword.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jTextFieldSearchedKeyword.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jTextFieldSearchedKeyword.setText("商品名or商品番号");

        jButtonSearchProduct.setFont(new java.awt.Font("MS UI Gothic", 0, 14)); // NOI18N
        jButtonSearchProduct.setText("検索");
        jButtonSearchProduct.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jButtonSearchProductFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jButtonSearchProductFocusLost(evt);
            }
        });
        jButtonSearchProduct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSearchProductActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PKeywordSearchLayout = new javax.swing.GroupLayout(PKeywordSearch);
        PKeywordSearch.setLayout(PKeywordSearchLayout);
        PKeywordSearchLayout.setHorizontalGroup(
            PKeywordSearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PKeywordSearchLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(LSearchProduct)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                .addComponent(jTextFieldSearchedKeyword, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButtonSearchProduct, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        PKeywordSearchLayout.setVerticalGroup(
            PKeywordSearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PKeywordSearchLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PKeywordSearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PKeywordSearchLayout.createSequentialGroup()
                        .addGroup(PKeywordSearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextFieldSearchedKeyword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButtonSearchProduct))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(LSearchProduct, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout PRegisterOrderLayout = new javax.swing.GroupLayout(PRegisterOrder);
        PRegisterOrder.setLayout(PRegisterOrderLayout);
        PRegisterOrderLayout.setHorizontalGroup(
            PRegisterOrderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(LBorder3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(LBorder2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(PRegisterOrderLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PRegisterOrderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PRegisterOrderLayout.createSequentialGroup()
                        .addComponent(LSearchResult, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jComboBoxSearchResult, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(78, 78, 78)
                        .addComponent(LProductCount, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jSpinnerProductCount, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButtonAddProduct, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButtonRemoveProduct, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(PRegisterOrderLayout.createSequentialGroup()
                        .addComponent(PKeywordSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40)
                        .addComponent(PCategorySearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1170, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PRegisterOrderLayout.setVerticalGroup(
            PRegisterOrderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PRegisterOrderLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(PRegisterOrderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(PCategorySearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PKeywordSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(LBorder2)
                .addGap(18, 18, 18)
                .addGroup(PRegisterOrderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LSearchResult)
                    .addComponent(jComboBoxSearchResult, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LProductCount)
                    .addComponent(jButtonAddProduct)
                    .addComponent(jSpinnerProductCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(LBorder3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButtonRemoveProduct)
                .addContainerGap())
        );

        PSummary.setBackground(new java.awt.Color(153, 204, 255));
        PSummary.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        LSumFee.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        LSumFee.setText("合計金額");

        jLabelPrice.setBackground(new java.awt.Color(255, 255, 255));
        jLabelPrice.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabelPrice.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabelPrice.setText("999999");
        jLabelPrice.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabelPrice.setOpaque(true);

        LTax.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        LTax.setText("内消費税額");

        jLabelTax.setBackground(new java.awt.Color(255, 255, 255));
        jLabelTax.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabelTax.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabelTax.setText("9999");
        jLabelTax.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabelTax.setOpaque(true);

        LDeliveryAmount.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        LDeliveryAmount.setText("配達金額");

        jLabelDeliveryAmount.setBackground(new java.awt.Color(255, 255, 255));
        jLabelDeliveryAmount.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabelDeliveryAmount.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabelDeliveryAmount.setText("300");
        jLabelDeliveryAmount.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabelDeliveryAmount.setOpaque(true);

        LConsumeReward.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        LConsumeReward.setText("利用可能ポイント");

        jLabelConsumeReward.setBackground(new java.awt.Color(255, 255, 255));
        jLabelConsumeReward.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabelConsumeReward.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabelConsumeReward.setText("999999");
        jLabelConsumeReward.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabelConsumeReward.setOpaque(true);

        LReward.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        LReward.setText("利用ポイント");

        jSpinnerReward.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jSpinnerReward.setModel(new javax.swing.SpinnerNumberModel(0, 0, 999999, 1));
        jSpinnerReward.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jSpinnerRewardStateChanged(evt);
            }
        });

        jButtonDetarmineOrder.setFont(new java.awt.Font("MS UI Gothic", 0, 14)); // NOI18N
        jButtonDetarmineOrder.setText("注文を確定");
        jButtonDetarmineOrder.setToolTipText("");
        jButtonDetarmineOrder.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jButtonDetarmineOrderFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jButtonDetarmineOrderFocusLost(evt);
            }
        });
        jButtonDetarmineOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonDetarmineOrderActionPerformed(evt);
            }
        });

        jLabelCost.setBackground(new java.awt.Color(255, 255, 255));
        jLabelCost.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jLabelCost.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabelCost.setText("9999999");
        jLabelCost.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jLabelCost.setOpaque(true);

        LCost.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        LCost.setText("請求金額(内税)");

        jLabelErrorMessage.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N

        javax.swing.GroupLayout PSummaryLayout = new javax.swing.GroupLayout(PSummary);
        PSummary.setLayout(PSummaryLayout);
        PSummaryLayout.setHorizontalGroup(
            PSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PSummaryLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(PSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(LSumFee, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(LTax, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 129, Short.MAX_VALUE))
                .addGap(32, 32, 32)
                .addGroup(PSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PSummaryLayout.createSequentialGroup()
                        .addComponent(jLabelPrice, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(LDeliveryAmount, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(32, 32, 32)
                        .addComponent(jLabelDeliveryAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18))
                    .addGroup(PSummaryLayout.createSequentialGroup()
                        .addComponent(jLabelTax, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(364, 364, 364)))
                .addGroup(PSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(LReward, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(LConsumeReward, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(32, 32, 32)
                .addGroup(PSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabelConsumeReward, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jSpinnerReward, javax.swing.GroupLayout.DEFAULT_SIZE, 167, Short.MAX_VALUE))
                .addGroup(PSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PSummaryLayout.createSequentialGroup()
                        .addGroup(PSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(PSummaryLayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(LCost, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(32, 32, 32)
                                .addComponent(jLabelCost, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PSummaryLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButtonDetarmineOrder, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(100, 100, 100))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PSummaryLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabelErrorMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 413, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        PSummaryLayout.setVerticalGroup(
            PSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PSummaryLayout.createSequentialGroup()
                .addGroup(PSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PSummaryLayout.createSequentialGroup()
                        .addContainerGap(20, Short.MAX_VALUE)
                        .addGroup(PSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(LSumFee)
                            .addComponent(jLabelPrice)
                            .addComponent(LDeliveryAmount)
                            .addComponent(jLabelDeliveryAmount))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PSummaryLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(PSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LConsumeReward, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabelConsumeReward)
                                .addComponent(LCost)
                                .addComponent(jLabelCost)))))
                .addGap(18, 18, 18)
                .addGroup(PSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PSummaryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(LTax)
                        .addComponent(jLabelTax)
                        .addComponent(LReward)
                        .addComponent(jSpinnerReward, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabelErrorMessage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jButtonDetarmineOrder, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(PHeader, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(PCustomer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, 0)
                .addComponent(PRegisterOrder, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(PSummary, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(PHeader, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(PCustomer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(PRegisterOrder, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, 0)
                .addComponent(PSummary, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonRegisterCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRegisterCustomerActionPerformed
        setTelNumber(jTextFieldTelNumber.getText());
        controlRegisterOrder.registerIvidualCustomer();
    }//GEN-LAST:event_jButtonRegisterCustomerActionPerformed

    private void jButtonRemoveProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRemoveProductActionPerformed
        int size = orderDetailsTableModel.getRowCount();
        deleteRowList.clear();
        for (int i = 0; i < size; i++) {
            if ((boolean)orderDetailsTableModel.getValueAt(i, orderDetailsTableModel.getCheckColumn())) {
                deleteRowList.add(i);
            }            
        }
        if (deleteRowList.size() > 0) {
            if (showConfirmYesNo("本当に削除しますか？") == JOptionPane.YES_OPTION) {
                controlRegisterOrder.removeProductOrder(deleteRowList);
            }
        }
        else {
            showErrorDialog("削除する商品にチェックをつけてください");
        }

    }//GEN-LAST:event_jButtonRemoveProductActionPerformed

    private void jButtonSearchProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSearchProductActionPerformed
        String word = jTextFieldSearchedKeyword.getText();
        controlRegisterOrder.fetchMenu(word, null);
        jTextFieldSearchedKeyword.setText("");
    }//GEN-LAST:event_jButtonSearchProductActionPerformed

    private void jButtonSearchCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSearchCustomerActionPerformed
        String tel = jTextFieldTelNumber.getText();
        controlRegisterOrder.fetchCustomer(tel);
    }//GEN-LAST:event_jButtonSearchCustomerActionPerformed

    private void jButtonAddProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAddProductActionPerformed
        if (jComboBoxSearchResult.getSelectedIndex() >= 0) {
            MenuView menuView = menuViewList.get(jComboBoxSearchResult.getSelectedIndex());
            String productNo = menuView.getProductNo();
            int idx = controlRegisterOrder.getProductExists(productNo, orderDetailsTableModel);
            if (idx >= 0) {
                int setVal = (int)orderDetailsTableModel.getValueAt(idx, orderDetailsTableModel.getQuantityColumn()) + (int)jSpinnerProductCount.getValue();
                controlRegisterOrder.updateProductQuantityOrder(idx, orderDetailsTableModel.getQuantityColumn(), setVal);                
            }
            else {
                controlRegisterOrder.appendProductOrder(menuView, (int)jSpinnerProductCount.getValue());
            }
            jSpinnerProductCount.setValue(1);
        }
    }//GEN-LAST:event_jButtonAddProductActionPerformed

    private void jButtonAddFrequencyProductActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAddFrequencyProductActionPerformed
        Size size = null;
        if (jComboBoxSize.getSelectedItem() != null) {
            size = controlRegisterOrder.getSize(jComboBoxSize.getSelectedItem().toString());            
        }
        int idx = controlRegisterOrder.getFrequentlyProductExists(size, orderDetailsTableModel);
        if (idx >= 0) {
            int setVal = (int)orderDetailsTableModel.getValueAt(idx, orderDetailsTableModel.getQuantityColumn()) + (int)jSpinnerCount.getValue();
            controlRegisterOrder.updateProductQuantityOrder(idx, orderDetailsTableModel.getQuantityColumn(), setVal);
        }
        else {
            controlRegisterOrder.appendFrequentlyProductOrder(size, (int)jSpinnerCount.getValue());
        }
        jSpinnerCount.setValue(1);
    }//GEN-LAST:event_jButtonAddFrequencyProductActionPerformed

    private void jSpinnerRewardStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSpinnerRewardStateChanged
        if (controlRegisterOrder != null) {
            controlRegisterOrder.updateUsedReward();
        }        
    }//GEN-LAST:event_jSpinnerRewardStateChanged

    private void jButtonDetarmineOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonDetarmineOrderActionPerformed
        if (orderDetailsTableModel.getRowCount() > 0) {
            if (showConfirmYesNo("注文を確定しますか？") == JOptionPane.YES_OPTION) {
                int usageReward = (int)jSpinnerReward.getValue();
                controlRegisterOrder.detarmineOrder(orderDetailsTableModel, usageReward, jLabelAddress.getText());
            }
        }
        else {
            showErrorDialog("注文リストが空です");
            jTextFieldSearchedKeyword.requestFocusInWindow();
        }
    }//GEN-LAST:event_jButtonDetarmineOrderActionPerformed

    private void jButtonChangeAddressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonChangeAddressActionPerformed
        controlRegisterOrder.modifyToAnotherAddress();
    }//GEN-LAST:event_jButtonChangeAddressActionPerformed

    private void jButtonReturnPageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonReturnPageActionPerformed
        controlRegisterOrder.exit();
    }//GEN-LAST:event_jButtonReturnPageActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        controlRegisterOrder.exitLogout();
    }//GEN-LAST:event_formWindowClosing

    private void jButtonEditCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEditCustomerActionPerformed
        controlRegisterOrder.updataCustomer();
    }//GEN-LAST:event_jButtonEditCustomerActionPerformed

    private void jComboBoxProductCategoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxProductCategoryActionPerformed
        if (jComboBoxProductCategory.getSelectedItem() != null && controlRegisterOrder != null) {
            String categoryName = jComboBoxProductCategory.getSelectedItem().toString();
            controlRegisterOrder.fetchMenu(categoryName);
        }
    }//GEN-LAST:event_jComboBoxProductCategoryActionPerformed

    private void jButtonReturnPageFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonReturnPageFocusGained
        getRootPane().setDefaultButton(jButtonReturnPage);
    }//GEN-LAST:event_jButtonReturnPageFocusGained

    private void jButtonReturnPageFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonReturnPageFocusLost
        getRootPane().setDefaultButton(null);
    }//GEN-LAST:event_jButtonReturnPageFocusLost

    private void jButtonSearchCustomerFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonSearchCustomerFocusGained
        getRootPane().setDefaultButton(jButtonSearchCustomer);
    }//GEN-LAST:event_jButtonSearchCustomerFocusGained

    private void jButtonSearchCustomerFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonSearchCustomerFocusLost
        getRootPane().setDefaultButton(null);
    }//GEN-LAST:event_jButtonSearchCustomerFocusLost

    private void jButtonRegisterCustomerFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonRegisterCustomerFocusGained
        getRootPane().setDefaultButton(jButtonRegisterCustomer);
    }//GEN-LAST:event_jButtonRegisterCustomerFocusGained

    private void jButtonRegisterCustomerFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonRegisterCustomerFocusLost
        getRootPane().setDefaultButton(null);
    }//GEN-LAST:event_jButtonRegisterCustomerFocusLost

    private void jButtonEditCustomerFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonEditCustomerFocusGained
        getRootPane().setDefaultButton(jButtonEditCustomer);
    }//GEN-LAST:event_jButtonEditCustomerFocusGained

    private void jButtonEditCustomerFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonEditCustomerFocusLost
        getRootPane().setDefaultButton(null);
    }//GEN-LAST:event_jButtonEditCustomerFocusLost

    private void jButtonChangeAddressFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonChangeAddressFocusGained
        getRootPane().setDefaultButton(jButtonChangeAddress);
    }//GEN-LAST:event_jButtonChangeAddressFocusGained

    private void jButtonChangeAddressFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonChangeAddressFocusLost
        getRootPane().setDefaultButton(null);
    }//GEN-LAST:event_jButtonChangeAddressFocusLost

    private void jButtonAddFrequencyProductFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonAddFrequencyProductFocusGained
        getRootPane().setDefaultButton(jButtonAddFrequencyProduct);
    }//GEN-LAST:event_jButtonAddFrequencyProductFocusGained

    private void jButtonAddFrequencyProductFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonAddFrequencyProductFocusLost
        getRootPane().setDefaultButton(null);
    }//GEN-LAST:event_jButtonAddFrequencyProductFocusLost

    private void jButtonSearchProductFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonSearchProductFocusGained
        getRootPane().setDefaultButton(jButtonSearchProduct);
    }//GEN-LAST:event_jButtonSearchProductFocusGained

    private void jButtonSearchProductFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonSearchProductFocusLost
        getRootPane().setDefaultButton(null);
    }//GEN-LAST:event_jButtonSearchProductFocusLost

    private void jButtonAddProductFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonAddProductFocusGained
        getRootPane().setDefaultButton(jButtonAddProduct);
    }//GEN-LAST:event_jButtonAddProductFocusGained

    private void jButtonAddProductFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonAddProductFocusLost
        getRootPane().setDefaultButton(null);
    }//GEN-LAST:event_jButtonAddProductFocusLost

    private void jButtonRemoveProductFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonRemoveProductFocusGained
        getRootPane().setDefaultButton(jButtonRemoveProduct);
    }//GEN-LAST:event_jButtonRemoveProductFocusGained

    private void jButtonRemoveProductFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonRemoveProductFocusLost
        getRootPane().setDefaultButton(null);
    }//GEN-LAST:event_jButtonRemoveProductFocusLost

    private void jButtonDetarmineOrderFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonDetarmineOrderFocusGained
        getRootPane().setDefaultButton(jButtonDetarmineOrder);
    }//GEN-LAST:event_jButtonDetarmineOrderFocusGained

    private void jButtonDetarmineOrderFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonDetarmineOrderFocusLost
        getRootPane().setDefaultButton(null);
    }//GEN-LAST:event_jButtonDetarmineOrderFocusLost
    /**
     * 電話番号を表示する.
     * @param tel 表示する電話番号
     */
    public void showCustomerTel(String tel) {
        if (tel != null) {
            jTextFieldTelNumber.setText(tel);
        }
        else {
            jTextFieldTelNumber.setText("");
        }
    }
    /**
     * 顧客情報の表示.
     * @param customer 
     * @author 20jz0105
     */
    public void showCustomer(Customer customer) {
        try {
            jLabelName.setText(customer.getCustomerName());
            jLabelAddress.setText(customer.getCustomerAddress());
            jTextFieldSearchedKeyword.setEnabled(true);
            jSpinnerProductCount.setEnabled(true);
            jButtonSearchProduct.setEnabled(true);
            jComboBoxSearchResult.setEnabled(true);
            jComboBoxProductCategory.setEnabled(true);
            jButtonAddProduct.setEnabled(true);
            jButtonChangeAddress.setEnabled(true);
            jButtonRemoveProduct.setEnabled(true);

            if (controlRegisterOrder.getEmployee().isJobType() || (customer.isCustomerType() && !controlRegisterOrder.getEmployee().isJobType())) {
                jButtonEditCustomer.setEnabled(true);
                jButtonEditCustomer.setVisible(true);
            }
            else {
                jButtonEditCustomer.setEnabled(false);
                jButtonEditCustomer.setVisible(false);
            }

            if (customer.isCustomerType()) {
                jLabelConsumeReward.setText(Integer.toString(customer.getCustomerReward()));
                setSpinnerRewardMax();
                jSpinnerReward.setEnabled(true);    
            }
            else {
                jLabelConsumeReward.setText("0");
                setSpinnerRewardMax();
                jSpinnerReward.setEnabled(false);                                
            }

            jComboBoxSize.removeAllItems();            
            if (customer.getCustomerFrequentlyProduct() != null) {
                jLabelFrequencyProductName.setText(customer.getCustomerFrequentlyProduct().getProductName());
                jSpinnerCount.setEnabled(true);
                jButtonAddFrequencyProduct.setEnabled(true);            


                if (constant.CategoryList.MAIN.equals(customer.getCustomerFrequentlyProduct().getTypeName()) || constant.CategoryList.SET.equals(customer.getCustomerFrequentlyProduct().getTypeName())) {

                    List<Size> sizeList = controlRegisterOrder.getSizeList();
                    for (Size size : sizeList) {
                        jComboBoxSize.addItem(size.getSizeName());
                    }
                    jComboBoxSize.setEnabled(true);
                }
                else {
                    jComboBoxSize.setEnabled(false);
                }

            }
            else {
                jLabelFrequencyProductName.setText("");
                jSpinnerCount.setEnabled(false);
                jComboBoxSize.setEnabled(false);
                jButtonAddFrequencyProduct.setEnabled(false);
            }
        }
        catch (NullPointerException e) {
            
        }

    }
    /**
     * 配達先住所を引数の住所に変更する.
     * @param address 変更する住所
     */
    public void modifyCustomerAddress(String address) {
        jLabelAddress.setText(address);
    }
    
    /**
     * ポイントスピナーの最大値設定.
     * 　最大値は利用可能ポイントと請求金額の小さい方の値になる
     */
    public void setSpinnerRewardMax() {
        try {
            SpinnerNumberModel spinnerNumberModel = (SpinnerNumberModel)jSpinnerReward.getModel();
            int min = Math.min(Integer.parseInt(jLabelConsumeReward.getText()), Integer.parseInt(jLabelPrice.getText()) + Integer.parseInt(jLabelDeliveryAmount.getText()));
            spinnerNumberModel.setMaximum(min);
            if (min < (int)spinnerNumberModel.getValue()) {
                spinnerNumberModel.setValue(min);
            }
        }
        catch (ClassCastException e) {            
        }
    }    
    /**
     * 税額Mapに対するput処理.
     * @param key   マップのキー
     * @param value マップのバリュー
     * @author 20jz0105
     */
    public void putTaxMap(int key, int value) {
        taxMap.put(key, value);
    }
    
    /**
     * 注文リストに商品情報を追加する.
     * @param rowData   追加するデータ
     * @author 20jz0105
     */
    public void appendProductOrder(Object[] rowData, int value) {
        putTaxMap(orderDetailsTableModel.getRowCount(), value);
        orderDetailsTableModel.addRow(rowData);
    }
    /**
     * 注文リストを更新する.
     * @param value     更新する値
     * @param row       行番号
     * @param column    列番号
     * @author 20jz0105
     */
    public void updateProductOrder(int value, int row, int column) {
        orderDetailsTableModel.setValueAt(value, row, column);
    }
    /**
     * 注文リストからデータを削除する.
     * @author 20jz0105
     * @param row 削除する行番号
     */
    public void removeProductOrder(int row) {
        orderDetailsTableModel.removeRow(row);
        taxMap.remove(row);
    }
    /**
     * taxMapを再編成する.
     */
    public void reorganizationTaxMap() {
        Map<Integer, Integer> tmpMap = new HashMap<Integer, Integer>();
        int i = 0;
        for (Map.Entry<Integer, Integer> entry : taxMap.entrySet()) {
            tmpMap.put(i, entry.getValue());
            i++;
        }
        taxMap = tmpMap;
    }
    
    /**
     * 合計金額を計算する.
     * @author 20jz0105
     */
    public void calculateTotalAmount() {
        int sum = 0;
        int rowSize = orderDetailsTableModel.getRowCount();
        int subTotalColumn = orderDetailsTableModel.getSubTotalColumn();
        for (int i = 0; i < rowSize; i++) {
            sum += (int)orderDetailsTableModel.getValueAt(i, subTotalColumn);
        }
        boolean lineFlag = sum >= constant.MoneyRelation.MIN_ORDER_AMOUNT;
        
        jButtonDetarmineOrder.setEnabled(lineFlag);
        jLabelErrorMessage.setVisible(!lineFlag);
        
        jLabelPrice.setText(Integer.toString(sum));
        calculateTaxAmount();
        calculateDeliveryAmount();
        setSpinnerRewardMax();
        calculateFinalyCost();
    }
    /**
     * 消費税額を計算する.
     * @author 20jz0105
     */
    public void calculateTaxAmount() {
        int sum = 0;
        int quantityColumn = orderDetailsTableModel.getQuantityColumn();
        for (Map.Entry<Integer, Integer> entry : taxMap.entrySet()) {
            sum += entry.getValue() * (int)orderDetailsTableModel.getValueAt(entry.getKey(), quantityColumn);
        }
        jLabelTax.setText(Integer.toString(sum));
    }
    /**
     * 配達金額を計算する.
     * @author 20jz0105
     */
    public void calculateDeliveryAmount() {
        int deliveryAmount;
        deliveryAmount = constant.MoneyRelation.getDeliveryAmount(Integer.parseInt(jLabelPrice.getText()));
        jLabelDeliveryAmount.setText(Integer.toString(deliveryAmount));
    }
    /**
     * 請求金額を計算する.
     * @author 20jz0105
     */
    public void calculateFinalyCost() {
        int orderCost = Integer.parseInt(jLabelPrice.getText()) + Integer.parseInt(jLabelDeliveryAmount.getText()) - (int)jSpinnerReward.getValue();
        jLabelCost.setText(Integer.toString(orderCost));
        
    }
    
    /**
     * コンボボックスに登録されているメニューのクリア.
     * @author 20jz0105
     */
    public void removeAllMenu() {
        jComboBoxSearchResult.removeAllItems();
        menuViewList.clear();
    }
    
    /**
     * コンボボックスにメニューを追加.
     * @param menuView  追加するメニュー
     * @author 20jz0105
     */
    public void appendMenu(MenuView menuView) {
        menuViewList.add(menuView);
        jComboBoxSearchResult.addItem(menuView.getProductName());        
    }
    /**
     * 注文画面をクリア.
     * @author 20jz0105
     */
    public void clearProductOrder() {
        orderDetailsTableModel.setRowCount(0);
        taxMap.clear();
        clearCustomer();
        calculateTotalAmount();
        jButtonDetarmineOrder.setEnabled(false);
        initSearch();
        jTextFieldTelNumber.requestFocusInWindow();
    }    
    /**
     * 顧客関連のクリア.
     * @author 20jz0105
     */
    public void clearCustomer() {
        initCustomer();
        jButtonEditCustomer.setVisible(controlRegisterOrder.getEmployee().isJobType());        
    }
    /**
     * 電話番号にフォーカスを当てる.
     */
    public void focusTelNumber() {
        jTextFieldTelNumber.requestFocusInWindow();
        jTextFieldTelNumber.selectAll();
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BoundaryRegisterOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BoundaryRegisterOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BoundaryRegisterOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BoundaryRegisterOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BoundaryRegisterOrder().setVisible(true);
            }
        });
    }
    
    /**
     * 検索用フィールドの初期化.
     * @author 20jz0105
     */
    public void initWordTextField() {
        jTextFieldSearchedKeyword.setText("");
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LAddress;
    private javax.swing.JLabel LBorder1;
    private javax.swing.JLabel LBorder2;
    private javax.swing.JLabel LBorder3;
    private javax.swing.JLabel LConsumeReward;
    private javax.swing.JLabel LCost;
    private javax.swing.JLabel LCustName;
    private javax.swing.JLabel LDeliveryAmount;
    private javax.swing.JLabel LFreqProduct;
    private javax.swing.JLabel LProductCategory;
    private javax.swing.JLabel LProductCount;
    private javax.swing.JLabel LProductNumber;
    private javax.swing.JLabel LReward;
    private javax.swing.JLabel LSearchProduct;
    private javax.swing.JLabel LSearchResult;
    private javax.swing.JLabel LSize;
    private javax.swing.JLabel LSumFee;
    private javax.swing.JLabel LTax;
    private javax.swing.JLabel LTelNumber;
    private javax.swing.JLabel LTimer;
    private javax.swing.JLabel LTitle;
    private javax.swing.JPanel PCategorySearch;
    private javax.swing.JPanel PCustomer;
    private javax.swing.JPanel PHeader;
    private javax.swing.JPanel PKeywordSearch;
    private javax.swing.JPanel PRegisterOrder;
    private javax.swing.JPanel PSummary;
    private javax.swing.JButton jButtonAddFrequencyProduct;
    private javax.swing.JButton jButtonAddProduct;
    private javax.swing.JButton jButtonChangeAddress;
    private javax.swing.JButton jButtonDetarmineOrder;
    private javax.swing.JButton jButtonEditCustomer;
    private javax.swing.JButton jButtonRegisterCustomer;
    private javax.swing.JButton jButtonRemoveProduct;
    private javax.swing.JButton jButtonReturnPage;
    private javax.swing.JButton jButtonSearchCustomer;
    private javax.swing.JButton jButtonSearchProduct;
    private javax.swing.JComboBox<String> jComboBoxProductCategory;
    private javax.swing.JComboBox<String> jComboBoxSearchResult;
    private javax.swing.JComboBox<String> jComboBoxSize;
    private javax.swing.JLabel jLabelAddress;
    private javax.swing.JLabel jLabelConsumeReward;
    private javax.swing.JLabel jLabelCost;
    private javax.swing.JLabel jLabelDeliveryAmount;
    private javax.swing.JLabel jLabelErrorMessage;
    private javax.swing.JLabel jLabelFrequencyProductName;
    private javax.swing.JLabel jLabelIcon;
    private javax.swing.JLabel jLabelName;
    private javax.swing.JLabel jLabelPrice;
    private javax.swing.JLabel jLabelTax;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jSpinnerCount;
    private javax.swing.JSpinner jSpinnerProductCount;
    private javax.swing.JSpinner jSpinnerReward;
    private javax.swing.JTable jTableOrder;
    private javax.swing.JTextField jTextFieldSearchedKeyword;
    private javax.swing.JTextField jTextFieldTelNumber;
    // End of variables declaration//GEN-END:variables
}

package DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Customer;

/**
 * 顧客DAO
 * @author 20jz0105
 */
public class CustomerDAO {
    private static Connection con;
    private static PreparedStatement ps;
    
    /**
     * コンストラクタ.
     */
    public CustomerDAO() {
        DBManager dbManager = DBManager.getDBManager();
        con = dbManager.getConnection();   
    }
    /**
     * 問い合わせ結果をCustomerに設定
     * @param customer  問い合わせ結果を格納
     * @param rs        問い合わせ結果
     */
    public void setCustomer(Customer customer, ResultSet rs) {
        try {
            customer.setCustomerNo(rs.getString("customer_no"));
            customer.setCustomerName(rs.getString("name"));
            customer.setCustomerTEL(rs.getString("telephone_no"));
            customer.setCustomerAddress(rs.getString("address"));
            customer.setCustomerReward(rs.getInt("reward"));
            customer.setAnotherAddress(rs.getString("another_address"));
            customer.setCustomerType(rs.getBoolean("customer_type"));
            customer.setCustomerFrequentlyProduct(new ProductDAO().dbSearchNo(rs.getString("frequently_product_no")));
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**
     * 顧客テーブル検索処理実行.
     * @return 検索結果のリスト
     */
    public List<Customer> selectCustomerExceute() {
        List<Customer> customerList = new ArrayList<>();
        try {
            customerList.clear();
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Customer customer = new Customer();
                setCustomer(customer, rs);
                customerList.add(customer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customerList;
    }
    /**
     * 電話番号指定による検索.
     * 　一意キーでの検索のため、returnはListにしない
     * 　検索結果が0件の場合nullを返す
     * @param TEL   電話番号(一意キー)
     * @return      検索結果
     */
    public Customer dbSearchCustomerTEL(String TEL) {
        List<Customer> customerList = new ArrayList<>();//1件しか検索されないためリストにする必要はないがListの方が扱いやすいため
        Customer customer = null;
        String sql = "SELECT * FROM customers WHERE telephone_no = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, TEL);
            customerList = selectCustomerExceute();
            if (customerList.size() == 1) {
                customer = customerList.get(0);
            }
        }        
        catch (SQLException e) {
            e.printStackTrace();
        }
        return customer;
    }
    /**
     * 全件検索.
     * @return 検索結果
     */
    public List<Customer> dbSearchCustomerAll() {
        List<Customer> customerList = new ArrayList<>();
        String sql = "SELECT * FROM customers";
        try {
            ps = con.prepareStatement(sql);
            customerList = selectCustomerExceute();
        }        
        catch (SQLException e) {
            e.printStackTrace();
        }
        return customerList;
    }
    /**
     * 顧客データを1件登録.
     * 　顧客番号、ポイント、配達先住所、最頻注文商品番号はDEFAULT値を利用する
     * @param customer  登録する顧客データ
     * @return          登録件数
     */
    public int dbInsertCustomer(Customer customer) {
        String sql = "INSERT INTO customers(customer_no, name, telephone_no, address, customer_type) VALUES(?, ?, ?, ?, ?)";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, customer.getCustomerNo());
            ps.setString(2, customer.getCustomerName());
            ps.setString(3, customer.getCustomerTEL());
            ps.setString(4, customer.getCustomerAddress());
            ps.setBoolean(5, customer.isCustomerType());
            return ps.executeUpdate();
        }
        catch (SQLIntegrityConstraintViolationException e) {
            return 0;
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
        catch (NullPointerException e) {
            return -1;
        }
    }
    /**
     * 顧客の配達先住所を更新する.
     * @param tel               更新する顧客の電話番号
     * @param anotherAddress    更新する配達先住所
     * @return                  更新件数
     */
    public int dbUpdateAnotherAddress(String tel, String anotherAddress) {
        String sql = "UPDATE customers SET another_address = ? WHERE telephone_no = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, anotherAddress);
            ps.setString(2, tel);
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }

    }
    /**
     * 顧客の名前、電話番号、住所を更新する.
     * @param customerNo　更新する顧客の顧客番号
     * @param name       更新する名前
     * @param tel        更新する電話番号
     * @param address    更新する住所
     * @return                  更新件数
     */
    public int dbUpdateNameTELAddress(String customerNo, String name, String tel, String address) {
        String sql = "UPDATE customers SET name = ?, telephone_no = ?, address = ? WHERE customer_no = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, tel);
            ps.setString(3, address);
            ps.setString(4, customerNo);
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }

    }
    /**
     * 顧客のポイントを加算する.
     * @param tel       更新する顧客の電話番号
     * @param reward    更新するポイント
     * @return          更新件数
     */
    public int dbUpdateAddReward(String tel, int reward) {
        String sql = "UPDATE customers SET reward = reward + ? WHERE telephone_no = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, reward);
            ps.setString(2, tel);
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }

    }

    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) { 
        CustomerDAO customerDAO = new CustomerDAO();
        System.out.println("-----電話番号検索");
        System.out.println("03-3363-7761: " + customerDAO.dbSearchCustomerTEL("03-3363-7761"));        
        System.out.println("000-3363-7761: " + customerDAO.dbSearchCustomerTEL("000-3363-7761"));
                
        System.out.println("-----データ登録");
        System.out.println("電話番号03-3363-7761　登録件数: " + customerDAO.dbInsertCustomer(new Customer("03-3363-7761", "テスト住所1", "NO-NAME", false)));
        System.out.println("電話番号000-3363-7761　登録件数: " + customerDAO.dbInsertCustomer(new Customer("000-3363-7761", "テスト住所2", "TEST-NAME", true)));
        
        System.out.println("-----配達先住所更新");
        System.out.println("電話番号03-3363-7761　更新件数: " + customerDAO.dbUpdateAnotherAddress("03-3363-7761", "UPDATE住所1"));
        System.out.println("電話番号222-2222-7777　更新件数: " + customerDAO.dbUpdateAnotherAddress("22-2222-7777", "UPDATE住所2"));
        
        System.out.println("-----ポイント更新");
        System.out.println("電話番号03-3333-9999　更新件数: " + customerDAO.dbUpdateAddReward("03-3363-7761", 123));
        System.out.println("電話番号000-3363-7761　更新件数: " + customerDAO.dbUpdateAddReward("000-3363-7761", 0));
        
        System.out.println("-----全件検索");
        List<Customer> customerList = customerDAO.dbSearchCustomerAll();
        for (Customer customer : customerList) {
            customer.println();
        }
        
//        System.out.println("-----最頻注文商品番号更新");
//        System.out.println("電話番号03-3363-7761　更新件数: " + customerDAO.dbUpdateFrequentlyProduct("03-3363-7761", "P00002"));
//        System.out.println("電話番号012-9923-8942　更新件数: " + customerDAO.dbUpdateFrequentlyProduct("012-9923-8942", ""));
        

    }
    
    
    /**
     * 非推奨・未使用メソッド.
     */
    /**
     * 顧客の最頻注文商品番号を更新する.
     * @param tel       更新する顧客の電話番号
     * @param productNo 更新する最頻注文商品番号
     * @return          更新件数
     */
    /*
    public int dbUpdateFrequentlyProduct(String tel, String productNo) {
        String sql = "UPDATE customers SET frequently_product_no = ? WHERE telephone_no = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, productNo);
            ps.setString(2, tel);
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }*/
}

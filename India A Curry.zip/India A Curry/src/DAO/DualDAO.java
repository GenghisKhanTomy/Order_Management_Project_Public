package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * dual表用のDAO
 * @author 20jz0105
 */
public class DualDAO {
    private static Connection con;
    private static PreparedStatement ps;
    
    /**
     * コンストラクタ.
     * 　データベース接続情報設定
     */
    public DualDAO() {
        DBManager dbManager = DBManager.getDBManager();
        con = dbManager.getConnection();  
    }
    /**
     * シーケンスの問い合せ結果を取得.
     * @return シーケンスの値
     */
    public int selectSeqExceute() {
        int Seq = -1;
        try {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {//検索結果は１行である前提
                Seq = rs.getInt("val");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Seq;
    }
    /**
     * 文字列化したシーケンスの問い合せ結果を取得.
     * @return シーケンスの値
     */
    public String selectStrSeqExceute() {
        String Seq = "";
        try {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {//検索結果は１行である前提
                Seq = rs.getString("val");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Seq;
    }
    /**
     * 注文番号シーケンスの次の値を取得.
     * @return シーケンスの次の値
     */
    public int dbSearchSeqOrderNextVal() {
        int nextVal = -1;
        String sql = "SELECT seq_order.nextval AS val FROM dual";

        try {
            ps = con.prepareStatement(sql);
            nextVal = selectSeqExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return nextVal;
    }
    /**
     * 従業員番号シーケンスの次の値を取得.
     * @return シーケンスの次の値
     */
    public int dbSearchSeqEmployeeNextVal() {
        int nextVal = -1;
        String sql = "SELECT seq_employee.nextval AS val FROM dual";

        try {
            ps = con.prepareStatement(sql);
            nextVal = selectSeqExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return nextVal;
    }
    /**
     * 商品番号シーケンスの次の値を取得.
     * @author 20jz0132
     * @return シーケンスの次の値
     */
    public String dbSearchSeqProductNextVal() {
        int nextVal = -1;
        String sql = "SELECT seq_product.nextval AS val FROM dual";

        try {
            ps = con.prepareStatement(sql);
            nextVal = selectSeqExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return nextVal != -1 ? String.format("P%05d", nextVal) : new String("*");
    }
    /**
     * 顧客番号シーケンスの次の値を取得.
     * @author 20jz0132
     * @return シーケンスの次の値
     */
    public String dbSearchSeqCustomerNextVal() {
        int nextVal = -1;
        String sql = "SELECT seq_customer.nextval AS val FROM dual";

        try {
            ps = con.prepareStatement(sql);
            nextVal = selectSeqExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return nextVal != -1 ? String.format("C%05d", nextVal) : new String("*");
    }    
    /**
     * (非推奨)商品番号シーケンスの現在の値を取得.
     * @deprecated
     * @author 20jz0132
     * @return  シーケンスの現在の値
     */
    public String dbSearchSeqProductCurrVal() {
        int currVal = -1;
        String sql = "SELECT seq_product.currval AS val FROM dual";

        try {
            ps = con.prepareStatement(sql);
            currVal = selectSeqExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return currVal != -1 ? String.format("P%05d", currVal) : new String("*");
    }
    /**
     * 従業員番号シーケンスの次の値を取得.
     * @return シーケンスの次の値
     */
    public String dbSearchStrSeqEmployeeNextVal() {
        String nextVal = "";
        String sql = "SELECT CONCAT('E', LPAD(seq_employee.nextval, 5, '0')) AS val FROM dual";

        try {
            ps = con.prepareStatement(sql);
            nextVal = selectStrSeqExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return nextVal;
    }    
    
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        DualDAO dualDAO = new DualDAO();
//        System.out.println("seq_order next : " + dualDAO.dbSearchSeqOrderNextVal());
//        System.out.println("seq_order curr :" + dualDAO.dbSearchSeqOrderCurrVal());
//        System.out.println("seq_order curr :" + dualDAO.dbSearchSeqOrderCurrVal());
//        System.out.println("seq_order next : " + dualDAO.dbSearchSeqOrderNextVal());
//        System.out.println("seq_order curr :" + dualDAO.dbSearchSeqOrderCurrVal());
        
//        System.out.println("seq_employee next : " + dualDAO.dbSearchSeqEmployeeNextVal());
//        System.out.println("seq_employee next : " + dualDAO.dbSearchSeqEmployeeNextVal());

//        System.out.println("seq_employee next : " + dualDAO.dbSearchSeqEmployeeNextVal());
//        System.out.println("seq_employee next : " + dualDAO.dbSearchSeqEmployeeNextVal());

//        System.out.println(dualDAO.dbSearchSeqProductNextVal());
//        System.out.println(dualDAO.dbSearchSeqProductCurrVal());
        
        System.out.println("文字列化 seq_employee next : " + dualDAO.dbSearchStrSeqEmployeeNextVal());
        System.out.println("文字列化 seq_employee next : " + dualDAO.dbSearchStrSeqEmployeeNextVal());


    }


    /**
     * 以下のメソッドは非推奨及び使用予定のないもの.
     */
    /**
     * 注文番号シーケンスの現在の値を取得.
     * @return  シーケンスの現在の値
     */
    /*
    public int dbSearchSeqOrderCurrVal() {
        int currVal = -1;
        String sql = "SELECT seq_order.currval AS val FROM dual";

        try {
            ps = con.prepareStatement(sql);
            currVal = selectSeqExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return currVal;
    }*/
    /**
     * 従業員番号シーケンスの現在の値を取得.
     * @return  シーケンスの現在の値
     */
    /*
    public int dbSearchSeqEmployeeCurrVal() {
        int currVal = -1;
        String sql = "SELECT seq_employee.currval AS val FROM dual";

        try {
            ps = con.prepareStatement(sql);
            currVal = selectSeqExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return currVal;
    }*/
    /**
     * DBで数値型でも文字列取得できるのかのテスト　→　結果：可能
     * @return 
     */
    /*
    public String test() {
        String seq = "";
        String sql = "SELECT seq_order.nextval AS val FROM dual";

        try {
            ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {//検索結果は１行である前提
                seq = rs.getString("val");
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return seq;
    }*/
}

package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.InvoiceView;
import model.InvoiceDetail;

/**
 * 請求書DAO
 * @author 20jz0105
 */
public class InvoiceViewDAO {
    private static Connection con;
    private static PreparedStatement ps;
    /**
     * コンストラクタ.
     * 　データベース接続情報設定
     */
    public InvoiceViewDAO() {
        DBManager dbManager = DBManager.getDBManager();
        con = dbManager.getConnection();  
    }
    /**
     * 問い合わせ結果をInvoiceViewに設定
     * @param invoiceDetail  問い合わせ結果を格納
     * @param rs        問い合わせ結果
     */
    public void setInvoiceDetail(InvoiceDetail invoiceDetail, ResultSet rs) {
        try {
            invoiceDetail.setBillingDate(rs.getDate("billing_date"));
            invoiceDetail.setTotalFinalyCost(rs.getInt("total_finaly_cost"));
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**
     * 問い合わせ結果をInvoiceListに設定
     * @param invoiceView  問い合わせ結果を格納
     * @param rs        問い合わせ結果
     */
    public void setInvoiceView(InvoiceView invoiceView, ResultSet rs) {
        try {
            invoiceView.setCustomerNo(rs.getString("customer_no"));
            invoiceView.setCustomerTEL(rs.getString("telephone_no"));
            invoiceView.setCustomerName(rs.getString("name"));
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }    
    
    /**
     * 請求書ビュー検索処理実行.
     * 　検索結果を格納したリストを持つクラスを返す
     * 　検索結果が0ならnullを返す
     * @return 検索結果のリスト
     */
    public InvoiceView selectInvoiceViewExceute() {
        InvoiceView invoiceView = null;;
        try {
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                invoiceView = new InvoiceView();
                setInvoiceView(invoiceView, rs);
                do {
                    InvoiceDetail invoiceDetail = new InvoiceDetail();
                    setInvoiceDetail(invoiceDetail, rs);
                    invoiceView.addInvoiceDetail(invoiceDetail);
                } while (rs.next());
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return invoiceView;
    }
    /**
     * 電話番号による検索.
     * @param TEL   電話番号
     * @return      検索結果
     */
    public InvoiceView dbSearchInvoiceViewNo(String TEL) {
        InvoiceView invoiceView = null;
        String sql = "SELECT * FROM invoice_view WHERE telephone_no = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, TEL);
            invoiceView = selectInvoiceViewExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return invoiceView;
    }
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        InvoiceViewDAO invoiceDAO = new InvoiceViewDAO();
        
        System.out.println("電話番号検索");
        
        System.out.println("電話番号 100-200-300");
        System.out.println(invoiceDAO.dbSearchInvoiceViewNo("100-200-300"));
        
        System.out.println("電話番号 111-222-333");
        System.out.println(invoiceDAO.dbSearchInvoiceViewNo("111-222-333"));

    }
}

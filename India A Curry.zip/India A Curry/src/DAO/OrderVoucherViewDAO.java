package DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import model.OrderVoucherDetail;
import model.OrderVoucherView;

/**
 * 注文伝票ビューDAO
 * @author 20jz0105
 */
public class OrderVoucherViewDAO {
    private static Connection con;
    private static PreparedStatement ps;

    public OrderVoucherViewDAO() {
        DBManager dbManager = DBManager.getDBManager();
        con = dbManager.getConnection();  
    }

    /**
     * 問い合わせ結果をOrderVoucherDetailMapに設定.
     * @param orderVoucherDetailMap  問い合わせ結果を格納
     * @param rs 問い合わせ結果
     */
    public boolean setOrderVoucherDetail(Map<String, List<OrderVoucherDetail>> orderVoucherDetailMap, ResultSet rs) {
        boolean nextFlag = false;
        try {    
            int prevOrderCode = rs.getInt("order_code");
            do {
                if (prevOrderCode != rs.getInt("order_code")) {
                    nextFlag = true;
                    break;
                }
                OrderVoucherDetail orderVoucherDetail = new OrderVoucherDetail();
                orderVoucherDetail.setOrderDetailCode(rs.getInt("order_detail_code"));
                orderVoucherDetail.setProductNo(rs.getString("product_no"));
                orderVoucherDetail.setProductName(rs.getString("product_name"));
                orderVoucherDetail.setPrice(rs.getInt("price"));
                orderVoucherDetail.setQuantity(rs.getInt("quantity"));
                orderVoucherDetail.setRewardMagnification(rs.getDouble("reward_magnification"));
                orderVoucherDetail.setNote(rs.getString("note"));
                String type_name = rs.getString("type_name");
                if (!orderVoucherDetailMap.containsKey(type_name)) {
                    orderVoucherDetailMap.put(type_name, new ArrayList<>());
                }
                orderVoucherDetailMap.get(type_name).add(orderVoucherDetail);
            } while (rs.next());
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return nextFlag;
    }
    
    /**
     * 問い合わせ結果をOrderVoucherViewに設定.
     * @param orderVoucherView  問い合わせ結果を格納
     * @param rs        問い合わせ結果
     */
    public boolean setOrderVoucherView(OrderVoucherView orderVoucherView, ResultSet rs) {
        boolean nextFlag = false;
        try {
            orderVoucherView.setOrderCode(rs.getInt("order_code"));
            orderVoucherView.setOrderTimestamp(rs.getTimestamp("order_date"));
            orderVoucherView.setUsageReward(rs.getInt("usage_reward"));
            orderVoucherView.setAddress(rs.getString("address"));
            orderVoucherView.setCustomerName(rs.getString("customer_name"));
            orderVoucherView.setCustomerTEL(rs.getString("telephone_no"));
            orderVoucherView.setCustomerReward(rs.getInt("reward"));
            orderVoucherView.setCustomerType(rs.getBoolean("customer_type"));
            nextFlag = setOrderVoucherDetail(orderVoucherView.getOrderVoucherDetailMap(), rs);
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return nextFlag;
    }
    /**
     * 注文伝票ビュー検索処理実行.
     * @return 検索結果のリスト
     */
    public List<OrderVoucherView> selectOrderVoucherViewExceute() {
        List<OrderVoucherView> orderVoucherViewList = new ArrayList<>();
        boolean nextFlag;
        try {
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                do {                    
                    OrderVoucherView orderVoucherView = new OrderVoucherView();
                    nextFlag = setOrderVoucherView(orderVoucherView, rs);
                    orderVoucherViewList.add(orderVoucherView);
                } while (nextFlag);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orderVoucherViewList;
    }
    
    
    /**
     * 注文コードによる検索.
     * 　一意となる値での検索のため、returnはListにしない
     * 　検索結果が0件の場合、nullを返す
     * @param orderCode
     * @return 検索結果
     */
    public OrderVoucherView dbSearchOrderCode(int orderCode) {
        List<OrderVoucherView> OrderVoucherViewList = new ArrayList<>();
        OrderVoucherView orderVoucherView = null;
        String sql = "SELECT * FROM order_voucher_view WHERE order_code = ? ORDER BY order_detail_code";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, orderCode);
            OrderVoucherViewList = selectOrderVoucherViewExceute();
            if (OrderVoucherViewList.size() == 1) {
                orderVoucherView = OrderVoucherViewList.get(0);
            }
        }        
        catch (SQLException e) {
            e.printStackTrace();
        }
        return orderVoucherView;
    }
    /**
     * 電話番号による検索.
     * @param TEL 電話番号
     * @param start 範囲検索：対象開始日
     * @param end 範囲検索：対象終了日
     * @return 検索結果
     */
    public List<OrderVoucherView> dbSearchTELOrderDate(String TEL, Date start, Date end) {
        List<OrderVoucherView> OrderVoucherViewList = new ArrayList<>();
        String sql = "SELECT * FROM order_voucher_view WHERE telephone_no = ? AND order_date BETWEEN ? AND ? ORDER BY order_code, order_detail_code";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, TEL);
            ps.setDate(2, start);
            ps.setDate(3, end);
            OrderVoucherViewList = selectOrderVoucherViewExceute();
        }        
        catch (SQLException e) {
            e.printStackTrace();
        }
        return OrderVoucherViewList;
    }   
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        OrderVoucherViewDAO orderVoucherViewDAO = new OrderVoucherViewDAO();
        
        System.out.println("注文コード 88 : " + orderVoucherViewDAO.dbSearchOrderCode(88));
        System.out.println("注文コード 100 : " + orderVoucherViewDAO.dbSearchOrderCode(100));
        
        System.out.println("電話番号 100-200-300 : " + orderVoucherViewDAO.dbSearchTELOrderDate("100-200-300", Date.valueOf(LocalDate.MIN), Date.valueOf(LocalDate.MAX)));
        System.out.println("電話番号 11-22-33 : " + orderVoucherViewDAO.dbSearchTELOrderDate("11-22-33", Date.valueOf(LocalDate.now().minusYears(1)), Date.valueOf(LocalDate.now())));
        
        
    }
    
    
    
    /**
     * 全件検索.
     * @return 検索結果
     */
    /*
    public List<OrderVoucherView> dbSearchAll() {
        List<OrderVoucherView> OrderVoucherViewList = new ArrayList<>();
        String sql = "SELECT * FROM order_voucher_view WHERE order_code = ?";
        try {
            ps = con.prepareStatement(sql);
            OrderVoucherViewList = selectOrderVoucherViewExceute();
        }        
        catch (SQLException e) {
            e.printStackTrace();
        }
        return OrderVoucherViewList;
    }*/
}

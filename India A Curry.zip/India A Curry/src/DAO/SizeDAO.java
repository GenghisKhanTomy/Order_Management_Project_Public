/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Size;

/**
 * サイズDAO
 * @author 20jz0105
 */
public class SizeDAO {
    private static Connection con;
    private static PreparedStatement ps;
    
    /**
     * コンストラクタ.
     * 　データベース接続情報設定
     */
    public SizeDAO() {
        DBManager dbManager = DBManager.getDBManager();
        con = dbManager.getConnection();  
    }
    
    /**
     * 問い合わせ結果をSizeに設定
     * @param size  問い合わせ結果を格納
     * @param rs        問い合わせ結果
     */
    public void setSize(Size size, ResultSet rs) {
        try {
            size.setSizeNo(rs.getString("size_no"));
            size.setSizeName(rs.getString("name"));
            size.setPrice(rs.getInt("price"));
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**
     * サイズテーブル検索処理実行.
     * @return 検索結果のリスト
     */
    public List<Size> selectSizeExceute() {
        List<Size> sizeList = new ArrayList<>();
        try {
            sizeList.clear();
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Size size = new Size();
                setSize(size, rs);
                sizeList.add(size);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sizeList;
    }
    /**
     * サイズ番号による検索.
     * 　一意キーでの検索のため、returnはListにしない
     * 　検索結果が0件の場合nullを返す
     * @param sizeNo   サイズ番号(一意キー)
     * @return      検索結果
     */
    public Size dbSearchSizeNo(String sizeNo) {
        List<Size> sizeList = new ArrayList<>();
        Size size = null;
        String sql = "SELECT * FROM sizes WHERE size_no = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, sizeNo);
            sizeList = selectSizeExceute();
            if (sizeList.size() == 1) {
                size = sizeList.get(0);
            }
        }        
        catch (SQLException e) {
            e.printStackTrace();
        }
        return size;
    }
    /**
     * サイズの全件検索.
     * @return      検索結果
     */
    public List<Size> dbSearchSizeAll() {
        List<Size> sizeList = new ArrayList<>();
        String sql = "SELECT * FROM sizes ORDER BY size_no";
        try {
            ps = con.prepareStatement(sql);
            sizeList = selectSizeExceute();            
        }        
        catch (SQLException e) {
            e.printStackTrace();
        }
        return sizeList;
    }
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        SizeDAO sizeDAO = new SizeDAO();

        System.out.println("全件検索");
        List<Size> sizeList = sizeDAO.dbSearchSizeAll();
        for (Size size : sizeList) {
            System.out.println(size);
        }
        
        System.out.println("番号検索");
        System.out.println("番号 : S1\n" + sizeDAO.dbSearchSizeNo("S1"));
        System.out.println("");
        System.out.println("番号 : S3\n" + sizeDAO.dbSearchSizeNo("S3"));

    }
}

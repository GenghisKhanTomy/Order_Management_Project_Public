package DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import model.Customer;
import model.Employee;
import model.Order;

/**
 * 注文DAO
 * @author 20jz0105
 */
public class OrderDAO {
    private static Connection con;
    private static PreparedStatement ps;

    /**
     * コンストラクタ.
     * 　データベース接続情報設定
     */
    public OrderDAO() {
        DBManager dbManager = DBManager.getDBManager();
        con = dbManager.getConnection();  
    }
    
    /**
     * 注文データを1件登録.
     * 　注文コード、注文年月日時分、利用ポイント、顧客番号、従業員番号、配達先住所を登録する
     * @param order     登録する顧客データ
     * @return          登録件数
     */
    public int dbInsertOrder(Order order) {
        String sql = "INSERT INTO orders(order_code, order_date, usage_reward, customer_no, employee_no, address) VALUES(?, ?, ?, ?, ?, ?)";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, order.getOrderCode());
            ps.setTimestamp(2, order.getOrderTimestamp());
            ps.setInt(3, order.getUsageReward());
            ps.setString(4, order.getCustomer().getCustomerNo());
            ps.setString(5, order.getEmployee().getEmployeeNo());
            ps.setString(6, order.getAddress());
            return ps.executeUpdate();
        }
        catch (SQLIntegrityConstraintViolationException e) {
            e.printStackTrace();
            return 0;
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
        catch (NullPointerException e) {
            e.printStackTrace();
            return -1;
        }
    }
    /**
     * 注文の取消区分を更新.
     * 　0→1、1→0どちらも可能
     * @param orderCode         更新する注文の注文コード
     * @param cancelType        更新する取消区分
     * @return                  更新件数
     */
    public int dbUpdateCancelType(int orderCode, boolean cancelType) {
        String sql = "UPDATE orders SET cancel_type = ? WHERE order_code = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setBoolean(1, cancelType);
            ps.setInt(2, orderCode);
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }
    
    /**
     * 注文の入金年月日時分を更新.
     * @param orderCode         更新する注文の注文コード
     * @param paymentTimestamp       更新する注文年月日時分
     * @return                  更新件数
     */
    public int dbUpdatePaymentDate(int orderCode, Timestamp paymentTimestamp) {
        String sql = "UPDATE orders SET payment_date = ? WHERE order_code = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setTimestamp(1, paymentTimestamp);
            ps.setInt(2, orderCode);
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }
    /**
     * 特定の期間の顧客の注文を全て入金する
     * @param customerNo   顧客番号
     * @param paymentTimestamp  入金年月日
     * @param start　開始日
     * @param end   終了日
     * @return 
     */
    public int dbUpdatePaymentDateStartEnd(String customerNo, Timestamp paymentTimestamp, Date start, Date end) {
        String sql = "UPDATE orders SET payment_date = ? WHERE customer_no = ? AND order_date BETWEEN ? AND ? AND cancel_type = 0";
        try {
            ps = con.prepareStatement(sql);
            ps.setTimestamp(1, paymentTimestamp);
            ps.setString(2, customerNo);
            ps.setDate(3, start);
            ps.setDate(4, end);
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }
    /**
     * 複数の注文の入金年月日時分を更新.
     * @param orderCodeList         更新する注文の注文コード
     * @param paymentTimestamp       更新する注文年月日時分
     * @return                  更新件数
     */
    public int dbMultiUpdatePaymentDate(List<Integer> orderCodeList, Timestamp paymentTimestamp) {
        if (orderCodeList.size() > 0) {
            StringBuilder sqlBuilder = new StringBuilder("UPDATE orders SET payment_date = ? WHERE order_code IN (");
            int size = orderCodeList.size();
            for (int i = 1; i <= size; i++) {
                sqlBuilder.append("?");
                if (i != size) {
                    sqlBuilder.append(", ");
                }
            }
            sqlBuilder.append(")");
            String sql = sqlBuilder.toString();
            try {
                ps = con.prepareStatement(sql);
                ps.setTimestamp(1, paymentTimestamp);
                for (int i = 0; i < size; i++) {
                    ps.setInt(i + 2, orderCodeList.get(i));
                }
                return ps.executeUpdate();
            }
            catch (SQLException e) {
                e.printStackTrace();
                return -1;
            }
        }
        else {
            return -1;
        }
    }    
    
    
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        OrderDAO orderDAO = new OrderDAO();
        
        System.out.println("-----データ登録");
        System.out.println("登録件数: " + orderDAO.dbInsertOrder(new Order(1, Timestamp.valueOf(LocalDateTime.now()), 0, new Customer("C0001", "03-3363-7761", "東京都新宿区百人町1-25-4", "日本電子専門学校", 0, false, null, "i専門職大学"), new Employee("E999", "豊福", "toyofuku", 1, Date.valueOf("1800-10-01"), "080-xxxx-yyyy", "東京都千代田区1-2-3", true, true), "東京都千代田区1-2-3")));
        System.out.println("登録件数: " + orderDAO.dbInsertOrder(new Order(new DualDAO().dbSearchSeqOrderNextVal(), Timestamp.valueOf(LocalDateTime.now()), 0, new CustomerDAO().dbSearchCustomerTEL("03-3363-7761"), new Employee("E00001", "豊福", "toyofuku", 1, Date.valueOf("1800-10-01"), "080-xxxx-yyyy", "東京都千代田区1-2-3", true, true), "マリアナ海溝")));
        
        System.out.println("-----配達先住所更新");
        System.out.println("注文コード 1　更新件数: " + orderDAO.dbUpdateCancelType(1, true));
        System.out.println("注文コード 491　更新件数: " + orderDAO.dbUpdateCancelType(491, false));
        
        System.out.println("-----ポイント更新");
        System.out.println("注文コード 2　更新件数: " + orderDAO.dbUpdatePaymentDate(2, Timestamp.valueOf(LocalDateTime.now())));
        System.out.println("注文コード " + new DualDAO().dbSearchSeqOrderNextVal() + " 更新件数: " + orderDAO.dbUpdatePaymentDate(new DualDAO().dbSearchSeqOrderNextVal(), Timestamp.valueOf("2020-01-22 10:33:44.00")));
        
        System.out.println("-----入金日登録");
        System.out.println("注文コード 1　更新件数: " + orderDAO.dbUpdatePaymentDate(1, null));
        System.out.println("注文コード 491　更新件数: " + orderDAO.dbUpdatePaymentDate(491, Timestamp.valueOf(LocalDateTime.now())));

        System.out.println("-----入金日一括登録");
        System.out.println("電話番号 1-2-3　更新件数: " + orderDAO.dbUpdatePaymentDate(1, null));
        System.out.println("電話番号 100-200-300　更新件数: " + orderDAO.dbUpdatePaymentDate(491, Timestamp.valueOf(LocalDateTime.now())));

    }
    
    
    
    
    
    /**
     * 注文の取消区分を更新.
     * 　取消状態にする更新
     * @param orderCode         更新する注文の注文コード
     * @return                  更新件数
     */
    /*
    public int dbUpdateCancelType(int orderCode) {
        String sql = "UPDATE orders SET cancel_type = 1 WHERE order_code = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, orderCode);
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }
    */
    
    //    /**
//     * 問い合わせ結果をOrderに設定
//     * @param order  問い合わせ結果を格納
//     * @param rs        問い合わせ結果
//     */
//    public void setOrder(Order order, ResultSet rs) {
//        try {
////                private int orderCode;          //注文コード
////    private Timestamp orderTimestamp;     //注文年月日+時刻　DB上ではDate
////    private int usageReward;        //利用ポイント
////    private Timestamp paymentTimestamp;   //入金年月日+時刻　DB上ではDate
////    private boolean cancelType;    //取消区分 true:取消された false:取消されてない
////    private Customer customer;      //顧客
////    private Employee employee;      //従業員
////    private List<OrderDetail> orderDetailsList;  //注文明細
////    private OrderStatus orderStatus;    //注文状態
////    private String address;  //配達先住所  DB上では住所
//            order.setOrderCode(rs.getInt("order_code"));
//            order.setOrderTimestamp(rs.getTimestamp("order_date"));
//            order.setUsageReward(rs.getInt("usage_reward"));
//            order.setPaymentTimestamp(rs.getTimestamp("payment_date"));
//            order.setCancelType(rs.getBoolean("cancel_type"));
//            
//            order.setAddress(rs.getString("address"));
//        }
//        catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//    /**
//     * 注文結合ビュー検索処理実行.
//     * @return 検索結果のリスト
//     */
//    public List<Order> selectOrderExceute() {
//        List<Order> orderList = new ArrayList<>();
//        try {
//            orderList.clear();
//            ResultSet rs = ps.executeQuery();
//            while (rs.next()) {
//                Order order = new Order();
//                setOrder(order, rs);
//                orderList.add(order);
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return orderList;
//    }
//    /**
//     * 注文コードによる検索.
//     * 　一意となる値での検索のため、returnはListにしない
//     * 　検索結果が0件の場合、nullを返す
//     * @param orderCode
//     * @return 検索結果
//     */
//    public Order dbSearchOrderCode(int orderCode) {
//        List<Order> orderList = new ArrayList<>();
//        Order order = null;
//        String sql = "SELECT * FROM order_join_view WHERE order_code = ?";
//        try {
//            ps = con.prepareStatement(sql);
//            ps.setInt(1, orderCode);
//            orderList = selectOrderExceute();
//            if (orderList.size() == 1) {
//                order = orderList.get(0);
//            }
//        }        
//        catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return order;
//    }
//    /**
//     * 全件検索. 　
//     * @return 検索結果のリスト
//     */
//    public List<Order> dbSearchOrderJoinAll() {
//        List<Order> orderList = new ArrayList<>();
//        String sql = "SELECT * FROM order_join_view";
//        try {
//            ps = con.prepareStatement(sql);
//            orderList = selectOrderExceute();
//        }        
//        catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return orderList;
//    }
    
    
}

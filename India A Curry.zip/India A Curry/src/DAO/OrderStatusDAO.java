package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import model.OrderStatus;

/**
 * 注文状態DAO
 * @author 20jz0105
 */
public class OrderStatusDAO {
    private static Connection con;
    private static PreparedStatement ps;
    /**
     * コンストラクタ接続情報.
     */
    public OrderStatusDAO() {
        DBManager dbManager = DBManager.getDBManager();
        con = dbManager.getConnection();  
    }

    
    
    /**
     * 注文状態の調理開始年月日時分の更新.
     * @param orderCode             更新対象の注文コード
     * @param cookingStartTimestamp 更新する値
     * @return 
     */
    public int dbUpdateCookingStartTimestamp(int orderCode, Timestamp cookingStartTimestamp) {
        String sql = "UPDATE order_status SET cooking_start_date = ? WHERE order_code = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setTimestamp(1, cookingStartTimestamp);
            ps.setInt(2, orderCode);
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }
    /**
     * 注文状態の調理終了年月日時分の更新.
     * @param orderCode             更新対象の注文コード
     * @param cookingEndTimestamp   更新する値
     * @return 
     */
    public int dbUpdateCookingEndTimestamp(int orderCode, Timestamp cookingEndTimestamp) {
        String sql = "UPDATE order_status SET cooking_end_date = ? WHERE order_code = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setTimestamp(1, cookingEndTimestamp);
            ps.setInt(2, orderCode);
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }
    /**
     * 注文状態の配達開始年月日時分の更新.
     * @param orderCode                 更新対象の注文コード
     * @param deliveryStartTimestamp    更新する値
     * @return 
     */
    public int dbUpdateDeliveryStartTimestamp(int orderCode, Timestamp deliveryStartTimestamp) {
        String sql = "UPDATE order_status SET delivery_start_date = ? WHERE order_code = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setTimestamp(1, deliveryStartTimestamp);
            ps.setInt(2, orderCode);
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }
    /**
     * 注文状態の配達終了年月日時分の更新.
     * @param orderCode             更新対象の注文コード
     * @param deliveryEndTimestamp  更新する値
     * @return 
     */
    public int dbUpdateDeliveryEndTimestamp(int orderCode, Timestamp deliveryEndTimestamp) {
        String sql = "UPDATE order_status SET delivery_end_date = ? WHERE order_code = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setTimestamp(1, deliveryEndTimestamp);
            ps.setInt(2, orderCode);
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        
    }
    
    
    //    /**
//     * 問い合わせ結果をOrderStatusに設定
//     * @param orderStatus  問い合わせ結果を格納
//     * @param rs        問い合わせ結果
//     */
//    public void setOrderStatus(OrderStatus orderStatus, ResultSet rs) {
//        try {
////            orderStatus.setOrder(rs.getInt("order_code"));
//            orderStatus.setCookingStartTimestamp(rs.getTimestamp("cooking_start_date"));
//            orderStatus.setCookingEndTimestamp(rs.getTimestamp("cooking_end_date"));
//            orderStatus.setDeliveryStartTimestamp(rs.getTimestamp("delivery_start_date"));
//            orderStatus.setDeliveryEndTimestamp(rs.getTimestamp("delivery_end_date"));
//            orderStatus.setPaymentTimestamp(rs.getTimestamp("payment_date"));
//        }
//        catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//    /**
//     * 注文結合ビュー検索処理実行.
//     * @return 検索結果のリスト
//     */
//    public List<OrderStatus> selectOrderStatusExceute() {
//        List<OrderStatus> orderStatusList = new ArrayList<>();
//        try {
//            orderStatusList.clear();
//            ResultSet rs = ps.executeQuery();
//            while (rs.next()) {
//                OrderStatus orderStatus = new OrderStatus();
//                setOrderStatus(orderStatus, rs);
//                orderStatusList.add(orderStatus);
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return orderStatusList;
//    }
//    /**
//     * 注文コードによる検索.
//     * 　一意となる値での検索のため、returnはListにしない
//     * 　検索結果が0件の場合、nullを返す
//     * @param orderCode
//     * @return 検索結果
//     */
//    public OrderStatus dbSearchOrderStatusCode(int orderCode) {
//        List<OrderStatus> orderStatusList = new ArrayList<>();
//        OrderStatus orderStatus = null;
//        String sql = "SELECT * FROM order_join_view WHERE order_code = ?";
//        try {
//            ps = con.prepareStatement(sql);
//            ps.setInt(1, orderCode);
//            orderStatusList = selectOrderStatusExceute();
//            if (orderStatusList.size() == 1) {
//                orderStatus = orderStatusList.get(0);
//            }
//        }        
//        catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return orderStatus;
//    }
//    /**
//     * 全件検索. 　
//     * @return 検索結果のリスト
//     */
//    public List<OrderStatus> dbSearchOrderJoinAll() {
//        List<OrderStatus> orderStatusList = new ArrayList<>();
//        String sql = "SELECT * FROM order_join_view";
//        try {
//            ps = con.prepareStatement(sql);
//            orderStatusList = selectOrderStatusExceute();
//        }        
//        catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return orderStatusList;
//    }
}

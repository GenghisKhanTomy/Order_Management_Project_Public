package DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import model.Employee;
import model.Order;
import model.OrderDetail;
import model.Product;
import model.Size;

/**
 * 注文DAO
 * @author 20jz0105
 */
public class OrderDetailDAO {
    private static Connection con;
    private static PreparedStatement ps;
    
    /**
     * コンストラクタ.
     * 　データベース接続情報設定
     */
    public OrderDetailDAO() {
        DBManager dbManager = DBManager.getDBManager();
        con = dbManager.getConnection();  
    }
    /**
     * 注文明細テーブルに対する集計関数を利用したSELECT文の実行.
     * @return 検索結果
     */
    public List<Integer> selectGroupExceute() {
        List<Integer> groupList = new ArrayList<>();
        try {
            groupList.clear();
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                groupList.add(rs.getInt("group_val"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return groupList;
    }
    /**
     * 注文データの登録.
     * 　注文コード、個数、商品番号、サイズ番号を登録する
     * @param orderDetail  注文明細データ
     * @return              登録件数
     */
    public int dbInsertOrderDetails(OrderDetail orderDetail) {
        String sql = "INSERT INTO order_details(order_code, order_detail_code, quantity, product_no, size_no, note) VALUES(?, ?, ?, ?, ?, ?)";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, orderDetail.getOrder().getOrderCode());
            ps.setInt(2, orderDetail.getOrderDetailCode());
            ps.setInt(3, orderDetail.getQuantity());
            ps.setString(4, orderDetail.getProduct().getProductNo());
            if (orderDetail.getSize() != null) {
                ps.setString(5, orderDetail.getSize().getSizeNo());
            }
            else {
                ps.setString(5, "");
            }
            ps.setString(6, orderDetail.getNote());
            return ps.executeUpdate();
        }
        catch (SQLIntegrityConstraintViolationException e) {
            e.printStackTrace();
            return 0;
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
        catch (NullPointerException e) {//hs-aの関係のため一応
            e.printStackTrace();
            return -1;
        }
    }
    /**
     * 注文明細の取消区分を更新.
     * @param orderCode         注文コード
     * @param orderDetailCode   注文明細コード
     * @param cancelType        取消区分
     * @return 
     */
    public int dbUpdateCancelType(int orderCode, int orderDetailCode, boolean cancelType) {
        String sql = "UPDATE order_details SET cancel_type = ? WHERE order_code = ? AND order_detail_code = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setBoolean(1, cancelType);
            ps.setInt(2, orderCode);
            ps.setInt(3, orderDetailCode);
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }
    
    /**
     * 取り消されていない注文明細データの数を検索
     * @param orderCode 検索条件である注文コード
     * @return データ数
     */
    public Integer dbCountOrderDetails(int orderCode) {
        String sql = "SELECT COUNT(*) AS group_val FROM order_details WHERE order_code = ? AND cancel_type = 0";
        Integer count = -1;
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, orderCode);
            List<Integer> countList = selectGroupExceute();
            if (countList.size() == 1) {
                count = countList.get(0);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }
    /**
     * 注文明細の個数を更新
     * @param orderCode 注文コード
     * @param orderDetailCode   注文明細コード
     * @param quantity  個数
     * @return  更新件数
     */    
    public int dbUpdateQuantity(int orderCode, int orderDetailCode, int quantity) {
        String sql = "UPDATE order_details SET quantity = ? WHERE order_code = ? AND order_detail_code = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, quantity);
            ps.setInt(2, orderCode);
            ps.setInt(3, orderDetailCode);
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }
    /**
     * 注文明細の個数を更新
     * @param orderCode 注文コード
     * @param productNo   商品番号
     * @param sizeNo   サイズ番号
     * @param quantity  個数
     * @return  更新件数
     */
    public int dbUpdateQuantity(int orderCode, String productNo, String sizeNo, int quantity) {
        String sql = "UPDATE order_details SET quantity = ? WHERE order_code = ? AND product_no = ? AND size_no = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, quantity);
            ps.setInt(2, orderCode);
            ps.setString(3, productNo);
            ps.setString(4, sizeNo);
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }
    
    public static void main(String[] args) {
        OrderDetailDAO orderDetailDAO = new OrderDetailDAO();
        
        System.out.println("-----注文明細登録");
        System.out.println("登録件数 : " + orderDetailDAO.dbInsertOrderDetails(new OrderDetail(new Order(1, Timestamp.valueOf(LocalDateTime.now()), 0, new CustomerDAO().dbSearchCustomerTEL("03-3363-7761"), new Employee("E00001", "豊福", "toyofuku", 1, Date.valueOf("1800-10-01"), "080-xxxx-yyyy", "東京都千代田区1-2-3", true, true), "東京都千代田区1-2-3"), 1, 2, new ProductDAO().dbSearchNo("P00001"), new Size("S1", "L", 100), "")));
        System.out.println("登録件数 : " + orderDetailDAO.dbInsertOrderDetails(new OrderDetail(null, 3, 1, new Product(), new Size(), "肉抜き")));
        
        System.out.println("-----注文取消");
        System.out.println("更新件数 : " + orderDetailDAO.dbUpdateCancelType(1, 2, true));
        System.out.println("更新件数 : " + orderDetailDAO.dbUpdateCancelType(1, 1, false));

        System.out.println("-----注文数更新");
        System.out.println("更新件数 : " + orderDetailDAO.dbUpdateQuantity(1, 3, 1));
        System.out.println("更新件数 : " + orderDetailDAO.dbUpdateQuantity(1, 2, 3));
        
//        System.out.println("更新件数 : " + orderDetailDAO.dbUpdateQuantity(1, "P00003", "S1", 1));
//        System.out.println("更新件数 : " + orderDetailDAO.dbUpdateQuantity(1, "P00003", "S2", 3));
        
        System.out.println("-----集計データ集計");
        System.out.println("注文コード 1 件数 : " + orderDetailDAO.dbCountOrderDetails(1));
        System.out.println("注文コード 2 件数 : " + orderDetailDAO.dbCountOrderDetails(2));
    }
    
    


}

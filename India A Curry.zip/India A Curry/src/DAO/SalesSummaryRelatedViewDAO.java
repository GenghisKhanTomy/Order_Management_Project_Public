package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * 売上サマリーDAO
 * @author 20jz0105
 */
public class SalesSummaryRelatedViewDAO {
    private static Connection con;
    private static PreparedStatement ps;
    
    public SalesSummaryRelatedViewDAO() {
        DBManager dbManager = DBManager.getDBManager();
        con = dbManager.getConnection();
    }
    /**
     * 売上サマリー集計実行.
     * 　集計の軸には文字列型を用いる
     * @return 集計結果のマップ key=集計の軸 value=合計値
     */
    public Map<String, Integer> selectSummaryGroupExceute() {
        Map<String, Integer> groupMap = new HashMap<>();
        try {
            groupMap.clear();
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                groupMap.put(rs.getString("key"), rs.getInt("value"));
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return groupMap;
    }

    /**
     * 曜日を軸とした売上サマリー集計.
     * @return 集計結果のマップ key=集計の軸 value=合計値
     */
    public Map<String, Integer> dbSelectGroupDays() {
        Map<String, Integer> groupMap = new HashMap<>();
        String sql = "SELECT days AS key, SUM(price) AS value FROM sales_summary_related_view GROUP BY days ORDER BY days";

        try {
            ps = con.prepareStatement(sql);
            groupMap = selectSummaryGroupExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return groupMap;
    }
    
    /**
     * 月を軸とした売上サマリー集計.
     * @return 集計結果のマップ key=集計の軸 value=合計値
     */
    public Map<String, Integer> dbSelectGroupMonth() {
        Map<String, Integer> groupMap = new HashMap<>();
        String sql = "SELECT month AS key, SUM(price) AS value FROM sales_summary_related_view GROUP BY month ORDER BY month";

        try {
            ps = con.prepareStatement(sql);
            groupMap = selectSummaryGroupExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return groupMap;
    }
    /**
     * 日を軸とした売上サマリー集計.
     * @return 集計結果のマップ key=集計の軸 value=合計値
     */
    public Map<String, Integer> dbSelectGroupDay() {
        Map<String, Integer> groupMap = new HashMap<>();
        String sql = "SELECT day AS key, SUM(price) AS value FROM sales_summary_related_view GROUP BY day ORDER BY day";

        try {
            ps = con.prepareStatement(sql);
            groupMap = selectSummaryGroupExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return groupMap;
    }
    /**
     * 時を軸とした売上サマリー集計.
     * @return 集計結果のマップ key=集計の軸 value=合計値
     */
    public Map<String, Integer> dbSelectGroupHour() {
        Map<String, Integer> groupMap = new HashMap<>();
        String sql = "SELECT hour AS key, SUM(price) AS value FROM sales_summary_related_view GROUP BY hour ORDER BY hour";

        try {
            ps = con.prepareStatement(sql);
            groupMap = selectSummaryGroupExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return groupMap;
    }
    /**
     * 曜日を軸とした売上サマリー集計.
     * 　集計範囲の指定あり
     * @param start 集計対象となるデータの開始日
     * @param end   集計対象となるデータの終了日
     * @return 
     */
    public Map<String, Integer> dbSelectGroupDaysBetween(Timestamp start, Timestamp end) {
        Map<String, Integer> groupMap = new HashMap<>();
        String sql = "SELECT days AS key, SUM(price) AS value FROM sales_summary_related_view WHERE group_date BETWEEN ? AND ? GROUP BY days ORDER BY days";
        try {
            ps = con.prepareStatement(sql);
            ps.setTimestamp(1, start);
            ps.setTimestamp(2, end);
            groupMap = selectSummaryGroupExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return groupMap;
    }
    
    /**
     * 月を軸とした売上サマリー集計.
     * 　集計範囲の指定あり
     * @param start 集計対象となるデータの開始日
     * @param end   集計対象となるデータの終了日
     * @return 集計結果のマップ key=集計の軸 value=合計値
     */
    public Map<String, Integer> dbSelectGroupMonthBetween(Timestamp start, Timestamp end) {
        Map<String, Integer> groupMap = new HashMap<>();
        String sql = "SELECT month AS key, SUM(price) AS value FROM sales_summary_related_view WHERE group_date BETWEEN ? AND ? GROUP BY month ORDER BY month";

        try {
            ps = con.prepareStatement(sql);
            ps.setTimestamp(1, start);
            ps.setTimestamp(2, end);
            groupMap = selectSummaryGroupExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return groupMap;
    }
    /**
     * 日を軸とした売上サマリー集計.
     * 　集計範囲の指定あり
     * @param start 集計対象となるデータの開始日
     * @param end   集計対象となるデータの終了日
     * @return 集計結果のマップ key=集計の軸 value=合計値
     */
    public Map<String, Integer> dbSelectGroupDayBetween(Timestamp start, Timestamp end) {
        Map<String, Integer> groupMap = new HashMap<>();
        String sql = "SELECT day AS key, SUM(price) AS value FROM sales_summary_related_view WHERE group_date BETWEEN ? AND ? GROUP BY day ORDER BY day";

        try {
            ps = con.prepareStatement(sql);
            ps.setTimestamp(1, start);
            ps.setTimestamp(2, end);
            groupMap = selectSummaryGroupExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return groupMap;
    }
    /**
     * 時を軸とした売上サマリー集計.
     * 　集計範囲の指定あり
     * @param start 集計対象となるデータの開始日
     * @param end   集計対象となるデータの終了日
     * @return 集計結果のマップ key=集計の軸 value=合計値
     */
    public Map<String, Integer> dbSelectGroupHourBetween(Timestamp start, Timestamp end) {
        Map<String, Integer> groupMap = new HashMap<>();
        String sql = "SELECT hour AS key, SUM(price) AS value FROM sales_summary_related_view WHERE group_date BETWEEN ? AND ? GROUP BY hour ORDER BY hour";

        try {
            ps = con.prepareStatement(sql);
            ps.setTimestamp(1, start);
            ps.setTimestamp(2, end);
            groupMap = selectSummaryGroupExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return groupMap;
    }
    
    public static void main(String[] args) {
        SalesSummaryRelatedViewDAO salesSummaryDAO = new SalesSummaryRelatedViewDAO();
        Map<String, Integer> groupMap = new HashMap<>();

        System.out.println("曜日で集計");
        groupMap = salesSummaryDAO.dbSelectGroupDays();
        for (Map.Entry<String, Integer> entry : groupMap.entrySet()) {
            String key = entry.getKey();
            Integer value = entry.getValue();
            System.out.println(key + ", "+ value);
        }
        
        System.out.println("月で集計");
        groupMap = salesSummaryDAO.dbSelectGroupMonth();
        for (Map.Entry<String, Integer> entry : groupMap.entrySet()) {
            String key = entry.getKey();
            Integer value = entry.getValue();
            System.out.println(key + ", "+ value);
        }

        System.out.println("日で集計");
        groupMap = salesSummaryDAO.dbSelectGroupDay();
        for (Map.Entry<String, Integer> entry : groupMap.entrySet()) {
            String key = entry.getKey();
            Integer value = entry.getValue();
            System.out.println(key + ", "+ value);
        }

        System.out.println("時間で集計");
        groupMap = salesSummaryDAO.dbSelectGroupHour();
        for (Map.Entry<String, Integer> entry : groupMap.entrySet()) {
            String key = entry.getKey();
            Integer value = entry.getValue();
            System.out.println(key + ", "+ value);
        }

        System.out.println("曜日で集計　範囲指定あり");
        groupMap = salesSummaryDAO.dbSelectGroupDaysBetween(Timestamp.valueOf("2019-05-01 01:02:03.123456789"), Timestamp.valueOf(LocalDateTime.now()));
        for (Map.Entry<String, Integer> entry : groupMap.entrySet()) {
            String key = entry.getKey();
            Integer value = entry.getValue();
            System.out.println(key + ", "+ value);
        }
        
        System.out.println("月で集計　範囲指定あり");
        groupMap = salesSummaryDAO.dbSelectGroupMonthBetween(Timestamp.valueOf("2019-05-01 01:02:03.123456789"), Timestamp.valueOf(LocalDateTime.now()));
        for (Map.Entry<String, Integer> entry : groupMap.entrySet()) {
            String key = entry.getKey();
            Integer value = entry.getValue();
            System.out.println(key + ", "+ value);
        }

        System.out.println("日で集計　範囲指定あり");
        groupMap = salesSummaryDAO.dbSelectGroupDayBetween(Timestamp.valueOf("2019-05-01 01:02:03.123456789"), Timestamp.valueOf(LocalDateTime.now()));
        for (Map.Entry<String, Integer> entry : groupMap.entrySet()) {
            String key = entry.getKey();
            Integer value = entry.getValue();
            System.out.println(key + ", "+ value);
        }

        System.out.println("時間で集計　範囲指定あり");
        groupMap = salesSummaryDAO.dbSelectGroupHourBetween(Timestamp.valueOf("2019-05-01 01:02:03.123456789"), Timestamp.valueOf(LocalDateTime.now()));
        for (Map.Entry<String, Integer> entry : groupMap.entrySet()) {
            String key = entry.getKey();
            Integer value = entry.getValue();
            System.out.println(key + ", "+ value);
        }        
    }
    
    
    
    
    /**
     * 以下非推奨メソッド.
     */
    
    /**
     * 売上サマリー集計実行.
     * 　集計の軸には数値型を用いる
     * @return 集計結果のマップ key=集計の軸 value=合計値
     */
    /*
    public Map<Integer, Integer> selectSummaryIntegerGroupExceute() {
        Map<Integer, Integer> groupMap = new HashMap<>();
        try {
            groupMap.clear();
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                groupMap.put(rs.getInt("key"), rs.getInt("value"));
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return groupMap;
    }*/
    
    
}

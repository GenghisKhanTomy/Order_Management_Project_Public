package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.OrderListView;

/**
 * 注文一覧ビューDAO
 * @author 20jz0105
 */
public class OrderListViewDAO {
    private static Connection con;
    private static PreparedStatement ps;
    
    /**
     * コンストラクタ.
     */
    public OrderListViewDAO() {
        DBManager dbManager = DBManager.getDBManager();
        con = dbManager.getConnection();   
    }
    /**
     * 問い合わせ結果をOrderListViewに設定
     * @param orderListView  問い合わせ結果を格納
     * @param rs        問い合わせ結果
     */
    public void setOrderListView(OrderListView orderListView, ResultSet rs) {
        try {
            orderListView.setOrderCode(rs.getInt("order_code"));
            orderListView.setOrderTimestamp(rs.getTimestamp("order_date"));
            orderListView.setCookingStartTimestamp(rs.getTimestamp("cooking_start_date"));
            orderListView.setCookingEndTimestamp(rs.getTimestamp("cooking_end_date"));
            orderListView.setDeliveryStartTimestamp(rs.getTimestamp("delivery_start_date"));
            orderListView.setDeliveryEndTimestamp(rs.getTimestamp("delivery_end_date"));
            orderListView.setPaymentTimestamp(rs.getTimestamp("payment_date"));
            orderListView.setCutomerTEL(rs.getString("telephone_no"));
            orderListView.setCutomerName(rs.getString("name"));
            orderListView.setCustomerType(rs.getBoolean("customer_type"));
            orderListView.setUsageReward(rs.getInt("usage_reward"));
            orderListView.setTotalAmount(rs.getInt("total_amount"));
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**
     * 注文ビュー検索処理実行.
     * @return 検索結果のリスト
     */
    public List<OrderListView> selectOrderListViewExceute() {
        List<OrderListView> orderListViewList = new ArrayList<>();
        try {
            orderListViewList.clear();
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                OrderListView orderListView = new OrderListView();
                setOrderListView(orderListView, rs);
                orderListViewList.add(orderListView);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orderListViewList;
    }
    /**
     * 未入金の注文検索.
     * @return 検索結果
     */
    public List<OrderListView> dbSearchPaymentNull() {
        List<OrderListView> customerList = new ArrayList<>();
        String sql = "SELECT * FROM order_list_view WHERE payment_date IS NULL ORDER BY order_code";
        try {
            ps = con.prepareStatement(sql);
            customerList = selectOrderListViewExceute();
        }        
        catch (SQLException e) {
            e.printStackTrace();
        }
        return customerList;
    }
    /**
     * 未入金の注文検索.
     * 　個人顧客からの注文のみ検索する.
     * @return 検索結果
     */
    public List<OrderListView> dbSearchPaymentNullIvidual() {
        List<OrderListView> customerList = new ArrayList<>();
        String sql = "SELECT * FROM order_list_view WHERE payment_date IS NULL AND customer_type = 1 ORDER BY order_code";
        try {
            ps = con.prepareStatement(sql);
            customerList = selectOrderListViewExceute();
        }        
        catch (SQLException e) {
            e.printStackTrace();
        }
        return customerList;
    }
    /**
     * 未入金の注文検索.
     * 　個人顧客からの注文及び、法人顧客からの当日の注文を検索する.
     * @return 検索結果
     */
    public List<OrderListView> dbSearchPaymentNullCorpDateTodayORIvidual() {
        List<OrderListView> customerList = new ArrayList<>();
        String sql = "SELECT * FROM order_list_view WHERE payment_date IS NULL AND (customer_type = 1 OR customer_type = 0 AND TRUNC(order_date, 'DD') = TRUNC(SYSDATE)) ORDER BY order_code";
        try {
            ps = con.prepareStatement(sql);
            customerList = selectOrderListViewExceute();
        }        
        catch (SQLException e) {
            e.printStackTrace();
        }
        return customerList;
    }
    /**
     * 未入金の注文検索.
     * 　当日の注文のみ検索する
     * @return 検索結果
     */
    public List<OrderListView> dbSearchPaymentNullDateToday() {
        List<OrderListView> customerList = new ArrayList<>();
        String sql = "SELECT * FROM order_list_view WHERE payment_date IS NULL AND TRUNC(order_date, 'DD') = TRUNC(SYSDATE) ORDER BY order_code";
        try {
            ps = con.prepareStatement(sql);
            customerList = selectOrderListViewExceute();
        }        
        catch (SQLException e) {
            e.printStackTrace();
        }
        return customerList;
    }
    /**
     * 注文コードによる検索.
     * 　一意な値での検索のため、returnはListにしない
     * 　検索結果が0件の場合nullを返す
     * @param orderCode  注文コード
     * @return      検索結果
     */
    public OrderListView dbSearchOrderCode(int orderCode) {
        List<OrderListView> orderListViewList = new ArrayList<>();
        OrderListView orderListView = null;
        String sql = "SELECT * FROM order_list_view WHERE order_code = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, orderCode);
            orderListViewList = selectOrderListViewExceute();
            if (orderListViewList.size() == 1) {
                orderListView = orderListViewList.get(0);
            }
        }        
        catch (SQLException e) {
            e.printStackTrace();
        }
        return orderListView;
    }
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        OrderListViewDAO orderListViewDAO = new OrderListViewDAO();        
        List<OrderListView> orderListViewList;

        System.out.println("未入金");
        orderListViewList = orderListViewDAO.dbSearchPaymentNull();
        for (OrderListView orderListView : orderListViewList) {
            orderListView.println();
        }
        
        System.out.println("未入金かつ(個人or法人の当日注文)");
        orderListViewList = orderListViewDAO.dbSearchPaymentNullCorpDateTodayORIvidual();
        for (OrderListView orderListView : orderListViewList) {
            orderListView.println();
        }
        
        System.out.println("未入金かつ個人");
        orderListViewList = orderListViewDAO.dbSearchPaymentNullIvidual();
        for (OrderListView orderListView : orderListViewList) {
            orderListView.println();
        }

    }
}

package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * シングルトンパターンを適用したデータベース接続管理クラス.
 * @author 20jz0105
 */
public class DBManager {
    private static DBManager dbManager = null;
    private static Connection con = null;
    private static final String driverUrl = "";
    private static final String dbUserName = "";
    private static final String dbUserPassword = "";
    /**
     * コンストラクタ.
     * ドライバマネージャにJDBCドライバを登録し、URLで指定された場所に存在するデータベースに接続する
     * アクセス修飾子がprivateなので、内部メソッドからしか生成することができない
     */
    private DBManager() {
        try {
            con = DriverManager.getConnection(driverUrl, dbUserName, dbUserPassword);
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**
     * DB接続管理インスタンスの生成を兼ねたゲッター.
     * @return DB接続管理インスタンス
     */
    public static DBManager getDBManager() {
        if (DBManager.dbManager == null) {
            DBManager.dbManager = new DBManager();
        }
        return DBManager.dbManager;
    }
    /**
     * コネクションのゲッター.
     * @return コネクション
     */
    public Connection getConnection() {
        return con;
    }
    /**
     * テスト用main.
     * @param args 
     */
    public static void main(String[] args) {
        DBManager dbManager = DBManager.getDBManager();
        con = dbManager.getConnection();
        System.out.println("Finish!!");
    }   
}
/*
run:
Finish!!
BUILD SUCCESSFUL (total time: 0 seconds)

*/

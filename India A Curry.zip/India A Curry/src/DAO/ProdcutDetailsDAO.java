package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import model.Product;
import model.ProductDetails;
import DAO.DualDAO;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 * 商品明細DAO
 * @author 20jz0105
 */
public class ProdcutDetailsDAO {
    private static Connection con;
    private static PreparedStatement ps;
    private DualDAO dualDAO;

    /**
     * コンストラクタ.
     * 　データベース接続情報設定
     */
    public ProdcutDetailsDAO() {
        DBManager dbManager = DBManager.getDBManager();
        con = dbManager.getConnection();  
        dualDAO = new DualDAO();
    }
    
    /**
     * 商品明細を一件登録.
     * @author 20jz0132
     * @param productDetails
     * @return 登録件数
     */
    public int dbInsertProductDetailsDAO(ProductDetails productDetails) {
        String sql = "INSERT INTO product_details VALUES(?, ?, ?)";
        try {
            ps = con.prepareStatement(sql); 
            ps.setString(1, productDetails.getProdcut().getProductNo());
            ps.setString(2, productDetails.getProductDetail().getProductNo());
            ps.setInt(3, productDetails.getQuantity());
            return ps.executeUpdate();
        }
        catch (SQLIntegrityConstraintViolationException e) {
            return 0;
        }
        catch (SQLException e) {
            return -1;            
        }
        catch (NullPointerException e) {
            return -1;
        }
    }
    
    /**
     * 商品明細を一件登録.
     * @author 20jz0132
     * @param productDetails
     * @return 登録件数
     */
    public int dbInsertAlreadyProductDetailsDAO(ProductDetails productDetails) {
        String sql = "INSERT INTO product_details VALUES(?, ?, ?)";
        try {
            ps = con.prepareStatement(sql); 
            ps.setString(1, productDetails.getProdcut().getProductNo());
            ps.setString(2, productDetails.getProductDetail().getProductNo());
            ps.setInt(3, productDetails.getQuantity());
            return ps.executeUpdate();
        }
        catch (SQLIntegrityConstraintViolationException e) {
            return 0;
        }
        catch (SQLException e) {
            return -1;            
        }
        catch (NullPointerException e) {
            return -1;
        }
    }
    
    /**
     * セット商品の構成商品の情報を変更するために一度明細を削除する.
     * @author 20jz0132
     * @param product
     * @return 
     */
    public int dbDeleteProdcutDetails(Product product) {
        String sql = "DELETE FROM product_details WHERE product_no = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, product.getProductNo());
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }

    /**
     * 商品番号による検索.
     * @author 20jz0132
     * @param productNo
     * @return 
     */
    public List<ProductDetails> dbSearchProductDetailsFromProductNo(String productNo) {
        List<ProductDetails> productDetailsList = new ArrayList<>();//1件しか検索されないためリストにする必要はないがListの方が扱いやすいため
        ProductDetails productDetails = null;
        String sql = "SELECT * FROM product_Details WHERE product_no = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, productNo);
            productDetailsList = selectProductDetailsExceute();
            if (productDetailsList.size() == 1) {
                productDetails = productDetailsList.get(0);
            }
        }        
        catch (SQLException e) {
            e.printStackTrace();
        }
        return productDetailsList;
    }
    
    /**
     * 商品詳細テーブル検索処理実行.
     * @author 20jz0132
     * @return 検索結果のリスト
     */
    public List<ProductDetails> selectProductDetailsExceute() {
        List<ProductDetails> productDetailsList = new ArrayList<>();
        try {
            productDetailsList.clear();
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ProductDetails productDetails = new ProductDetails();
                setProductDetails(productDetails, rs);
                productDetailsList.add(productDetails);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return productDetailsList;
    }
    
    /**
     * 問い合わせ結果をproductDetailsに設定.
     * @author 20jz0132
     * @param productDetails 格納先モデル
     * @param rs 問い合わせ結果
     */
    private void setProductDetails(ProductDetails productDetails, ResultSet rs) {
        try {
            productDetails.setProdcut(new Product(rs.getString("product_no")));
            productDetails.setProductDetail(new Product(rs.getString("product_detail_no")));
            productDetails.setQuantity(rs.getInt("quantity"));
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        ProdcutDetailsDAO prodcutDetailsDAO = new ProdcutDetailsDAO();
        System.out.println("登録テスト");
        System.out.println("登録件数 : " + prodcutDetailsDAO.dbInsertProductDetailsDAO(new ProductDetails(new Product(), new Product(), 0)));
        System.out.println("登録件数 : " + prodcutDetailsDAO.dbInsertProductDetailsDAO(new ProductDetails(new Product("P00003", "", "", 0, null, null, false), new Product("P00002", "", "", 0, null, null, false), 1)));
    }    
}

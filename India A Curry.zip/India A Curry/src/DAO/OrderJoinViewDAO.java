package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.OrderJoinView;

/**
 * 注文結合ビューDAO
 * @author 20jz0105
 */
public class OrderJoinViewDAO {
    private static Connection con;
    private static PreparedStatement ps;
    /**
     * コンストラクタ.
     */
    public OrderJoinViewDAO() {
        DBManager dbManager = DBManager.getDBManager();
        con = dbManager.getConnection();  
    }
    /**
     * 問い合わせ結果をOrderJoinViewに設定
     * @param orderJoinView  問い合わせ結果を格納
     * @param rs        問い合わせ結果
     */
    public void setOrderJoinView(OrderJoinView orderJoinView, ResultSet rs) {
        try {
            orderJoinView.setOrderCode(rs.getInt("order_code"));
            orderJoinView.setOrderTimestamp(rs.getTimestamp("order_date"));
            orderJoinView.setCookingStartTimestamp(rs.getTimestamp("cooking_start_date"));
            orderJoinView.setCookingEndTimestamp(rs.getTimestamp("cooking_end_date"));
            orderJoinView.setDeliveryStartTimestamp(rs.getTimestamp("delivery_start_date"));
            orderJoinView.setDeliveryEndTimestamp(rs.getTimestamp("delivery_end_date"));
            orderJoinView.setPaymentTimestamp(rs.getTimestamp("payment_date"));
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**
     * 注文結合ビュー検索処理実行.
     * @return 検索結果のリスト
     */
    public List<OrderJoinView> selectOrderJoinViewExceute() {
        List<OrderJoinView> orderJoinViewList = new ArrayList<>();
        try {
            orderJoinViewList.clear();
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                OrderJoinView orderJoinView = new OrderJoinView();
                setOrderJoinView(orderJoinView, rs);
                orderJoinViewList.add(orderJoinView);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orderJoinViewList;
    }
    /**
     * 注文コードによる検索.
     * 　一意となる値での検索のため、returnはListにしない
     * 　検索結果が0件の場合、nullを返す
     * @param orderCode
     * @return 検索結果
     */
    public OrderJoinView dbSearchOrderJoinViewCode(int orderCode) {
        List<OrderJoinView> orderJoinViewList = new ArrayList<>();
        OrderJoinView orderJoinView = null;
        String sql = "SELECT * FROM order_join_view WHERE order_code = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, orderCode);
            orderJoinViewList = selectOrderJoinViewExceute();
            if (orderJoinViewList.size() == 1) {
                orderJoinView = orderJoinViewList.get(0);
            }
        }        
        catch (SQLException e) {
            e.printStackTrace();
        }
        return orderJoinView;
    }

    
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        OrderJoinViewDAO orderJoinViewDAO = new OrderJoinViewDAO();
        List<OrderJoinView> orderJoinViewList = new ArrayList<>();
        System.out.println("全件検索");
//        orderJoinViewList = orderJoinViewDAO.dbSearchOrderJoinAll();
//        for (OrderJoinView orderJoinView : orderJoinViewList) {
//            System.out.println(orderJoinView);
//        }
        
        System.out.println("注文コード検索 11 : " + orderJoinViewDAO.dbSearchOrderJoinViewCode(11));
        System.out.println("注文コード検索 12 : " + orderJoinViewDAO.dbSearchOrderJoinViewCode(12));

    }
    
    
    /**
     * 全件検索. 　
     * @return 検索結果のリスト
     */
    /*
    public List<OrderJoinView> dbSearchOrderJoinAll() {
        List<OrderJoinView> orderJoinViewList = new ArrayList<>();
        String sql = "SELECT * FROM order_join_view";
        try {
            ps = con.prepareStatement(sql);
            orderJoinViewList = selectOrderJoinViewExceute();
        }        
        catch (SQLException e) {
            e.printStackTrace();
        }
        return orderJoinViewList;
    }*/
}

package DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import model.Product;
import java.util.stream.Collectors;
import java.util.stream.IntStream;


/**
 * 商品DAO
 * @author 20jz0105
 */
public class ProductDAO {
    private static Connection con;
    private static PreparedStatement ps;
    
    /**
     * コンストラクタ.
     * 　データベース接続情報設定
     */
    public ProductDAO() {
        DBManager dbManager = DBManager.getDBManager();
        con = dbManager.getConnection();   
    }
    /**
     * 問い合せ結果をProductに格納.
     * @param product   問い合わせ結果を格納
     * @param rs        問い合わせ結果
     */
    public void setProduct(Product product, ResultSet rs) {
        try {
            product.setProductNo(rs.getString("product_no"));
            product.setProductName(rs.getString("name"));
            product.setTypeName(rs.getString("type_name"));
            product.setPrice(rs.getInt("price"));
            product.setProductSalesStartDate(rs.getDate("sales_start_date"));
            product.setProdcutSalesEndDate(rs.getDate("sales_end_date"));
            product.setProductType(rs.getBoolean("set_type"));
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**
     * 商品テーブル検索処理実行.
     * @return 検索結果のリスト
     */
    public List<Product> selectProductExceute() {
        List<Product> productList = new ArrayList<>();
        try {
            productList.clear();
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Product Product = new Product();
                setProduct(Product, rs);
                productList.add(Product);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return productList;
    }
    /**
     * 商品番号又は商品名に対する部分一致し、指定されたカテゴリのデータの検索.
     * @param searchWord       検索ワード
     * @param category   検索カテゴリ
     * @return           検索結果のリスト
     */
    public List<Product> dbSearchNoNameLikeCategory(String searchWord, String category) {
        List<Product> productList = new ArrayList<>();
        String sql = "SELECT * FROM products WHERE (product_no LIKE ? OR name LIKE ?) AND type_name = ? ORDER BY product_no";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, "%" + searchWord + "%");
            ps.setString(2, "%" + searchWord + "%");
            ps.setString(3, category);
            productList = selectProductExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return productList;
    }
    /**
     * 商品番号又は商品名に対する部分一致し、指定されたカテゴリのデータの検索.
     * 　販売中の商品のみ検索する
     * @param searchWord       検索ワード
     * @param category   検索カテゴリ
     * @return           検索結果のリスト
     */
    public List<Product> dbSearchSaleNoNameLikeCategory(String searchWord, String category) {
        List<Product> productList = new ArrayList<>();
        String sql = "SELECT * FROM products WHERE (product_no LIKE ? OR name LIKE ?) AND type_name = ? AND sales_start_date <= SYSDATE AND (sales_end_date >= SYSDATE OR sales_end_date IS NULL) ORDER BY product_no";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, "%" + searchWord + "%");
            ps.setString(2, "%" + searchWord + "%");
            ps.setString(3, category);
            productList = selectProductExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return productList;
    }
    /**
     * 商品番号又は商品名に対する部分一致検索.
     * @param searchWord   検索ワード
     * @return       検索結果のリスト
     */
    public List<Product> dbSearchNoNameLike(String searchWord) {
        List<Product> productList = new ArrayList<>();
        String sql = "SELECT * FROM products WHERE product_no LIKE ? OR name LIKE ? ORDER BY product_no";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, "%" + searchWord + "%");
            ps.setString(2, "%" + searchWord + "%");
            productList = selectProductExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return productList;
    }
    
    /**
     * 商品番号又は商品名に対する部分一致検索.
     * 　販売中の商品のみ検索する
     * @param searchWord   検索ワード
     * @return       検索結果のリスト
     */
    public List<Product> dbSearchSaleAllProduct() {
        List<Product> productList = new ArrayList<>();
        String sql = "SELECT * FROM products WHERE sales_start_date <= SYSDATE AND (sales_end_date >= SYSDATE OR sales_end_date IS NULL) ORDER BY product_no";

        try {
            ps = con.prepareStatement(sql);
            productList = selectProductExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return productList;
    }
    
    /**
     * 商品番号又は商品名に対する部分一致検索.
     * 　販売中の商品のみ検索する
     * @param searchWord   検索ワード
     * @return       検索結果のリスト
     */
    public List<Product> dbSearchSaleNoNameLike(String searchWord) {
        List<Product> productList = new ArrayList<>();
        String sql = "SELECT * FROM products WHERE (product_no LIKE ? OR name LIKE ?) AND sales_start_date <= SYSDATE AND (sales_end_date >= SYSDATE OR sales_end_date IS NULL) ORDER BY product_no";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, "%" + searchWord + "%");
            ps.setString(2, "%" + searchWord + "%");
            productList = selectProductExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return productList;
    }
    /**
     * 商品番号又は商品名に対する部分一致検索.
     * 　販売中の商品のみ検索する
     * 　単品商品のみ検索する
     * @param searchWord   検索ワード
     * @return       検索結果のリスト
     */
    public List<Product> dbSearchSaleNoNameLikeNotSet(String searchWord) {
        List<Product> productList = new ArrayList<>();
        String sql = "SELECT * FROM products WHERE (product_no LIKE ? OR name LIKE ?) AND sales_start_date <= SYSDATE AND (sales_end_date >= SYSDATE OR sales_end_date IS NULL) AND set_type = 0 ORDER BY product_no";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, "%" + searchWord + "%");
            ps.setString(2, "%" + searchWord + "%");
            productList = selectProductExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return productList;
    }
    /**
     * 商品番号(主キー)指定による検索.
     * 　主キーでの検索のため、returnはListにしない
     * 　検索結果が0件の場合はnullを返す
     * @param productNo 商品番号
     * @return          検索結果
     */
    public Product dbSearchNo(String productNo) {
        List<Product> productList = new ArrayList<>();
        Product product = null;
        String sql = "SELECT * FROM products WHERE product_no = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, productNo);
            productList = selectProductExceute();
            if (productList.size() == 1) {
                product = productList.get(0);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return product;
    }
    /**
     * 商品番号(主キー)指定による検索.
     * 　主キーでの検索のため、returnはListにしない
     * 　検索結果が0件の場合はnullを返す
     * 　販売中の商品のみ検索する
     * @param productNo 商品番号
     * @return          検索結果
     */
    public Product dbSearchSaleNo(String productNo) {
        List<Product> productList = new ArrayList<>();
        Product product = null;
        String sql = "SELECT * FROM products WHERE product_no = ? AND sales_start_date <= SYSDATE AND (sales_end_date >= SYSDATE OR sales_end_date IS NULL) ORDER BY product_no";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, productNo);
            productList = selectProductExceute();
            if (productList.size() == 1) {
                product = productList.get(0);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return product;
    }    
    /**
     * 商品データを1件登録.
     * @suthor 20jz0132
     * @param product  登録する商品データ
     * @return          登録件数
     */
    public int dbInsertProduct(Product product) {
        String sql = "INSERT INTO products VALUES(?, ?, ?, ?, ?, ?, ?)";//(name, type_name, price, sales_start_date, sales_end_date, set_type)
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, product.getProductNo()); 
            ps.setString(2, product.getProductName());
            ps.setString(3, product.getTypeName());
            ps.setInt(4, product.getPrice());
            ps.setDate(5, product.getProductSalesStartDate());
            ps.setDate(6, product.getProdcutSalesEndDate());
            ps.setBoolean(7, product.isProductType());
            return ps.executeUpdate();
        }
        catch (SQLIntegrityConstraintViolationException e) {
            return 0;
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }
    /**
     * 商品の販売終了年月日を更新する.
     * @param productNo             更新する商品の商品番号
     * @param prodcutSalesEndDate   更新する販売終了年月日
     * @return                      更新件数
     */
    public int dbUpdateProdcutSalesEndDate(String productNo, Date prodcutSalesEndDate) {
        String sql = "UPDATE products SET sales_end_date = ? WHERE product_no = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setDate(1, prodcutSalesEndDate);
            ps.setString(2, productNo);
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }

    /**
     * 商品の情報を更新する.
     * @author 20jz0132
     * @param product             更新する商品
     * @return                      更新件数
     */
    public int dbUpdateProdcut(Product product) {
        String sql = "UPDATE products SET name = ?, type_name = ?, price = ?, sales_start_date = ?, sales_end_date = ?, set_type = ? WHERE product_no = ?";
        try {//                                 1               2           3                   4                   5               6                   7
            ps = con.prepareStatement(sql);
            ps.setString(1, product.getProductName());
            ps.setString(2, product.getTypeName());
            ps.setInt(3, product.getPrice());
            ps.setDate(4, product.getProductSalesStartDate());
            ps.setDate(5, product.getProdcutSalesEndDate());
            ps.setInt(6, product.getProductType());
            ps.setString(7, product.getProductNo());
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }
    
    /**
     * 配列で渡された商品番号を検索.
     * @param rowProductNo IN句で利用する商品番号の配列
     * @return 
     */
    public List<Product> dbSearchFromNoToProductIn(String[] rowProductNo) {
        List<Product> productList = new ArrayList<>();
        String sql = "SELECT * FROM products WHERE sales_start_date <= SYSDATE AND (sales_end_date >= SYSDATE OR sales_end_date IS NULL) AND product_no IN ";
        sql += IntStream.range(0, rowProductNo.length).boxed().map(i -> "?").collect(Collectors.joining(", ", "(", ")"));
        sql += " ORDER BY product_no";
        try {
            ps = con.prepareStatement(sql);
            for (int idx = 0; idx < rowProductNo.length; idx++) {
                ps.setString(idx + 1, rowProductNo[idx]);
            }
            productList = selectProductExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return productList;
    }


    /**
     * テスト用メイン
     * @param args 
     */
    public static void main(String[] args) {
        ProductDAO productDAO = new ProductDAO();
        List<Product> productList = new ArrayList<>();
        System.out.println("-----商品番号又は商品名に部分一致検索かつ、カテゴリ検索");
        System.out.println("P00001, ライス : ");
        productList = productDAO.dbSearchNoNameLikeCategory("P00001", "ライス");
        for (Product product : productList) {
            product.println();
        }
        System.out.println("カレー, カレー : ");
        productList = productDAO.dbSearchNoNameLikeCategory("カレー", "カレー");
        for (Product product : productList) {
            product.println();
        }
        
        System.out.println("-----商品番号又は商品名に部分一致検索");
        
        System.out.println("P0 : ");
        productList = productDAO.dbSearchNoNameLike("P0");
        for (Product product : productList) {
            product.println();
        }
        System.out.println("カレー : ");
        productList = productDAO.dbSearchNoNameLike("カレー");
        for (Product product : productList) {
            product.println();
        }
        
        System.out.println("-----商品番号検索");
        System.out.println("003 : " + productDAO.dbSearchNo("003"));
        System.out.println("P00001 : " + productDAO.dbSearchNo("P00001"));
        
        System.out.println("----商品登録");
        System.out.println("商品番号　P00001　登録件数: " + productDAO.dbInsertProduct(new Product("P00001", "ライス", "ライス", 200, Date.valueOf("2021-9-1"), null, false)));//販売終了日が定まっていない場合はDate.valueOf("")ではなくnullを渡す
        System.out.println("商品番号　P00002　登録件数: " + productDAO.dbInsertProduct(new Product("P00002", "ポークカレー", "カレー", 500, Date.valueOf(LocalDate.now()), Date.valueOf(LocalDate.now().plusDays(30)), false)));
        
        System.out.println("----販売終了年月日更新");
        System.out.println("商品番号　P00007　更新件数: " + productDAO.dbUpdateProdcutSalesEndDate("P00007", null));
        System.out.println("商品番号　P00002　更新件数: " + productDAO.dbUpdateProdcutSalesEndDate("P00002", Date.valueOf("2029-9-1")));
        
        
    }

}

package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Date;
import java.time.LocalDate;
import model.Product;
import model.SpecialProduct;

/**
 * 特別商品DAO
 * @author 20jz0105
 */
public class SpecialProductDAO {
    private static Connection con;
    private static PreparedStatement ps;

    /**
     * コンストラクタ.
     */
    public SpecialProductDAO() {
        DBManager dbManager = DBManager.getDBManager();
        con = dbManager.getConnection();   
    }
    /**
     * 特別商品情報を、該当商品のキャンペーン既にあるなら更新、ないなら登録.
     * @param specailProduct  更新・登録する商品データ
     * @return                更新・登録件数
     */
    public int dbMergeSpecailProduct(SpecialProduct specailProduct) {
        try {
            if (dbUpdateSpecialEndDate(specailProduct.getProduct().getProductNo(), Date.valueOf(LocalDate.now())) != -1) {
                return dbInsertSpecialProduct(specailProduct);
            }
            else {
                return -1;
            }
        }
        catch (NullPointerException e) {
            return -1;
        }

    }
    /**
     * 特別情報商品の終了日の更新
     * @param specailProductNo  更新するデータの特別商品番号
     * @param specialEndDate    更新する終了日
     * @return 更新件数
     */
    public int dbUpdateSpecialEndDate(String specailProductNo, Date specialEndDate) {
        String sql = "UPDATE special_products SET special_end_date = ? WHERE special_product_no = ?";        
        try {
            ps = con.prepareStatement(sql);
            ps.setDate(1, specialEndDate);
            ps.setString(2, specailProductNo);
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }   
    }
    /**
     * 特別商品を1件登録
     * @param specialProduct    登録する特別商品
     * @return                  登録件数
     */
    public int dbInsertSpecialProduct(SpecialProduct specialProduct) {
        String sql = "INSERT INTO special_products(reward_magnification, special_start_date, special_end_date, product_no) VALUES(?, ?, ?, ?)";
        try {
            ps = con.prepareStatement(sql); 
            ps.setFloat(1, specialProduct.getRewardMagnification());
            ps.setDate(2, specialProduct.getSpecialSalesStartDate());
            ps.setDate(3, specialProduct.getSpecialSalesEndDate());
            ps.setString(4, specialProduct.getProduct().getProductNo());
            return ps.executeUpdate();
        }
        catch (SQLIntegrityConstraintViolationException e) {
            return 0;
        }
        catch (NullPointerException e) {
            return -1;
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        SpecialProductDAO specialProductDAO = new SpecialProductDAO();
        System.out.println("マージテスト");
        System.out.println("登録件数 : " + specialProductDAO.dbMergeSpecailProduct(new SpecialProduct(new ProductDAO().dbSearchNo("P00001"), 1.123f, Date.valueOf(LocalDate.now()), null)));
        System.out.println("登録件数 : " + specialProductDAO.dbMergeSpecailProduct(new SpecialProduct(new ProductDAO().dbSearchNo("P00010"), 1.123f, Date.valueOf(LocalDate.now()), null)));
        System.out.println("登録件数 : " + specialProductDAO.dbMergeSpecailProduct(new SpecialProduct(new Product("P00002", "", "", 0, null, null, false), 1.45f, Date.valueOf(LocalDate.now()), null)));
        
    }

    public int dbUpdateSpecialEndDateUsingProductNo(String productNo) {
        String sql = "UPDATE special_products SET special_end_date = TRUNC(SYSDATE-1, 'DD')  WHERE product_no = ? AND special_end_date >= SYSDATE";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, productNo);
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }   
    }    
}

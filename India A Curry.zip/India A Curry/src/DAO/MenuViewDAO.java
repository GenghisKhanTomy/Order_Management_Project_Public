package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.MenuView;

/**
 * メニュービューDAO
 * @author 20jz0105
 */
public class MenuViewDAO {
    private static Connection con;
    private static PreparedStatement ps;
    
    /**
     * コンストラクタ.
     */
    public MenuViewDAO() {
        DBManager dbManager = DBManager.getDBManager();
        con = dbManager.getConnection();   
    }
    
    /**
     * 問い合わせ結果をMenuViewに設定
     * @param menuView  問い合わせ結果を格納
     * @param rs        問い合わせ結果
     */
    public void setMenuView(MenuView menuView, ResultSet rs) {
        try {
            menuView.setProductNo(rs.getString("product_no"));
            menuView.setProductName(rs.getString("product_name"));
            menuView.setPrice(rs.getInt("price"));
            menuView.setCategoryName(rs.getString("type_name"));
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**
     * メニュービュー検索処理実行.
     * @return 検索結果のリスト
     */
    public List<MenuView> selectMenuViewExceute() {
        List<MenuView> menuViewList = new ArrayList<>();
        try {
            menuViewList.clear();
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                MenuView menuView = new MenuView();
                setMenuView(menuView, rs);
                menuViewList.add(menuView);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return menuViewList;
    }
    /**
     * メニューの全件検索.
     * @return      検索結果のリスト
     */
    public List<MenuView> dbSearchMenuViewAll() {
        List<MenuView> menuViewList = new ArrayList<>();
        String sql = "SELECT * FROM menu_view";
        try {
            ps = con.prepareStatement(sql);
            menuViewList = selectMenuViewExceute();
        }        
        catch (SQLException e) {
            e.printStackTrace();
        }
        return menuViewList;
    }
    /**
     * メニューの商品番号又は商品名の部分一致検索.
     * @param searchWord    検索ワード
     * @return      検索結果のリスト
     */
    public List<MenuView> dbSearchMenuViewNoLikeORNameLike(String searchWord) {
        List<MenuView> menuViewList = new ArrayList<>();
        String sql = "SELECT * FROM menu_view WHERE product_no LIKE ? OR product_name LIKE ?";
        try {
            ps = con.prepareStatement(sql);
            searchWord = '%' + searchWord + '%';
            ps.setString(1, searchWord);
            ps.setString(2, searchWord);
            menuViewList = selectMenuViewExceute();
        }        
        catch (SQLException e) {
            e.printStackTrace();
        }
        return menuViewList;
    }
    /**
     * メニューの商品番号又は商品名の部分一致検索かつ、区分検索.
     * @param searchWord    検索ワード
     * @param typeName      検索区分
     * @return      検索結果のリスト
     */
    public List<MenuView> dbSearchMenuViewNoLikeORNameLikeType(String searchWord, String typeName) {
        List<MenuView> menuViewList = new ArrayList<>();
        String sql = "SELECT * FROM menu_view WHERE (product_no LIKE ? OR product_name LIKE ?) AND type_name = ?";
        try {
            ps = con.prepareStatement(sql);
            searchWord = '%' + searchWord + '%';
            ps.setString(1, searchWord);
            ps.setString(2, searchWord);
            ps.setString(3, typeName);
            menuViewList = selectMenuViewExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return menuViewList;
    }
    /**
     * メニューの区分検索.
     * @param typeName      検索区分
     * @return      検索結果のリスト
     */
    public List<MenuView> dbSearchMenuViewType(String typeName) {
        List<MenuView> menuViewList = new ArrayList<>();
        String sql = "SELECT * FROM menu_view WHERE type_name = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, typeName);
            menuViewList = selectMenuViewExceute();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return menuViewList;
    }
    public static void main(String[] args) {
        MenuViewDAO menuViewDAO = new MenuViewDAO();
        List<MenuView> menuViewList = new ArrayList<>();
        
        System.out.println("全件検索");
        menuViewList = menuViewDAO.dbSearchMenuViewAll();
        for (MenuView menuView : menuViewList) {
            menuView.println();
        }
        
        System.out.println("商品番号検索");
        menuViewList = menuViewDAO.dbSearchMenuViewNoLikeORNameLike("P00");
        for (MenuView menuView : menuViewList) {
            menuView.println();
        }
        
        System.out.println("商品名検索");
        menuViewList = menuViewDAO.dbSearchMenuViewNoLikeORNameLike("カレー");
        for (MenuView menuView : menuViewList) {
            menuView.println();
        }
        
        System.out.println("区分かつ商品番号検索");
        menuViewList = menuViewDAO.dbSearchMenuViewNoLikeORNameLikeType("1", "ライス");
        for (MenuView menuView : menuViewList) {
            menuView.println();
        }
        
        System.out.println("区分かつ商品名検索");
        menuViewList = menuViewDAO.dbSearchMenuViewNoLikeORNameLikeType("00", "カレー");
        for (MenuView menuView : menuViewList) {
            menuView.println();
        }
    }
}

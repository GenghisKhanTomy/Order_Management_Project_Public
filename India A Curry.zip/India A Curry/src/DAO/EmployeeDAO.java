package DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import model.Employee;

/**
 * 従業員DAO
 * @author 20jz0105
 */
public class EmployeeDAO {
    private static Connection con;
    private static PreparedStatement ps;
    /**
     * コンストラクタ.
     * 　データベース接続情報設定
     */
    public EmployeeDAO() {
        DBManager dbManager = DBManager.getDBManager();
        con = dbManager.getConnection();   
    }
    /**
     * 問い合わせ結果をEmployeeに設定
     * @param employee  問い合わせ結果を格納
     * @param rs        問い合わせ結果
     */
    public void setEmployee(Employee employee, ResultSet rs) {
        try {
            employee.setEmployeeNo(rs.getString("employee_no"));
            employee.setEmployeeName(rs.getString("name"));
            employee.setPassword(rs.getString("password"));
            employee.setSex(rs.getInt("sex"));
            employee.setBirthDate(rs.getDate("birth_date"));
            employee.setTEL(rs.getString("telephone_no"));
            employee.setAddress(rs.getString("address"));
            employee.setJobType(rs.getBoolean("job_type"));
            employee.setContinueServiceType(rs.getBoolean("continued_service_type"));
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**
     * 従業員テーブル検索処理実行.
     * @return 検索結果のリスト
     */
    public List<Employee> selectEmployeeExceute() {
        List<Employee> employeeList = new ArrayList<>();
        try {
            employeeList.clear();
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Employee employee = new Employee();
                setEmployee(employee, rs);
                employeeList.add(employee);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return employeeList;
    }
    /**
     * 従業員番号による検索.
     * 　一意キーでの検索のため、returnはListにしない
     * 　検索結果が0件の場合nullを返す
     * @param employeeNo   従業員番号(一意キー)
     * @return      検索結果
     */
    public Employee dbSearchEmployeeNo(String employeeNo) {
        List<Employee> employeeList = new ArrayList<>();
        Employee employee = null;
        String sql = "SELECT * FROM employees WHERE employee_no = ? AND continued_service_type = 1";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, employeeNo);
            employeeList = selectEmployeeExceute();
            if (employeeList.size() == 1) {
                employee = employeeList.get(0);
            }
        }        
        catch (SQLException e) {
            e.printStackTrace();
        }
        return employee;
    }
    /**
     * 従業員の全件検索.
     * @return      検索結果
     */
    public List<Employee> dbSearchEmployeeAll() {
        List<Employee> employeeList = new ArrayList<>();
        String sql = "SELECT * FROM employees";
        try {
            ps = con.prepareStatement(sql);
            employeeList = selectEmployeeExceute();            
        }        
        catch (SQLException e) {
            e.printStackTrace();
        }
        return employeeList;
    }
    /**
     * 従業員の部分一致検索.
     * @param searchWord  検索ワード
     * @return      検索結果
     */
    public List<Employee> dbSearchContunueEmployeeNoLikeORNameLike(String searchWord) {
        List<Employee> employeeList = new ArrayList<>();
        String sql = "SELECT * FROM employees WHERE (employee_no LIKE ? OR name LIKE ?) AND continued_service_type = 1";
        try {
            ps = con.prepareStatement(sql);
            searchWord = '%' + searchWord + '%';
            ps.setString(1, searchWord);
            ps.setString(2, searchWord);
            employeeList = selectEmployeeExceute();            
        }        
        catch (SQLException e) {
            e.printStackTrace();
        }
        return employeeList;
    }    
    /**
     * 従業員番号及びパスワード指定による検索.
     * 　一意キーでの検索のため、returnはListにしない
     * 　検索結果が0件の場合nullを返す
     * @param employeeNo   従業員番号(一意キー)
     * @param password    パスワード
     * @return      検索結果
     */
    public Employee dbSearchEmployeeNoPass(String employeeNo, String password) {
        List<Employee> employeeList = new ArrayList<>();
        Employee employee = null;
        String sql = "SELECT * FROM employees WHERE employee_no = ? AND password = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, employeeNo);
            ps.setString(2, password);
            employeeList = selectEmployeeExceute();
            if (employeeList.size() == 1) {
                employee = employeeList.get(0);
            }
        }        
        catch (SQLException e) {
            e.printStackTrace();
        }
        return employee;
    }
    /**
     * 従業員データを1件登録.
     * 　顧客番号、ポイント、配達先住所、最頻注文商品番号はDEFAULT値を利用する
     * @param employee  登録する顧客データ
     * @return          登録件数
     */
    public int dbInsertEmployee(Employee employee) {
        String sql = "INSERT INTO employees(employee_no, name, password, sex, birth_date, telephone_no, address, job_type) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, employee.getEmployeeNo());
            ps.setString(2, employee.getEmployeeName());
            ps.setString(3, employee.getPassword());
            ps.setInt(4, employee.getSex());
            ps.setDate(5, employee.getBirthDate());
            ps.setString(6, employee.getTEL());
            ps.setString(7, employee.getAddress());
            ps.setBoolean(8, employee.isJobType());
            return ps.executeUpdate();
        }
        catch (SQLIntegrityConstraintViolationException e) {
            return 0;
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
        catch (NullPointerException e) {
            return -1;
        }
    }
    /**
     * 従業員の勤続区分の更新.
     * @param employeeNo            更新する従業員の従業員番号
     * @param continueServiceType   更新する勤続区分
     * @return 更新件数
     */
    public int dbUpdateContinueServiceType(String employeeNo, boolean continueServiceType) {
        String sql = "UPDATE employees SET continued_service_type = ? WHERE employee_no = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setBoolean(1, continueServiceType);
            ps.setString(2, employeeNo);
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }
    /**
     * 従業員情報の更新.
     * @param employeeNo    従業員番号
     * @param name  名前
     * @param sex   性別
     * @param TEL
     * @param address
     * @param jobType
     * @return 更新件数
     */
    public int dbUpdateEmployee(String employeeNo, String name, int sex, String TEL, String address, boolean jobType) {
        String sql = "UPDATE employees SET name = ?, sex = ?, telephone_no = ?, address = ?, job_type = ? WHERE employee_no = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, name);
            ps.setInt(2, sex);
            ps.setString(3, TEL);
            ps.setString(4, address);
            ps.setBoolean(5, jobType);
            ps.setString(6, employeeNo);
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }
    /**
     * 従業員のパスワード更新.
     * @param employeeNo    従業員番号
     * @param password      更新するパスワード
     * @return 更新件数
     */
    public int dbUpdatePassword(String employeeNo, String password) {
        String sql = "UPDATE employees SET password = ? WHERE employee_no = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, password);
            ps.setString(2, employeeNo);
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }
    
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        EmployeeDAO employeeDAO = new EmployeeDAO();
        System.out.println("登録テスト");
        System.out.println("登録件数 : " + employeeDAO.dbInsertEmployee(new Employee("E00001", "ヤマダ", "pass", 0, Date.valueOf(LocalDate.now()), "0123-456-789", "山", true)));
        System.out.println("登録件数 : " + employeeDAO.dbInsertEmployee(new Employee("E00002", "test", "", 0, Date.valueOf(LocalDate.now()), "999-888-777", "島", false)));

        System.out.println("検索テスト");
        System.out.println("従業員番号E00001のデータ : " + employeeDAO.dbSearchEmployeeNo("E00001"));
        System.out.println("従業員番号E00010のデータ : " + employeeDAO.dbSearchEmployeeNo("E00010"));

        System.out.println("従業員番号E00001,パスワードpassのデータ : " + employeeDAO.dbSearchEmployeeNoPass("E00001", "pass"));
        System.out.println("従業員番号E00001,パスワードwordのデータ : " + employeeDAO.dbSearchEmployeeNoPass("E00001", "word"));
        
        System.out.println("更新テスト");
        System.out.println("更新件数 : " + employeeDAO.dbUpdateContinueServiceType("E00001", false));
        System.out.println("更新件数 : " + employeeDAO.dbUpdateContinueServiceType("E00011", true));
        
        System.out.println("全件検索");
        List<Employee> employeeList = employeeDAO.dbSearchEmployeeAll();
        for (Employee employee : employeeList) {
            System.out.println(employee);
        }
    }
    
    
    
    
    /**
     * 以下非推奨メソッド.
     */
    /**
     * 従業員のパスワードの更新.
     * @param employeeNo        更新する従業員の従業員番号
     * @param password          更新するパスワード
     * @return 更新件数
     */
    /*
    public int dbUpdatePassword(String employeeNo, String password) {
        String sql = "UPDATE employees SET password = ? WHERE employee_no = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, password);
            ps.setString(2, employeeNo);
            return ps.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }*/
    
    
}

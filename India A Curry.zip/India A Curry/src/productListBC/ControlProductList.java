package productListBC;

import DAO.ProductDAO;
import editProductBC.ControlEditProduct;
import java.util.List;
import model.Product;

/**
 * 商品一覧コントロール
 * @author 20jz0105
 */
public class ControlProductList extends bcSuper.ControlSuper {
    private BoundaryProductList boundaryProductList;
    private ControlEditProduct controlEditProduct;
    private ProductDAO productDAO;
    private List<Product> productList;
    private String searchWord;//帰還時の再検索用
    private String category;//帰還時の再検索用

    public ControlProductList() {
        boundaryProductList = new BoundaryProductList();
        productDAO = new ProductDAO();
    }        


    public void setControlEditProduct(ControlEditProduct controlEditProduct) {
        this.controlEditProduct = controlEditProduct;
    }

    /**
     * 画面起動メソッド.
     */
    public void start() {
        boundaryProductList.setControlProductList(this);
        fetchProductList("", null);
        boundaryProductList.setVisible(true);        
    }
    /**
     * システムメニューへの帰還メソッド.
     */
    public void exit() {
        boundaryProductList.setVisible(false);
        boundaryProductList.clear();
        super.getControlSystemMenu().exitContents();
    }
    /**
     * 商品確認・変更画面からの帰還メソッド.
     */
    public void exitContents() {
        fetchProductList(searchWord, category);
        boundaryProductList.setVisible(true);
    }
    /**
     * ログイン画面への帰還メソッド.
     */
    public void exitLogout() {
        boundaryProductList.setVisible(false);
        boundaryProductList.clear();
        super.getControlSystemMenu().exit();
    }
    /**
     * 商品リストの検索.
     * @param searchWord
     * @param category 
     */
    public void fetchProductList(String searchWord, String category) {
        if (constant.CategoryList.ALL.equals(category) || category == null) {
            productList = productDAO.dbSearchSaleNoNameLike(searchWord);
        }
        else {
            productList = productDAO.dbSearchSaleNoNameLikeCategory(searchWord, category);     
        }
        boundaryProductList.clearProduct();
        for (Product product : productList) {
            boundaryProductList.appendProduct(new Object[]{product.getProductNo(), product.getTypeName(), product.getProductName(), product.getPrice(), "詳細を表示"});
        }
        this.searchWord = searchWord;
        this.category = category;
    }
    /**
     * 選択された商品の詳細を表示.
     * @param productNo
     */
    public void awakenProductEditor(String productNo) {
//        controlEditProduct.fetchPreparation();
        controlEditProduct.fetchProduct(true, productNo);
        boundaryProductList.setVisible(false);
        controlEditProduct.setReturnProductListButtonVisble();
        controlEditProduct.start();
        controlEditProduct.installProduct();
    }

    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        new ControlProductList().start();
    }
}

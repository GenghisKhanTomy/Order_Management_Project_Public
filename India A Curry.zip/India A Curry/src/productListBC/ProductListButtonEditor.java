package productListBC;

import javax.swing.JCheckBox;
import javax.swing.JOptionPane;

/**
 *
 * @author 20jz0105
 */
public class ProductListButtonEditor extends bcSuper.ButtonEditor {
    private BoundaryProductList boundaryProductList;
    
    public ProductListButtonEditor(JCheckBox checkBox, BoundaryProductList boundaryProductList) {
        super(checkBox);
        setBoundaryProductList(boundaryProductList);
    }

    public void setBoundaryProductList(BoundaryProductList boundaryProductList) {
        this.boundaryProductList = boundaryProductList;
    }


    
    @Override
    public Object getCellEditorValue() {
        if (isPushed) {
            if (boundaryProductList.showConfirmYesNo("詳細に移動しますか？") == JOptionPane.YES_OPTION) {
                boundaryProductList.showDetail();
            }
        }
        isPushed = false;
        return label;
    }
    
}

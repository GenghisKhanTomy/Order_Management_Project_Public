package productListBC;

import javax.swing.table.DefaultTableModel;

/**
 *
 * @author 20jz0105
 */
public class ProductListTableModel extends DefaultTableModel {
    private int productNoColumn;
    private int categoryNameColumn;
    private int productNameColumn;
    private int priceColumn;
    private int showDetailColumn;
    
    public ProductListTableModel(Object[] os, int i) {
        super(os, i);
        for (int column = 0; column < getColumnCount(); column++) {
            if ("商品番号".equals(getColumnName(column))) {
                setProductNoColumn(productNoColumn);
            }
            else if ("商品カテゴリ".equals(getColumnName(column))) {
                setCategoryNameColumn(column);
            }
            else if ("商品名".equals(getColumnName(column))) {
                setProductNameColumn(column);
            }
            else if ("価格（税抜）".equals(getColumnName(column))) {
                setPriceColumn(column);
            }
            else if ("詳細".equals(getColumnName(column))) {
                setShowDetailColumn(column);
            }
        }
    }
    @Override
    public boolean isCellEditable(int row, int column) {
        return column == getShowDetailColumn();   
    }

    public int getProductNoColumn() {
        return productNoColumn;
    }

    public int getCategoryNameColumn() {
        return categoryNameColumn;
    }

    public int getProductNameColumn() {
        return productNameColumn;
    }

    public int getPriceColumn() {
        return priceColumn;
    }

    public int getShowDetailColumn() {
        return showDetailColumn;
    }

    public void setProductNoColumn(int productNoColumn) {
        this.productNoColumn = productNoColumn;
    }

    public void setCategoryNameColumn(int categoryNameColumn) {
        this.categoryNameColumn = categoryNameColumn;
    }

    public void setProductNameColumn(int productNameColumn) {
        this.productNameColumn = productNameColumn;
    }

    public void setPriceColumn(int priceColumn) {
        this.priceColumn = priceColumn;
    }

    public void setShowDetailColumn(int showDetailColumn) {
        this.showDetailColumn = showDetailColumn;
    }
}

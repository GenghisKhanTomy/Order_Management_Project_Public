package paymentBC;

import javax.swing.table.DefaultTableModel;

/**
 * 請求書テーブルモデルクラス
 * @author 20jz0105
 */
public class InvoiceTableModel extends DefaultTableModel {
    private int orderCodeColumn;
    private int orderDateColumn;
    private int productNameColumn;
    private int priceColumn;
    private int quantityColumn;
    private int subTotalColumn;

    public InvoiceTableModel(Object[] os, int i) {
        super(os, i);
        for (int column = 0; column < getColumnCount(); column++) {
            if ("注文番号".equals(getColumnName(column))) {
                setOrderCodeColumn(column);
            }
            else if ("注文日".equals(getColumnName(column))) {
                setOrderDateColumn(column);
            }
            else if ("商品名".equals(getColumnName(column))) {
                setProductNameColumn(column);
            }
            else if ("単価".equals(getColumnName(column))) {
                setPriceColumn(column);
            }
            else if ("個数".equals(getColumnName(column))) {
                setQuantityColumn(column);
            }
            else if ("金額".equals(getColumnName(column))) {
                setSubTotalColumn(column);
            }
        }
    }

    public int getOrderCodeColumn() {
        return orderCodeColumn;
    }

    public int getOrderDateColumn() {
        return orderDateColumn;
    }

    public int getProductNameColumn() {
        return productNameColumn;
    }

    public int getPriceColumn() {
        return priceColumn;
    }

    public int getQuantityColumn() {
        return quantityColumn;
    }

    public int getSubTotalColumn() {
        return subTotalColumn;
    }

    public void setOrderCodeColumn(int orderCodeColumn) {
        this.orderCodeColumn = orderCodeColumn;
    }

    public void setOrderDateColumn(int orderDateColumn) {
        this.orderDateColumn = orderDateColumn;
    }

    public void setProductNameColumn(int productNameColumn) {
        this.productNameColumn = productNameColumn;
    }

    public void setPriceColumn(int priceColumn) {
        this.priceColumn = priceColumn;
    }

    public void setQuantityColumn(int quantityColumn) {
        this.quantityColumn = quantityColumn;
    }

    public void setSubTotalColumn(int subTotalColumn) {
        this.subTotalColumn = subTotalColumn;
    }
    
    @Override
    public boolean isCellEditable(int row, int column) {                
        return false;
    }
}

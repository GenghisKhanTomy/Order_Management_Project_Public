package paymentBC;

import DAO.CustomerDAO;
import DAO.DBManager;
import DAO.InvoiceViewDAO;
import DAO.OrderDAO;
import DAO.OrderListViewDAO;
import DAO.OrderVoucherViewDAO;
import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.swing.JOptionPane;
import model.InvoiceDetail;
import model.InvoiceView;
import model.OrderListView;
import model.OrderVoucherDetail;
import model.OrderVoucherView;
import orderStatusBC.ControlOrderStatus;

/**
 * 入金コントロール
 * @author 20jz0105
 */
public class ControlPayment extends bcSuper.ControlSuper {
    private BoundaryPayment boundaryPayment;
    private ControlOrderStatus controlOrderStatus;
    private OrderDAO orderDAO;
    private OrderListViewDAO orderListViewDAO;
    private InvoiceViewDAO invoiceDAO;
    private OrderVoucherViewDAO orderVoucherViewDAO;
    private CustomerDAO customerDAO;
    private OrderListView orderListView;
    private InvoiceView invoiceView;
    private BoundaryInvoice boundaryInvoice;
    private List<OrderVoucherView> orderVoucherViewList;
    private InvoiceDetail invoiceDetail;
    
    public ControlPayment() {
        boundaryPayment = new BoundaryPayment();
        orderDAO = new OrderDAO();
        orderListViewDAO = new OrderListViewDAO();
        invoiceDAO = new InvoiceViewDAO();
        orderVoucherViewDAO = new OrderVoucherViewDAO();
        customerDAO = new CustomerDAO();
        orderVoucherViewList = new ArrayList<>();
    }

    public void setControlOrderStatus(ControlOrderStatus controlOrderStatus) {
        this.controlOrderStatus = controlOrderStatus;
    }
    /**
     * システムメニューに戻るボタンを表示し、注文状態確認画面に戻るボタンを非表示にする.
     */
    public void setReturnButtonVisble() {
        boundaryPayment.setReturnButtonVisble();
    }
    /**
     * システムメニューに戻るボタンを非表示にし、注文状態確認画面に戻るボタンを表示する.
     */
    public void setReturnOrderStatusButtonVisble() {
        boundaryPayment.setReturnOrderStatusButtonVisble();
    }    
    /**
     * 画面起動メソッド.
     */
    public void start() {
        boundaryPayment.setControlPayment(this);
        boundaryPayment.setVisible(true);
    }
    /**
     * システムメニューへの帰還メソッド.
     */
    public void exit() {
        boundaryPayment.setVisible(false);
        boundaryPayment.clear();
        super.getControlSystemMenu().exitContents();
    }
    /**
     * 注文状態確認画面への帰還メソッド.
     * @author 20jz0132
     */
    public void exitOrderStatus() {
        boundaryPayment.setVisible(false);
        boundaryPayment.clear();
        controlOrderStatus.exitContents();
    }
    /**
     * ログイン画面への帰還メソッド.
     */
    public void exitLogout() {
        boundaryPayment.setVisible(false);
        boundaryPayment.clear();
        super.getControlSystemMenu().exit();
    }
    /**
     * 注文コードを基に入金画面用のビューから注文データを取得する.
     * @param orderCode 
     */
    public void fetchOrder(int orderCode) {
        orderListView = orderListViewDAO.dbSearchOrderCode(orderCode);
        if (orderListView != null) {
            System.out.println(orderListView.getPaymentTimestamp());
            if (!orderListView.isCustomerType()) {//法人顧客の場合
                boundaryPayment.showErrorDialog("法人顧客の注文です");
                boundaryPayment.setCropRadioSelected(true);
                boundaryPayment.setTabSelected(1);
            }
            else if (orderListView.getIntOrderStatus() != constant.OrderStatusList.PAID) {
                boundaryPayment.showPaymentOrderView(orderListView);            
            }
            else {
                boundaryPayment.showErrorDialog("注文[" + orderCode + "] は既に入金済みです");
                boundaryPayment.focusOrderNumber();
            }
        }
        else {
            boundaryPayment.showErrorDialog("注文[" + orderCode + "] は存在しません。もう一度ご確認ください。");
            boundaryPayment.focusOrderNumber();
        }
    }
    /**
     * 指定された電話番号の法人顧客の請求書を検索する.
     * @param TEL 電話番号
     */
    public void fetchInvoice(String TEL) {
        invoiceView = invoiceDAO.dbSearchInvoiceViewNo(TEL);
        boundaryPayment.clearInvoice();
        if (invoiceView != null) {
            boundaryPayment.showInvoice(invoiceView);
        }
        else {
            boundaryPayment.showPlainDialog("未入金の請求書はありません");
            boundaryPayment.focusTelNumber();
        }
    }
    /**
     * 選択された請求書を表示する.
     * @param idx 何番目の請求書か
     */
    public void showSelectedInvoice(int idx) {
        if (boundaryInvoice == null) {
            boundaryInvoice = new BoundaryInvoice(boundaryPayment, true);
            boundaryInvoice.setControlPayment(this);
        }
        try {
            invoiceDetail = invoiceView.getInvoiceViewList().get(idx);
            boundaryInvoice.clearInvoiceOrder();
            LocalDate start = invoiceDetail.getBillingLocalDate().minusMonths(1);
            LocalDate end = invoiceDetail.getBillingLocalDate().minusDays(1);


            orderVoucherViewList = orderVoucherViewDAO.dbSearchTELOrderDate(invoiceView.getCustomerTEL(), Date.valueOf(start), Date.valueOf(end));
            boundaryInvoice.showInvoice(invoiceView, idx);

            String delivery = "配達金額";
            int orderCode;
            String orderDate;
            String productName;
            int price;
            int quantity;
            int subTotal;
            DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy年MM月dd日 HH時mm分");
            for (OrderVoucherView orderVoucherView : orderVoucherViewList) {
                orderCode = orderVoucherView.getOrderCode();
                orderDate = orderVoucherView.getOrderTimestamp().toLocalDateTime().format(format);
                for (Map.Entry<String, List<OrderVoucherDetail>> entry : orderVoucherView.getOrderVoucherDetailMap().entrySet()) {
                    for (OrderVoucherDetail orderVoucherDetail : entry.getValue()) {
                        productName = orderVoucherDetail.getProductName();
                        price = orderVoucherDetail.getPrice();
                        quantity = orderVoucherDetail.getQuantity();
                        subTotal = orderVoucherDetail.getTaxSubTotal();

                        Object[] rowData = {orderCode, orderDate, productName, price, quantity, subTotal};
                        boundaryInvoice.appendInvoiceOrder(rowData);
                    }                
                }
                Object[] rowData = {orderCode, orderDate, delivery, orderVoucherView.getDeliveryAmount(), "", orderVoucherView.getDeliveryAmount()};
                boundaryInvoice.appendInvoiceOrder(rowData);
            }

            boundaryInvoice.setVisible(true);            
        }
        catch (NullPointerException | IndexOutOfBoundsException e) {
        }

    }
    
    /**
     * 入金を確定するか確認する.
     */
    public void detarminePayment() {
        try {
            if (orderListView != null) {
//                int Status = orderListView.getOrderJoinView().getIntOrderStatus();
                int Status = orderListView.getIntOrderStatus();
                String orderCodeStr = String.format("%08d", orderListView.getOrderCode());
                if (Status != constant.OrderStatusList.PAID && Status != constant.OrderStatusList.DELIVERY_END) {
                    String message = String.format("注文番号[%s]は配達終了日時が記録されていません%n入金を確定しますか？", orderCodeStr);
                    if (boundaryPayment.showWarningConfirmYesNo(message) == JOptionPane.YES_OPTION) {
                        storeIvidualPayment();                    
                    }
                }
                else {
                    if (boundaryPayment.showConfirmYesNo(String.format("注文番号[%s]の入金を確定しますか？", orderCodeStr)) == JOptionPane.YES_OPTION) {
                        storeIvidualPayment();                    
                    }
                }
            }            
        }
        catch (NullPointerException e) {
        }
    }
    /**
     * 入金を確定し、入金処理を行う.
     * 　個人顧客での入金処理
     */
    public void storeIvidualPayment() {
        try {
            if (orderListView.isCustomerType()) {
                System.out.println(orderListView.getOrderCode());
                if (orderDAO.dbUpdatePaymentDate(orderListView.getOrderCode(), Timestamp.valueOf(LocalDateTime.now())) == 1) {
                    OrderVoucherView orderVoucherView = orderVoucherViewDAO.dbSearchOrderCode(orderListView.getOrderCode());
                    if (customerDAO.dbUpdateAddReward(orderListView.getCutomerTEL(), orderVoucherView.getAddedReward()) == 1) {
                        boundaryPayment.clearTabIvidual();
                        orderListView = null;
                        boundaryPayment.showPlainDialog("入金処理が完了しました");
                    }
                    else {
                        throw new Exception();
                    }
                }            
                else {
                    throw new Exception();
                }
            }
            else {
                throw new Exception();
            }
        }
        catch (Exception e) {
            if (DBManager.getDBManager().getConnection() != null) {
                if (orderDAO != null && orderListView != null) {
                    orderDAO.dbUpdatePaymentDate(orderListView.getOrderCode(), null);
                }
            }
            boundaryPayment.showErrorDialog("入金処理に失敗しました");
        }
    }
    /**
     * 入金を確定し、入金処理を行う.
     * 　法人顧客での入金処理
     */    
    public void storeCorpPayment() {
        try {
            LocalDate start = invoiceDetail.getBillingLocalDate().minusMonths(1);
            LocalDate end = invoiceDetail.getBillingLocalDate().minusDays(1);
            if (orderDAO.dbUpdatePaymentDateStartEnd(invoiceView.getCustomerNo(), Timestamp.valueOf(LocalDateTime.now()), Date.valueOf(start), Date.valueOf(end)) > 0) {
                invoiceView.getInvoiceViewList().remove(invoiceDetail);
                boundaryPayment.clearInvoice();
                boundaryPayment.showInvoice(invoiceView);
                boundaryInvoice.setDetemineButtonEnable(false);
                boundaryInvoice.showPlainDialog("入金処理が完了しました");
            }
            else {
                boundaryPayment.showErrorDialog("入金処理に失敗しました");
            }
        }
        catch (NullPointerException e) {
        }
    }
    /**
     * 入金画面の個人・法人ラジオボタンを有効/無効にする.
     * @param tf true 個人 / false 法人
     */
    public void setRadioSelected(boolean tf) {
        if (tf) {
            boundaryPayment.setIvidualRadioSelected(true);        
            boundaryPayment.setTabSelected(0);
        }
        else {
            boundaryPayment.setCropRadioSelected(true);
            boundaryPayment.setTabSelected(1);
        }
    }
    
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        new ControlPayment().start();
    }
}

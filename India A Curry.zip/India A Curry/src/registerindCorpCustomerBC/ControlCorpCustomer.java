package registerindCorpCustomerBC;

import DAO.CustomerDAO;
import model.Customer;

/**
 * 法人顧客登録コントロール
 * @author 20jz0105
 */
public class ControlCorpCustomer extends bcSuper.ControlSuper{
    BoundaryRegisterCorpCustomer boundaryRegisterCorpCustomer;
    CustomerDAO customerDAO;
    
    public ControlCorpCustomer() {
        boundaryRegisterCorpCustomer = new BoundaryRegisterCorpCustomer();
        customerDAO = new CustomerDAO();
    }
    /**
     * 画面起動メソッド.
     */
    public void start() {
        boundaryRegisterCorpCustomer.setControlCorpCustomer(this);
        boundaryRegisterCorpCustomer.setVisible(true);
    }
    
    /**
     * システムメニューへの帰還メソッド.
     * @author 20jz0132
     */
    public void exit() {
        boundaryRegisterCorpCustomer.setVisible(false);
        boundaryRegisterCorpCustomer.clear();
        super.getControlSystemMenu().exitContents();
    }
    /**
     * ログイン画面への帰還メソッド.
     */
    public void exitLogout() {
        boundaryRegisterCorpCustomer.setVisible(false);
        boundaryRegisterCorpCustomer.clear();
        super.getControlSystemMenu().exit();
    }
    
    /**
     * 引数の情報を基に法人顧客を登録する.
     * @param name 顧客名
     * @param TEL   電話番号
     * @param address 住所
     */
    public void registerCorpCustomer(String name, String TEL, String address) {
        Customer customer = new Customer(TEL, address, name, false);
        if (customerDAO.dbInsertCustomer(customer) == 1) {
            boundaryRegisterCorpCustomer.clear();
            boundaryRegisterCorpCustomer.showPlainDialog("顧客を登録しました");
        }
        else {
            boundaryRegisterCorpCustomer.showErrorDialog("顧客の登録に失敗しました");
        }
    }
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        new ControlCorpCustomer().start();
    }
}

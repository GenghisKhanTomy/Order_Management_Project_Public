import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import orderListBC.OrderListButtonEditor;
import bcSuper.ButtonRenderer;

public class JButtonTableExample {

    public JButtonTableExample() {
        JFrame frame = new JFrame("JButtonTable Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        String[] heading = {"注文コード", "注文日時", "詳細を表示"};
        DefaultTableModel dm = new DefaultTableModel(heading, 0);
//        dm.setDataVector(new Object[][]{{"button 1", "foo"},
//                    {"button 2", "bar"}}, new Object[]{"Button", "String"});

        JTable table = new JTable();
        table.setModel(dm);
        table.getColumn("詳細を表示").setCellRenderer(new ButtonRenderer());
//        table.getColumn("詳細を表示").setCellEditor(new ButtonEditor(new JCheckBox()));

        dm.addRow(heading);

        JScrollPane scroll = new JScrollPane(table);

        table.setPreferredScrollableViewportSize(table.getPreferredSize());//thanks mKorbel +1 http://stackoverflow.com/questions/10551995/how-to-set-jscrollpane-layout-to-be-the-same-as-jtable

        table.getColumnModel().getColumn(0).setPreferredWidth(100);//so buttons will fit and not be shown butto..

        frame.add(scroll);

        frame.pack();
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new JButtonTableExample();
            }
        });

    }
}



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package orderListBC;

import bcSuper.ButtonEditor;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import orderListBC.BoundaryOrderList;

/**
 *
 * @author 20jz0105
 */
public class OrderListButtonEditor extends ButtonEditor {
    private BoundaryOrderList boundaryOrderList;
        
    public OrderListButtonEditor(JCheckBox checkBox, BoundaryOrderList boundaryOrderList) {
        super(checkBox);
        setBoundaryOrderList(boundaryOrderList);
    }

    public void setBoundaryOrderList(BoundaryOrderList boundaryOrderList) {
        this.boundaryOrderList = boundaryOrderList;
    }

    @Override
    public Object getCellEditorValue() {
        if (isPushed) {
            if (boundaryOrderList.showConfirmYesNo("詳細に移動しますか？") == JOptionPane.YES_OPTION) {
                boundaryOrderList.showDetail();
            }
        }
        isPushed = false;
        return label;
    }

}
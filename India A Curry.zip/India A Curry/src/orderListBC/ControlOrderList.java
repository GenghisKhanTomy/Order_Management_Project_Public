package orderListBC;

import DAO.CustomerDAO;
import DAO.DBManager;
import DAO.OrderDAO;
import DAO.OrderListViewDAO;
import DAO.OrderVoucherViewDAO;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import model.Employee;
import model.OrderListView;
import model.OrderVoucherView;
import orderStatusBC.ControlOrderStatus;


/**
 * 注文一覧コントロール
 * @author 20jz0105
 */
public class ControlOrderList extends bcSuper.ControlSuper {
    private BoundaryOrderList boundaryOrderList;
    private OrderListViewDAO orderListViewDAO;
    private List<OrderListView> ividualOrderListViewList;
    private List<OrderListView> allOrderListViewList;
    private ControlOrderStatus controlOrderStatus;
    private Employee employee;
    private OrderDAO orderDAO;
    private OrderVoucherViewDAO orderVoucherViewDAO;
    private CustomerDAO customerDAO;
    
    public ControlOrderList() {
        boundaryOrderList = new BoundaryOrderList();
        orderListViewDAO = new OrderListViewDAO();        
        orderDAO = new OrderDAO();
        orderVoucherViewDAO = new OrderVoucherViewDAO();
        customerDAO = new CustomerDAO();
        employee = new Employee();
    }

    public void setControlOrderStatus(ControlOrderStatus controlOrderStatus) {
        this.controlOrderStatus = controlOrderStatus;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }
    
    
    /**
     * 画面起動メソッド.
     */
    public void start() {
        boundaryOrderList.setControlOrderList(this);
        fetchIvidualOrderList();
        fetchAllOrderList();
        boundaryOrderList.setVisblePayment(employee.isJobType());
        boundaryOrderList.setVisible(true);        
    }
    /**
     * システムメニューへの帰還メソッド.
     */
    public void exit() {
        boundaryOrderList.setVisible(false);
        boundaryOrderList.clear();
        super.getControlSystemMenu().exitContents();        
    }
    /**
     * 注文状態表示画面からの帰還メソッド.
     */
    public void exitContents() {
        fetchAllOrderList();
        fetchIvidualOrderList();
        boundaryOrderList.setVisible(true);
    }
    /**
     * ログイン画面への帰還メソッド.
     */
    public void exitLogout() {
        boundaryOrderList.setVisible(false);
        super.getControlSystemMenu().exit();
    }
    /**
     * 法人顧客の当日の注文及び個人顧客の注文リストを取得する.
     */
    public void fetchAllOrderList() {       
        allOrderListViewList = orderListViewDAO.dbSearchPaymentNullCorpDateTodayORIvidual();
        DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy年MM月dd日 HH時mm分");
        boundaryOrderList.clearAllOrder();
        for (OrderListView orderListView : allOrderListViewList) {
            boundaryOrderList.appendAllOrder(new Object[]{orderListView.getOrderCode(), orderListView.getOrderTimestamp().toLocalDateTime().format(format),
                                            orderListView.getCutomerName(), constant.OrderStatusList.getStringOrderStatus(orderListView.getIntOrderStatus()), orderListView.getFinalyCost(), "詳細を表示"});

        }
    }
    /**
     * 個人顧客の注文リストを取得する. 
     */
    public void fetchIvidualOrderList() {       
        ividualOrderListViewList = orderListViewDAO.dbSearchPaymentNullIvidual();
        DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy年MM月dd日 HH時mm分");
        boundaryOrderList.clearIvidualOrder();
        for (OrderListView orderListView : ividualOrderListViewList) {
            boundaryOrderList.appendIvidualOrder(new Object[]{orderListView.getOrderCode(), orderListView.getOrderTimestamp().toLocalDateTime().format(format),
                                            orderListView.getCutomerName(), constant.OrderStatusList.getStringOrderStatus(orderListView.getIntOrderStatus()), orderListView.getFinalyCost(), "詳細を表示", false});

        }
    }
    /**
     * 選択された注文の詳細を表示.
     * @param orderCode
     */
    public void awakenOrderStatus(int orderCode) {
        controlOrderStatus.fetchOrderStatus(orderCode);
        boundaryOrderList.setVisible(false);        
        controlOrderStatus.setReturnOrderListButtonVisble();
        controlOrderStatus.start();
    }
    /**
     * 入金を確定し、入金処理を行う.
     * 　個人顧客での入金処理
     * @param orderCodeList 
     */
    public void storeIvidualPayment(List<Integer> orderCodeList) {
        if (orderCodeList.size() > 0) {
            try {
                if (orderDAO.dbMultiUpdatePaymentDate(orderCodeList, Timestamp.valueOf(LocalDateTime.now())) == orderCodeList.size()) {
                    for (Integer orderCode : orderCodeList) {//ポイントはトリガーによる自動化にしたい
                        OrderVoucherView orderVoucherView = orderVoucherViewDAO.dbSearchOrderCode(orderCode);
                        if (customerDAO.dbUpdateAddReward(orderVoucherView.getCustomerTEL(), orderVoucherView.getAddedReward()) != 1) {
                            throw new Exception();
                        }
                    }
                    boundaryOrderList.showPlainDialog("入金が完了しました");
                    orderCodeList = null;                    
                    fetchIvidualOrderList();
                    fetchAllOrderList();
                }
                else {
                    throw new Exception();
                }
            }
            catch (Exception e) {
                if (DBManager.getDBManager().getConnection() != null) {
                    if (orderDAO != null && orderCodeList != null) {
                        orderDAO.dbMultiUpdatePaymentDate(orderCodeList, null);
                    }                    
                }
                boundaryOrderList.showErrorDialog("入金処理に失敗しました");
            }
        }
    }
    
    
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        new ControlOrderList().start();
    }
}

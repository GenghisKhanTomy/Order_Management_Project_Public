package orderListBC;

import javax.swing.table.DefaultTableModel;

/**
 *
 * @author 20jz0105
 */
public class OrderListTableModel extends DefaultTableModel {
    private int orderCodeColumn;
    private int orderTimestampColumn;
    private int customerNameColumn;
    private int orderStatusColumn;
    private int finalyCostColumn;
    private int showDetailColumn;
    private int checkColumn;
    
    public OrderListTableModel(Object[] os, int i) {
        super(os, i);
        for (int column = 0; column < getColumnCount(); column++) {
            if ("注文番号".equals(getColumnName(column))) {
                setOrderCodeColumn(column);
            }
            else if ("注文日時".equals(getColumnName(column))) {
                setOrderTimestampColumn(column);
            }
            else if ("顧客名".equals(getColumnName(column))) {
                setCustomerNameColumn(column);
            }
            else if ("注文状態".equals(getColumnName(column))) {
                setOrderStatusColumn(column);
            }
            else if ("請求金額".equals(getColumnName(column))) {
                setFinalyCostColumn(column);
            }
            else if ("詳細".equals(getColumnName(column))) {
                setShowDetailColumn(column);
            }
            else if ("入金チェック".equals(getColumnName(column))) {
                setCheckColumn(column);
            }
        }
    }
    @Override
    public boolean isCellEditable(int row, int column) {
        return column == getShowDetailColumn() || column == getCheckColumn();   
    }
    @Override
    public Class<?> getColumnClass(int column) {
         return column == getCheckColumn() ? Boolean.class : super.getColumnClass(column);
    }
    
    public int getOrderCodeColumn() {
        return orderCodeColumn;
    }

    public int getOrderTimestampColumn() {
        return orderTimestampColumn;
    }

    public int getCustomerNameColumn() {
        return customerNameColumn;
    }

    public int getOrderStatusColumn() {
        return orderStatusColumn;
    }

    public int getFinalyCostColumn() {
        return finalyCostColumn;
    }

    public int getShowDetailColumn() {
        return showDetailColumn;
    }

    public int getCheckColumn() {
        return checkColumn;
    }

    public void setOrderCodeColumn(int orderCodeColumn) {
        this.orderCodeColumn = orderCodeColumn;
    }

    public void setOrderTimestampColumn(int orderTimestampColumn) {
        this.orderTimestampColumn = orderTimestampColumn;
    }

    public void setCustomerNameColumn(int customerNameColumn) {
        this.customerNameColumn = customerNameColumn;
    }

    public void setOrderStatusColumn(int orderStatusColumn) {
        this.orderStatusColumn = orderStatusColumn;
    }

    public void setFinalyCostColumn(int finalyCostColumn) {
        this.finalyCostColumn = finalyCostColumn;
    }

    public void setShowDetailColumn(int showDetailColumn) {
        this.showDetailColumn = showDetailColumn;
    }

    public void setCheckColumn(int checkColumn) {
        this.checkColumn = checkColumn;
    }
    
}

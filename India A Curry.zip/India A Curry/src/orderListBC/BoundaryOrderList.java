package orderListBC;

import bcSuper.ButtonRenderer;
import dateTimeLabel.DateTimeLabel;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;

/**
 *
 * @author 20jz0105
 */
public class BoundaryOrderList extends bcSuper.BoundarySuper {
    private ControlOrderList controlOrderList;
    private OrderListTableModel orderListIvidualTableModel;
    private OrderListTableModel orderListAllTableModel;
    private TableColumn paymentCheckColumn;
    private boolean paymentCheckColumnVisible;
    /**
     * Creates new form BoundaryOrderList
     */
    public BoundaryOrderList() {
        initComponents();
        setTitle("Indoor A Curry 注文一覧表示");
        initIvidualTableModel();
        initAllTableModel();
        clear();
        setMinimumSize(getSize());//画面サイズの最小値設定
        setIcon(jLabelIcon);
        setLocationRelativeTo(this);
    }

    public ControlOrderList getControlOrderList() {
        return controlOrderList;
    }

    public void setControlOrderList(ControlOrderList controlOrderList) {
        this.controlOrderList = controlOrderList;
    }
    
    public void setVisblePayment(boolean tf) {
        if(tf) {
            if (!paymentCheckColumnVisible) {
                jTableIvidualOrder.addColumn(paymentCheckColumn);            
                paymentCheckColumnVisible = true;
            }
        }
        else {
            if (paymentCheckColumnVisible) {
                jTableIvidualOrder.removeColumn(paymentCheckColumn);
                paymentCheckColumnVisible = false;
            }
        }
        jButtonDeteminePayment.setVisible(tf);
    }
    
    /**
     * テーブルモデルの初期化と表との連携.
     * @author 20jz0105
     */
    public void initIvidualTableModel() {        
        String buttonTitle = "詳細";
        String checkTitle = "入金チェック";
        String[] heading = {"注文番号", "注文日時", "顧客名", "注文状態", "請求金額", buttonTitle, checkTitle};
        orderListIvidualTableModel = new OrderListTableModel(heading, 0);        
        jTableIvidualOrder.getTableHeader().setFont(jTableIvidualOrder.getFont());
        jTableIvidualOrder.setModel(orderListIvidualTableModel);
        paymentCheckColumn = jTableIvidualOrder.getColumn(checkTitle);
        paymentCheckColumnVisible = true;
        
        Action action = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (showConfirmYesNo("詳細に移動しますか？") == JOptionPane.YES_OPTION) {
                    showDetail();
                }
            }
        };
        jTableIvidualOrder.getActionMap().put("MY_CUSTOM_ACTION", action);
        jTableIvidualOrder.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0, false), "MY_CUSTOM_ACTION");
        
        
        jTableIvidualOrder.getColumn(buttonTitle).setCellRenderer(new ButtonRenderer());
        jTableIvidualOrder.getColumn(buttonTitle).setCellEditor(new OrderListButtonEditor(new JCheckBox(), this));
        jTableIvidualOrder.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                
        DefaultTableCellRenderer rightCellRenderer = new DefaultTableCellRenderer();
        rightCellRenderer.setHorizontalAlignment(JLabel.RIGHT);        

        jTableIvidualOrder.getColumnModel().getColumn(orderListIvidualTableModel.getOrderCodeColumn()).setCellRenderer(rightCellRenderer);
        jTableIvidualOrder.getColumnModel().getColumn(orderListIvidualTableModel.getFinalyCostColumn()).setCellRenderer(rightCellRenderer);

        jTableIvidualOrder.getColumnModel().getColumn(orderListIvidualTableModel.getOrderCodeColumn()).setPreferredWidth(60);
        jTableIvidualOrder.getColumnModel().getColumn(orderListIvidualTableModel.getOrderTimestampColumn()).setPreferredWidth(150);
        jTableIvidualOrder.getColumnModel().getColumn(orderListIvidualTableModel.getCustomerNameColumn()).setPreferredWidth(150);
        jTableIvidualOrder.getColumnModel().getColumn(orderListIvidualTableModel.getOrderStatusColumn()).setPreferredWidth(40);
        jTableIvidualOrder.getColumnModel().getColumn(orderListIvidualTableModel.getFinalyCostColumn()).setPreferredWidth(40);
        jTableIvidualOrder.getColumnModel().getColumn(orderListIvidualTableModel.getShowDetailColumn()).setPreferredWidth(90);
        jTableIvidualOrder.getColumnModel().getColumn(orderListIvidualTableModel.getCheckColumn()).setPreferredWidth(30);
    }
    /**
     * テーブルモデルの初期化と表との連携.
     * @author 20jz0105
     */
    public void initAllTableModel() {        
        String buttonTitle = "詳細";
        String checkTitle = "入金チェック";
        String[] heading = {"注文番号", "注文日時", "顧客名", "注文状態", "請求金額", buttonTitle, checkTitle};
        orderListAllTableModel = new OrderListTableModel(heading, 0);
        jTableAllOrder.getTableHeader().setFont(jTableAllOrder.getFont());
        jTableAllOrder.setModel(orderListAllTableModel);
        jTableAllOrder.removeColumn(jTableAllOrder.getColumn(checkTitle));
        
        Action action = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (showConfirmYesNo("詳細に移動しますか？") == JOptionPane.YES_OPTION) {
                    showDetail();
                }
            }
        };
        jTableAllOrder.getActionMap().put("MY_CUSTOM_ACTION", action);
        jTableAllOrder.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0, false), "MY_CUSTOM_ACTION");
        
        jTableAllOrder.getColumn(buttonTitle).setCellRenderer(new ButtonRenderer(this));
        jTableAllOrder.getColumn(buttonTitle).setCellEditor(new OrderListButtonEditor(new JCheckBox(), this));
        jTableAllOrder.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                
        DefaultTableCellRenderer rightCellRenderer = new DefaultTableCellRenderer();
        rightCellRenderer.setHorizontalAlignment(JLabel.RIGHT);        

        jTableAllOrder.getColumnModel().getColumn(orderListAllTableModel.getOrderCodeColumn()).setCellRenderer(rightCellRenderer);
        jTableAllOrder.getColumnModel().getColumn(orderListAllTableModel.getFinalyCostColumn()).setCellRenderer(rightCellRenderer);

        jTableAllOrder.getColumnModel().getColumn(orderListAllTableModel.getOrderCodeColumn()).setPreferredWidth(60);
        jTableAllOrder.getColumnModel().getColumn(orderListAllTableModel.getOrderTimestampColumn()).setPreferredWidth(150);
        jTableAllOrder.getColumnModel().getColumn(orderListAllTableModel.getCustomerNameColumn()).setPreferredWidth(150);
        jTableAllOrder.getColumnModel().getColumn(orderListAllTableModel.getOrderStatusColumn()).setPreferredWidth(40);
        jTableAllOrder.getColumnModel().getColumn(orderListAllTableModel.getFinalyCostColumn()).setPreferredWidth(40);
        jTableAllOrder.getColumnModel().getColumn(orderListAllTableModel.getShowDetailColumn()).setPreferredWidth(90);    
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroupIvidualAll = new javax.swing.ButtonGroup();
        PHeader = new javax.swing.JPanel();
        jButtonReturnPage = new javax.swing.JButton();
        LTitle = new javax.swing.JLabel();
        LTimer = new DateTimeLabel("yyyy/MM/dd HH:mm:ss");
        jLabelIcon = new javax.swing.JLabel();
        PanelOrderNumber = new javax.swing.JPanel();
        LCustomerCategory = new javax.swing.JLabel();
        jRadioButtonAll = new javax.swing.JRadioButton();
        jRadioButtonIvidual = new javax.swing.JRadioButton();
        jTabbedPaneCustomerType = new javax.swing.JTabbedPane();
        PanelAll = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTableAllOrder = new javax.swing.JTable();
        PanelIvidual = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableIvidualOrder = new javax.swing.JTable();
        jButtonDeteminePayment = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        PHeader.setBackground(new java.awt.Color(204, 255, 255));
        PHeader.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jButtonReturnPage.setText("メニュー画面に戻る");
        jButtonReturnPage.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jButtonReturnPageFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jButtonReturnPageFocusLost(evt);
            }
        });
        jButtonReturnPage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonReturnPageActionPerformed(evt);
            }
        });

        LTitle.setBackground(new java.awt.Color(255, 255, 255));
        LTitle.setFont(new java.awt.Font("MS UI Gothic", 0, 24)); // NOI18N
        LTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LTitle.setText("注文一覧表示");
        LTitle.setOpaque(true);

        LTimer.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        LTimer.setText("yyyy年mm月dd日 HH:mm:ss");

        jLabelIcon.setText("jLabel1");

        javax.swing.GroupLayout PHeaderLayout = new javax.swing.GroupLayout(PHeader);
        PHeader.setLayout(PHeaderLayout);
        PHeaderLayout.setHorizontalGroup(
            PHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PHeaderLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(LTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(PHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(LTimer, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonReturnPage, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        PHeaderLayout.setVerticalGroup(
            PHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PHeaderLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(PHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelIcon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(PHeaderLayout.createSequentialGroup()
                        .addGroup(PHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(LTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(PHeaderLayout.createSequentialGroup()
                                .addComponent(jButtonReturnPage)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(LTimer)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        PanelOrderNumber.setBackground(new java.awt.Color(204, 204, 255));

        LCustomerCategory.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        LCustomerCategory.setText("表示対象注文");

        buttonGroupIvidualAll.add(jRadioButtonAll);
        jRadioButtonAll.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jRadioButtonAll.setSelected(true);
        jRadioButtonAll.setText("法人顧客の注文（当日のみ）含む");
        jRadioButtonAll.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jRadioButtonAllFocusGained(evt);
            }
        });

        buttonGroupIvidualAll.add(jRadioButtonIvidual);
        jRadioButtonIvidual.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jRadioButtonIvidual.setText("個人顧客の注文のみ");
        jRadioButtonIvidual.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jRadioButtonIvidualFocusGained(evt);
            }
        });

        jTabbedPaneCustomerType.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                jTabbedPaneCustomerTypeStateChanged(evt);
            }
        });

        jScrollPane3.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane3.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        jTableAllOrder.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jTableAllOrder.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTableAllOrder.setRowHeight(20);
        jScrollPane3.setViewportView(jTableAllOrder);

        javax.swing.GroupLayout PanelAllLayout = new javax.swing.GroupLayout(PanelAll);
        PanelAll.setLayout(PanelAllLayout);
        PanelAllLayout.setHorizontalGroup(
            PanelAllLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelAllLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 974, Short.MAX_VALUE)
                .addContainerGap())
        );
        PanelAllLayout.setVerticalGroup(
            PanelAllLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelAllLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 426, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(66, Short.MAX_VALUE))
        );

        jTabbedPaneCustomerType.addTab("法人顧客の注文（当日のみ）含む", PanelAll);

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        jTableIvidualOrder.setFont(new java.awt.Font("MS UI Gothic", 0, 18)); // NOI18N
        jTableIvidualOrder.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTableIvidualOrder.setRowHeight(20);
        jScrollPane1.setViewportView(jTableIvidualOrder);

        jButtonDeteminePayment.setFont(new java.awt.Font("MS UI Gothic", 0, 14)); // NOI18N
        jButtonDeteminePayment.setText("チェックした注文を入金する");
        jButtonDeteminePayment.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jButtonDeteminePaymentFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jButtonDeteminePaymentFocusLost(evt);
            }
        });
        jButtonDeteminePayment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonDeteminePaymentActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout PanelIvidualLayout = new javax.swing.GroupLayout(PanelIvidual);
        PanelIvidual.setLayout(PanelIvidualLayout);
        PanelIvidualLayout.setHorizontalGroup(
            PanelIvidualLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelIvidualLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(PanelIvidualLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 974, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelIvidualLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButtonDeteminePayment)))
                .addContainerGap())
        );
        PanelIvidualLayout.setVerticalGroup(
            PanelIvidualLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelIvidualLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 426, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButtonDeteminePayment)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        jTabbedPaneCustomerType.addTab("個人顧客の注文のみ", PanelIvidual);

        javax.swing.GroupLayout PanelOrderNumberLayout = new javax.swing.GroupLayout(PanelOrderNumber);
        PanelOrderNumber.setLayout(PanelOrderNumberLayout);
        PanelOrderNumberLayout.setHorizontalGroup(
            PanelOrderNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelOrderNumberLayout.createSequentialGroup()
                .addGroup(PanelOrderNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(PanelOrderNumberLayout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(LCustomerCategory)
                        .addGap(55, 55, 55)
                        .addComponent(jRadioButtonAll)
                        .addGap(35, 35, 35)
                        .addComponent(jRadioButtonIvidual))
                    .addGroup(PanelOrderNumberLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jTabbedPaneCustomerType, javax.swing.GroupLayout.PREFERRED_SIZE, 999, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PanelOrderNumberLayout.setVerticalGroup(
            PanelOrderNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelOrderNumberLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(PanelOrderNumberLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRadioButtonAll)
                    .addComponent(jRadioButtonIvidual)
                    .addComponent(LCustomerCategory))
                .addGap(27, 27, 27)
                .addComponent(jTabbedPaneCustomerType)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PHeader, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(PanelOrderNumber, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(PHeader, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(PanelOrderNumber, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonReturnPageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonReturnPageActionPerformed
        controlOrderList.exit();
    }//GEN-LAST:event_jButtonReturnPageActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        controlOrderList.exitLogout();
    }//GEN-LAST:event_formWindowClosing

    private void jButtonDeteminePaymentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonDeteminePaymentActionPerformed
        List<Integer> orderCodeList = new ArrayList<>();
        for (int i = 0; i < jTableIvidualOrder.getRowCount(); i++) {
            if ((boolean)orderListIvidualTableModel.getValueAt(i, orderListIvidualTableModel.getCheckColumn())) {
                orderCodeList.add((int)orderListIvidualTableModel.getValueAt(i, orderListIvidualTableModel.getOrderCodeColumn()));
            }
        }
        if (orderCodeList.size() > 0) {
            controlOrderList.storeIvidualPayment(orderCodeList);
        }
        else {
            showErrorDialog("入金する注文にチェックをつけてください");
        }
    }//GEN-LAST:event_jButtonDeteminePaymentActionPerformed

    private void jButtonReturnPageFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonReturnPageFocusGained
        getRootPane().setDefaultButton(jButtonReturnPage);
    }//GEN-LAST:event_jButtonReturnPageFocusGained

    private void jButtonReturnPageFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonReturnPageFocusLost
        getRootPane().setDefaultButton(null);
    }//GEN-LAST:event_jButtonReturnPageFocusLost

    private void jButtonDeteminePaymentFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonDeteminePaymentFocusGained
       getRootPane().setDefaultButton(jButtonDeteminePayment);
    }//GEN-LAST:event_jButtonDeteminePaymentFocusGained

    private void jButtonDeteminePaymentFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButtonDeteminePaymentFocusLost
       getRootPane().setDefaultButton(null);
    }//GEN-LAST:event_jButtonDeteminePaymentFocusLost

    private void jTabbedPaneCustomerTypeStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jTabbedPaneCustomerTypeStateChanged
        switch(jTabbedPaneCustomerType.getSelectedIndex()) {
            case 0:
                setAllRadioSelected(true);                
                break;
            case 1:
                setIvidualRadioSelected(true);
                break;
            default:
                break;
        }
    }//GEN-LAST:event_jTabbedPaneCustomerTypeStateChanged

    private void jRadioButtonIvidualFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jRadioButtonIvidualFocusGained
        setTabSelected(1);
    }//GEN-LAST:event_jRadioButtonIvidualFocusGained

    private void jRadioButtonAllFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jRadioButtonAllFocusGained
        setTabSelected(0);
    }//GEN-LAST:event_jRadioButtonAllFocusGained
    /**
     * 画面のクリア.
     */
    public void clear() {
        setAllRadioSelected(true);
        setTabSelected(0);
    }
    /**
     * 個人ラジオボタンを有効/無効にする.
     * @param tf true 有効化 / false 無効化
     */
    public void setAllRadioSelected(boolean tf) {
        jRadioButtonAll.setSelected(tf);
        jButtonReturnPage.setNextFocusableComponent(jRadioButtonAll);
        jRadioButtonAll.setNextFocusableComponent(jTabbedPaneCustomerType);
    }
    /**
     * 法人ラジオボタンを有効/無効にする.
     * @param tf true 有効化 / false 無効化
     */
    public void setIvidualRadioSelected(boolean tf) {
        jRadioButtonIvidual.setSelected(tf);
        jButtonReturnPage.setNextFocusableComponent(jRadioButtonIvidual);
        jRadioButtonIvidual.setNextFocusableComponent(jTabbedPaneCustomerType);    }
    /**
     * 指定されたタブを選択状態にする.
     * @param idx タブの番号
     */
    public void setTabSelected(int idx) {
        jTabbedPaneCustomerType.setSelectedIndex(idx);
    }

    /**
     * 個人顧客注文テーブルのクリア.
     */
    public void clearIvidualOrder() {
        orderListIvidualTableModel.setRowCount(0);
    }
    /**
     * 注文テーブルのクリア.
     */
    public void clearAllOrder() {
        orderListAllTableModel.setRowCount(0);
    }
    /**
     * 個人顧客注文テーブルへの行データ追加.
     * @param rowData 
     */
    public void appendIvidualOrder(Object[] rowData) {
        orderListIvidualTableModel.addRow(rowData);
    }
    /**
     * 注文テーブルへの行データ追加.
     * @param rowData 
     */
    public void appendAllOrder(Object[] rowData) {
        orderListAllTableModel.addRow(rowData);
    }
    /**
     * 詳細への遷移.
     */
    public void showDetail() {
        JTable jTable;
        if (jTabbedPaneCustomerType.getSelectedIndex() == 0) {
            jTable = jTableAllOrder;
        }
        else {
            jTable = jTableIvidualOrder;
        }
        int idx = jTable.getSelectedRow();
        if (idx >= 0) {
            controlOrderList.awakenOrderStatus((int)jTable.getModel().getValueAt(idx, orderListIvidualTableModel.getOrderCodeColumn()));
        }
    }
    
//    /**
//     * 指定されたタブを有効/無効にする.
//     * @param idx タブの番号
//     * @param tf true 有効化 / false 無効化
//     */
//    public void setTabSelected(int idx, boolean tf) {
//        jTabbedPaneCustomerType.setEnabledAt(idx, tf);
//        jTabbedPaneCustomerType.setEnabledAt(idx ^ 1, !tf);
//        jTabbedPaneCustomerType.setSelectedIndex(idx);
//    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BoundaryOrderList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BoundaryOrderList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BoundaryOrderList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BoundaryOrderList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BoundaryOrderList().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LCustomerCategory;
    private javax.swing.JLabel LTimer;
    private javax.swing.JLabel LTitle;
    private javax.swing.JPanel PHeader;
    private javax.swing.JPanel PanelAll;
    private javax.swing.JPanel PanelIvidual;
    private javax.swing.JPanel PanelOrderNumber;
    private javax.swing.ButtonGroup buttonGroupIvidualAll;
    private javax.swing.JButton jButtonDeteminePayment;
    private javax.swing.JButton jButtonReturnPage;
    private javax.swing.JLabel jLabelIcon;
    private javax.swing.JRadioButton jRadioButtonAll;
    private javax.swing.JRadioButton jRadioButtonIvidual;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPaneCustomerType;
    private javax.swing.JTable jTableAllOrder;
    private javax.swing.JTable jTableIvidualOrder;
    // End of variables declaration//GEN-END:variables
}

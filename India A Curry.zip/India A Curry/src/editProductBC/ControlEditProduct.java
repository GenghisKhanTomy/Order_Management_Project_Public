package editProductBC;

import DAO.ProdcutDetailsDAO;
import DAO.ProductDAO;
import java.sql.Date;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import model.Product;
import model.ProductDetails;
import productListBC.ControlProductList;

/**
 *
 * @author とよA
 */
public class ControlEditProduct extends bcSuper.ControlSuper {
    private BoundaryEditProduct boundaryEditProduct;
    private ControlProductList controlProductList;
    private ProductDAO productDAO;
    private ProdcutDetailsDAO prodcutDetailsDAO;
    private List<Product> productsTargetList;
    private List<Product> productsToTabList;
    private List<ProductDetails> productDetailseList;
    

    public ControlEditProduct() {
        boundaryEditProduct = new BoundaryEditProduct();
        productDAO = new ProductDAO();
        prodcutDetailsDAO = new ProdcutDetailsDAO(); //商品構成テーブルに情報を入力するために利用
        productsTargetList = new ArrayList<>(); //変更したい商品候補格納リスト
        productsToTabList = new ArrayList<>(); //構成商品候補の格納リスト
        productDetailseList = new ArrayList<>();
    }
    /**
     * システムメニューに戻るボタンを表示し、商品一覧画面に戻るボタンを非表示にする.
     */
    public void setReturnButtonVisble() {
        boundaryEditProduct.setReturnButtonVisble();
    }
    /**
     * システムメニューに戻るボタンを非表示にし、商品一覧画面に戻るボタンを表示する.
     */
    public void setReturnProductListButtonVisble() {
        boundaryEditProduct.setReturnOrderListButtonVisble();
    }    

    public void setControlProductList(ControlProductList controlProductList) {
        this.controlProductList = controlProductList;
    }
    
    /**
     * 画面起動メソッド.
     */
    public void startSelect() {
        boundaryEditProduct.setControl(this);
        addToAllProductToEditComboBox();
        addToAllProductToAddComboBox();
        boundaryEditProduct.setVisible(true);
    }
    /**
     * 画面起動メソッド.
     */
    public void start() {
        boundaryEditProduct.setControl(this);
        addToAllProductToAddComboBox();
        boundaryEditProduct.setVisible(true);
    }
        
    /**
     * システムメニューへの帰還メソッド.
     */
    public void exit() {
        boundaryEditProduct.setVisible(false);
        boundaryEditProduct.clear();
        super.getControlSystemMenu().exitContents();
    }
    /**
     * ログイン画面への帰還メソッド.
     */
    public void exitLogout() {
        boundaryEditProduct.setVisible(false);
        boundaryEditProduct.clear();
        super.getControlSystemMenu().exit();
    }
    /**
     * 選択した商品を削除
     * @param rows 
     */
    void removeProduct(int[] rows) {
        int size = rows.length;
        for (int i = size - 1; i >= 0; i--) {
            boundaryEditProduct.removeProductOrder(rows[i]);
        }
    }

    /**
     * 商品を部分検索し、結果を格納
     * @param includeSet セット商品を含める / 含めない
     * @param searchWord 検索キーワード
     */
    public void fetchProduct(boolean includeSet, String searchWord) {
        productsTargetList.clear();
        
        if (includeSet) {
            productsTargetList = productDAO.dbSearchSaleNoNameLike(searchWord);
            if (productsTargetList.size() > 0) {
                boundaryEditProduct.removeAllEditProductComboBox();
                for (Product product : productsTargetList) {
                    boundaryEditProduct.appendProductToEditCombBox(product);
                }
                boundaryEditProduct.successFetchProduct(includeSet);
                boundaryEditProduct.setTextSearchWord(searchWord);
            }
            else {
                boundaryEditProduct.showErrorDialog("[" + searchWord + "] は存在しません。もう一度ご確認ください。");
                boundaryEditProduct.focusSearchProductName();
            }            
        }
        else {
            productsTargetList = productDAO.dbSearchSaleNoNameLikeNotSet(searchWord);
            if (productsTargetList.size() > 0) {
                boundaryEditProduct.removeAllAddProductComboBox();
                for (Product product : productsTargetList) {
                    boundaryEditProduct.appendProductToAddCombBox(product);
                }
                boundaryEditProduct.successFetchProduct(includeSet);
            }
            else {
                boundaryEditProduct.showErrorDialog("[" + searchWord + "] は存在しません。もう一度ご確認ください。");
                boundaryEditProduct.focusAddProductName();
            }
        }
    }

    /**
     * 商品(productNo)が商品テーブル(productDetailsTableModel)に存在しているかの確認
     * @param productNo 対象商品番号
     * @param productDetailsTableModel 被検索対象テーブル
     * @return 一致した商品番号の添え字 / 見つからない時は-1
     */
    int getProductExists(String productNo, ProductDetailsTableModel productDetailsTableModel) {
        int size = productDetailsTableModel.getRowCount();
        int idx;
        boolean existsFlag = false;
        for (idx = 0; idx < size; idx++) {
            if (productNo.equals(productDetailsTableModel.getValueAt(idx, 0))) {
                existsFlag = true;
                break;
            }
        }
        if (!existsFlag) {
            idx = -1;
        }
        return idx;
    }
    
    void appendProduct(Product product) {
//        Object[] rowData = {product.getProductNo(), product.getProductName(), 
//                            product.getProductSalesStartDate(), product.getProdcutSalesEndDate(),
//                            product.getPrice(), 1};
        DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy年MM月dd日");
        Object[] rowData = {product.getProductNo(), product.getProductName(), 
                            product.getProductSalesStartDate() != null ? product.getProductSalesStartDate().toLocalDate().format(format) : null,
                            product.getProdcutSalesEndDate() != null ? product.getProdcutSalesEndDate().toLocalDate().format(format) : null,
                            product.getPrice(), 1};        
        boundaryEditProduct.appendProductToTable(rowData);
    }

    void updateProductQuantity(int rowIdx, int quantityColumn, int quantity) {
        boundaryEditProduct.updateProductOrder(quantity, rowIdx, quantityColumn);
        boundaryEditProduct.calculateTotalAmount();
    }

    void setProductDetailInfo(Product product) {
//        System.out.println(product.toString());
        boundaryEditProduct.setProductNo(product.getProductNo());
        boundaryEditProduct.setProductName(product.getProductName());
        boundaryEditProduct.setTypeName(product.getTypeName());
        boundaryEditProduct.setPrice(product.getPrice());
        boundaryEditProduct.setgetProductSalesStartDate(product.getProductSalesStartDate());
        boundaryEditProduct.setProdcutSalesEndDate(product.getProductSalesStartDate(), product.getProdcutSalesEndDate());
        
        //セット商品の時の処理
        boundaryEditProduct.clearProductTableModel();
        productDetailseList = prodcutDetailsDAO.dbSearchProductDetailsFromProductNo(product.getProductNo());
//        System.out.println("productDetailseList.size() : " + productDetailseList.size());
//        System.out.println("product.isProductType() : " + product.isProductType());
        if (product.isProductType() && productDetailseList.size() > 0) { 
            boundaryEditProduct.setEnableSelected(true, 1);
            
            for (ProductDetails productDetails : productDetailseList) {
                productDetails.println();
            }
            
            String rowProductNo[] = new String[productDetailseList.size()];
//            System.out.print("productDetailseList [ ");
//            for (int idx = 0; idx < productDetailseList.size(); idx++) {
//                rowProductNo[idx] = productDetailseList.get(idx).getProductDetail().getProductNo();
//                System.out.print(productDetailseList.get(idx).getProductDetail().getProductNo() + ": ");
//            }
//            System.out.println(" ]");
            productDetailseList.clear();
            
            productsToTabList = productDAO.dbSearchFromNoToProductIn(rowProductNo);
            if (productsToTabList.size() > 0) {
                String limitDate = "9999-12-31";//null;
                int i = 0;
                for (Product productToList : productsToTabList) {
                    appendProduct(productToList);
                    
                    Date date = productToList.getProdcutSalesEndDate();
                    if(date != null && limitDate.compareTo(date.toString()) > 0) {
                        limitDate = date.toString();
                    }
                }
                boundaryEditProduct.setStandardLimitDate(limitDate);
            }
            productsToTabList.clear();
        }
    }
    
    void removeProduct(String productNo, Date endDate) {
        try {
            if (productDAO.dbUpdateProdcutSalesEndDate(productNo, endDate) != 1 ){
                throw new Exception();
            }
        }
        catch (Exception e) {
            boundaryEditProduct.changedTab(0);
            boundaryEditProduct.showErrorDialog("商品の削除に失敗しました");
        }
    }

    void editProduct(boolean selectedSet, boolean unlimitSelected, ProductDetailsTableModel productDetailsTableModel, Product product) {
        if (unlimitSelected) {
//            System.out.println(".setProdcutSalesEndDate(null)");
            product.setProdcutSalesEndDate(null);
        }
//        System.out.println("product.toString() = " + product.toString() + " : " + product.getProductType());
        try {
            if (productDAO.dbUpdateProdcut(product) != 1 ){
                throw new Exception();
            }
//            System.out.println("productDetailsTableModel.getRowCount() : " + productDetailsTableModel.getRowCount());
            if (selectedSet && productDetailsTableModel.getRowCount() > 0) {
                int rowCnt = productDetailsTableModel.getRowCount();
                productDetailseList.clear();
                int tmp = prodcutDetailsDAO.dbDeleteProdcutDetails(product);
//                System.out.println("productDetailsTableModel.getRowCount() : " + tmp);
                if (tmp != 0) {
                        throw new Exception();
                }
                for (int row = 0; row < rowCnt; row++) {
                    productDetailseList.add(new ProductDetails(product, 
                                                                new Product((String)productDetailsTableModel.getValueAt(row, productDetailsTableModel.getProductNoColumn())), 
                                                                (int)productDetailsTableModel.getValueAt(row, productDetailsTableModel.getProductQuantityColumn())));
                }
                int i = 0;
                for(ProductDetails productDetails : productDetailseList) {
                    System.out.println("[" + i + "] productDetails.toString() : " + productDetails.toString());
                    if (prodcutDetailsDAO.dbInsertProductDetailsDAO(productDetails) != 1) {
                        throw new Exception();
                    }
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            boundaryEditProduct.changedTab(0);
            boundaryEditProduct.showErrorDialog("商品の変更に失敗しました");
        }
    }
    /**
     * 商品リストへの帰還メソッド.
     * @author 20jz0105
     */
    public void exitProductList() {
        boundaryEditProduct.setVisible(false);
        boundaryEditProduct.clear();
        controlProductList.exitContents();
    }
    /**
     * コンボボックスに全件追加.
     */
    public void addToAllProductToEditComboBox() {
        productsTargetList = productDAO.dbSearchSaleAllProduct();
        boundaryEditProduct.addedEditProduct(productsTargetList);
    }
    public void addToAllProductToAddComboBox() {
        productsTargetList = productDAO.dbSearchSaleNoNameLikeNotSet("");
        boundaryEditProduct.addedAddProduct(productsTargetList);
    }
    /**
     * 変更する商品の検索前準備.
     */
    public void fetchPreparation() {
        boundaryEditProduct.fetchPreparation();
    }
    /**
     * 先頭の商品を変更可能にする.
     */
    public void installProduct() {
        boundaryEditProduct.installProduct(0);
    }
        
    public static void main(String[] args) {
        new ControlEditProduct().start();
    }
}

package editProductBC;

import registerProductBC.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author とよA
 */
public class ProductDetailsTableModel extends DefaultTableModel {
    private int productNoColumn;
    private int productNameColumn;
    private int productSalesStartColumn;
    private int productSalesEndColumn;
    private int productPriceColumn;
    private int productQuantityColumn;
    private BoundaryEditProduct boundaryEditProduct;
//        String heading[] = {"商品番号", "商品名", "販売開始日", "販売終了日", "単価", "個数"};

    public ProductDetailsTableModel(Object[] os, int i) {
        super(os, i);    
        for (int column = 0; column < os.length; column++) {
            if ("商品番号".equals(getColumnName(column))) {
                setProductNoColumn(column);
            }
            else if ("商品名".equals(getColumnName(column))) {
                setProductNameColumn(column);
            }
            else if ("販売開始日".equals(getColumnName(column))) {
                setProductSalesStartColumn(column);
            }
            else if ("販売終了日".equals(getColumnName(column))) {
                setProductSalesEndColumn(column);
            }
            else if ("単価".equals(getColumnName(column))) {
                setProductPriceColumn(column);
            }
            else if ("個数".equals(getColumnName(column))) {
                setProductQuantityColumn(column);
            }
        }
    }

    public int getProductNoColumn() {
        return productNoColumn;
    }

    public void setProductNoColumn(int productNoColumn) {
        this.productNoColumn = productNoColumn;
    }

    public int getProductNameColumn() {
        return productNameColumn;
    }

    public void setProductNameColumn(int productNameColumn) {
        this.productNameColumn = productNameColumn;
    }

    public int getProductSalesStartColumn() {
        return productSalesStartColumn;
    }

    public void setProductSalesStartColumn(int productSalesStartColumn) {
        this.productSalesStartColumn = productSalesStartColumn;
    }

    public int getProductSalesEndColumn() {
        return productSalesEndColumn;
    }

    public void setProductSalesEndColumn(int productSalesEndColumn) {
        this.productSalesEndColumn = productSalesEndColumn;
    }

    public int getProductPriceColumn() {
        return productPriceColumn;
    }

    public void setProductPriceColumn(int productPriceColumn) {
        this.productPriceColumn = productPriceColumn;
    }
    
    public int getProductQuantityColumn() {
        return productQuantityColumn;
    }

    public void setProductQuantityColumn(int productQuantityColumn) {
        this.productQuantityColumn = productQuantityColumn;
    }

    public BoundaryEditProduct getBoundaryEditProduct() {
        return boundaryEditProduct;
    }

    public void setBoundaryEditProduct(BoundaryEditProduct boundaryEditProduct) {
        this.boundaryEditProduct = boundaryEditProduct;
    }

    @Override
    public boolean isCellEditable(int row, int column) {
        if ("個数".equals(getColumnName(column))) {
            return true;
        }
        else {
            return false;             
        }
    }
    
    @Override
    public void setValueAt(Object aValue, int row, int column) {
        if ("個数".equals(getColumnName(column))) {
            Pattern p = Pattern.compile("^[1-9]\\d*$");
            Matcher m = p.matcher(aValue.toString());
            if (m.matches()) {
                int val = Integer.parseInt(aValue.toString());
                if (val > 9999) {
                    val = 9999;
                }
                super.setValueAt(val, row, column);
                boundaryEditProduct.calculateTotalAmount();
            }
        }
        else {
            super.setValueAt(aValue, row, column);
        }

    }
}

package registerProductBC;

import DAO.DualDAO;
import DAO.ProductDAO;
import DAO.ProdcutDetailsDAO;
import model.Product;
import model.ProductDetails;
import java.sql.Date;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author とよA
 */
public class ControlRegisterProduct extends bcSuper.ControlSuper {
    private BoundaryRegisterProduct boundaryRegisterProduct;
    private ProductDAO productDAO;
    private ProdcutDetailsDAO prodcutDetailsDAO;
    private DualDAO dualDAO;
    private List<Product> productsList;
    private List<ProductDetails> productDetailseList;
    
    public ControlRegisterProduct() {
        boundaryRegisterProduct = new BoundaryRegisterProduct();
        productDAO = new ProductDAO();
        prodcutDetailsDAO = new ProdcutDetailsDAO();
        dualDAO = new DualDAO();
        productsList = new ArrayList<>();
        productDetailseList = new ArrayList<>();
    }
    
    /**
     * 画面起動メソッド.
     */
    public void start() {
        boundaryRegisterProduct.setControl(this);
        boundaryRegisterProduct.setVisible(true);
        addToAddProductToComboBox();
    }
    
    /**
     * システムメニューへの帰還メソッド.
     */
    public void exit() {
        boundaryRegisterProduct.setVisible(false);
        boundaryRegisterProduct.clear();
        super.getControlSystemMenu().exitContents();
    }
    /**
     * ログイン画面への帰還メソッド.
     */
    public void exitLogout() {
        boundaryRegisterProduct.setVisible(false);
        boundaryRegisterProduct.clear();
        super.getControlSystemMenu().exit();
    }
    /**
     * 商品の登録
     * @param limitedSelected 販売期間 limited(ture) / unlimited(fales)
     * @param multiSelected 商品タイプ multi(ture) / single(fales)
     * @param productDetailsTableModel 構成商品テーブル
     * @param productName 商品名
     * @param productCategory 商品カテゴリ
     * @param productFee 商品金額
     * @param startYmd 販売開始日
     * @param endYmd 販売終了日
     */
    void registerProduct(boolean limitedSelected, boolean multiSelected, ProductDetailsTableModel productDetailsTableModel, String productName, String productCategory, int productFee, String startYmd, String endYmd) {
        //前準備
//        int productType = multiSelected ? 0 : 1;
        boolean productType = multiSelected;
        Date endDate = limitedSelected ? Date.valueOf(endYmd) : null;
//        Product productMain = new Product(productName, productCategory, productFee, Date.valueOf(startYmd), endDate, productType);
        Product productMain = new Product(dualDAO.dbSearchSeqProductNextVal(), productName, productCategory, productFee, Date.valueOf(startYmd), endDate, productType);
        productDetailseList.clear();
        if (multiSelected) {
            int rowCnt = productDetailsTableModel.getRowCount();
            for (int row = 0; row < rowCnt; row++) {
                productDetailseList.add(new ProductDetails(productMain, 
                                                            new Product((String)productDetailsTableModel.getValueAt(row, productDetailsTableModel.getProductNoColumn())), 
                                                            (int)productDetailsTableModel.getValueAt(row, productDetailsTableModel.getProductQuantityColumn())));
            }
            /*
            for (ProductDetails productDetails : productDetailseList) {
                    System.out.println(productDetails.toString());
            }
            */
        }

        try {// 登録処理
            if (productDAO.dbInsertProduct(productMain) != 1) {
                throw new Exception();
            }
            if (multiSelected) { //セット商品の時のみ実行
                for (ProductDetails productDetails : productDetailseList) {
                    int ans = prodcutDetailsDAO.dbInsertProductDetailsDAO(productDetails);
                    if (ans != 1) {
                        System.out.println("error[insert row count] : " + ans);
                        throw  new Exception();
                    }
                }
            }
            boundaryRegisterProduct.showPlainDialog(String.format("商品番号[%s]で登録しました", productMain.getProductNo()));
        }
        catch (Exception e) {
//            e.printStackTrace();
            boundaryRegisterProduct.changedTab(0);
            boundaryRegisterProduct.showErrorDialog("商品の登録に失敗しました");
        }
    }

    /**
     * 選択した商品を削除
     * @param rows 
     */
    void removeProduct(int[] rows) {
        int size = rows.length;
        for (int i = size - 1; i >= 0; i--) {
            boundaryRegisterProduct.removeProductOrder(rows[i]);
        }
    }

    /**
     * 商品を部分検索し、結果を格納
     * @param searchWord 
     */
    void fetchProduct(String searchWord) {
        boundaryRegisterProduct.removeAllProduct();
        productsList.clear();
        
        productsList = productDAO.dbSearchSaleNoNameLikeNotSet(searchWord);
        if (productsList.size() > 0) {
            for (Product product : productsList) {
                boundaryRegisterProduct.appendProductToCombBox(product);
            }
        }
        else {
            boundaryRegisterProduct.showErrorDialog("[" + searchWord + "] は存在しません。もう一度ご確認ください。");
        }
    }

    /**
     * 商品(productNo)が商品テーブル(productDetailsTableModel)に存在しているかの確認
     * @param productNo 対象商品番号
     * @param productDetailsTableModel 被検索対象テーブル
     * @return 一致した商品番号の添え字 / 見つからない時は-1
     */
    int getProductExists(String productNo, ProductDetailsTableModel productDetailsTableModel) {
        int size = productDetailsTableModel.getRowCount();
        int idx;
        boolean existsFlag = false;
        for (idx = 0; idx < size; idx++) {
            if (productNo.equals(productDetailsTableModel.getValueAt(idx, 0))) {
                existsFlag = true;
                break;
            }
        }
        if (!existsFlag) {
            idx = -1;
        }
        return idx;
    }

    void appendProduct(Product product) {
//        Object[] rowData = {product.getProductNo(), product.getProductName(), 
//                            product.getProductSalesStartDate(), product.getProdcutSalesEndDate(),
//                            product.getPrice(), 1};
        DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy年MM月dd日");
        Object[] rowData = {product.getProductNo(), product.getProductName(), 
                            product.getProductSalesStartDate() != null ? product.getProductSalesStartDate().toLocalDate().format(format) : null,
                            product.getProdcutSalesEndDate() != null ? product.getProdcutSalesEndDate().toLocalDate().format(format) : null,
                            product.getPrice(), 1};             
        boundaryRegisterProduct.appendProductToTable(rowData);
    }

    void updateProductQuantity(int rowIdx, int quantityColumn, int quantity) {
        boundaryRegisterProduct.updateProductOrder(quantity, rowIdx, quantityColumn);
        boundaryRegisterProduct.calculateTotalAmount();
    }

    public void addToAddProductToComboBox() {
        productsList = productDAO.dbSearchSaleNoNameLikeNotSet("");
        boundaryRegisterProduct.addedProduct(productsList);
    }
    
    public static void main(String[] args) {
        new ControlRegisterProduct().start();
    }

}

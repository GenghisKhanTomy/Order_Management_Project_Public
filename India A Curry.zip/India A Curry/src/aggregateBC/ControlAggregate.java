package aggregateBC;

import java.io.IOException;

/**
 * 集計コントロール
 * @author 20jz0105
 */
public class ControlAggregate extends bcSuper.ControlSuper {
    private BoundaryAggregate boundaryAggregate;
    private ProcessBuilder processBuilder = new ProcessBuilder("java", "-jar", "DeliverySystemGraphMonth.jar");

    public ControlAggregate() {
        boundaryAggregate = new BoundaryAggregate();        
    }
    /**
     * 画面起動メソッド.
     */
    public void start() {
        boundaryAggregate.setControlAggregate(this);
        boundaryAggregate.setVisible(true);
    }
    
    /**
     * システムメニューへの帰還メソッド.
     */
    public void exit() {
        boundaryAggregate.setVisible(false);
        super.getControlSystemMenu().exitContents();
    }
    /**
     * ログイン画面への帰還メソッド.
     */
    public void exitLogout() {
        boundaryAggregate.setVisible(false);
        super.getControlSystemMenu().exit();
    }
    /**
     * 時間単位の集計結果を表示する.
     */
    public void showHoursGraph() {
        processBuilder = new ProcessBuilder("java", "-jar", "DeliverySystemGraphHour.jar");
        subProcessRun();
    }
    /**
     * 日単位の集計結果を表示する.
     */
    public void showDayGraph() {
        processBuilder = new ProcessBuilder("java", "-jar", "DeliverySystemGraphDay.jar");
        subProcessRun();
    }    
    /**
     * 月単位の集計結果を表示する.
     */        
    public void showMonthGraph() {
        processBuilder = new ProcessBuilder("java", "-jar", "DeliverySystemGraphMonth.jar");
        subProcessRun();
    }
    /**
     * 曜日単位の集計結果を表示する.
     */    
    public void showDayOfWeekGraph() {
        processBuilder = new ProcessBuilder("java", "-jar", "DeliverySystemGraphDayOfWeek.jar");
        subProcessRun();
    }
    /**
     * サブプロセスの実行.
     */
    public void subProcessRun() {
        try {
            System.out.println("start");
            boundaryAggregate.setVisible(false);
            Process process = processBuilder.start();
            process.waitFor();//サブプロセスが終わるまで待機
            boundaryAggregate.setVisible(true);
            System.out.println("end");
        }
        catch (IOException  | InterruptedException e) {
            System.out.println(e);
        }
    }
    
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        new ControlAggregate().start();
    }
}

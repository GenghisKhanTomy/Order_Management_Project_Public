package bcSuper;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

/**
 * フォーカスイベントクラス
 * 　不採用クラス
 * @author 20jz0105
 */
public class FocusListenerSuper implements FocusListener {
    private BoundarySuper boundarySuper;
    private ButtonRenderer buttonRenderer;
    public FocusListenerSuper(BoundarySuper boundarySuper, ButtonRenderer buttonRenderer) {
        this.boundarySuper = boundarySuper;
    }
    
    @Override
    public void focusGained(FocusEvent e) {
        boundarySuper.setDefaultButton(buttonRenderer);
    }

    @Override
    public void focusLost(FocusEvent e) {
        boundarySuper.setDefaultButton(null);
    }
}

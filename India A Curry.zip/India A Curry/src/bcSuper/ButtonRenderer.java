package bcSuper;

import java.awt.Component;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.table.TableCellRenderer;

/**
 * @author 20jz0105
 */
public class ButtonRenderer extends JButton implements TableCellRenderer {
    private BoundarySuper boundarySuper;

    public ButtonRenderer() {
        setOpaque(true);
    }
    /**
     * 未使用コンストラクタ
     * @param boundarySuper 
     */
    public ButtonRenderer(BoundarySuper boundarySuper) {
        setOpaque(true);
        addFocusListener(new FocusListenerSuper(boundarySuper, this));
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value,
        boolean isSelected, boolean hasFocus, int row, int column) {
        if (isSelected) {
            setForeground(table.getSelectionForeground());
            setBackground(table.getSelectionBackground());
        }
        else {
            setForeground(table.getForeground());
            setBackground(UIManager.getColor("Button.background"));
        }
        setText((value == null) ? "" : value.toString());
        return this;
    }
    
}
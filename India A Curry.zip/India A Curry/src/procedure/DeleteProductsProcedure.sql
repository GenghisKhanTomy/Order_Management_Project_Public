/**
 * 販売終了年月日を過ぎた商品を削除するプロシージャ
 * 未使用に決定
 * Author:  20jz0105
 * Created: 2021/12/26
 */
-- CREATE OR REPLACE PROCEDURE delete_products_procedure
-- IS
-- BEGIN
--   DELETE FROM products
--   WHERE TRUNC(SYSDATE, 'DD') > sales_end_date;
-- END;
-- /


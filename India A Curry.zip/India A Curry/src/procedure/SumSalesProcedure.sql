/**
 * その日の注文金額の合計を1時間単位で集計するプロシージャ
 * Author:  20jz0105
 * Created: 2021/12/23
 */

/**
 * 税金・サイズは考慮する
 * ポイント・送料は商品の売上には関与しないので考慮しない
 * 集計実行タイミングは日末
 */
CREATE OR REPLACE PROCEDURE sum_sales_procedure
IS
BEGIN
  INSERT INTO sales_summary
  SELECT TRUNC(order_date, 'HH24'), SUM(TRUNC((NVL(ph.price, p.price) + NVL(s.price, 0)) * 1.08) * od.quantity) , TO_CHAR(order_date, 'DY'),
         TO_NUMBER(TO_CHAR(order_date, 'YYYY')), TO_NUMBER(TO_CHAR(order_date, 'MM')),
         TO_NUMBER(TO_CHAR(order_date, 'DD')), TO_NUMBER(TO_CHAR(order_date, 'HH24'))
  FROM orders o
  JOIN order_details od ON o.order_code = od.order_code
  JOIN products p ON od.product_no = p.product_no
  LEFT JOIN sizes s ON od.size_no = s.size_no
  LEFT JOIN product_histories ph ON EXISTS (SELECT 0
                                            FROM product_histories
                                            WHERE ph.product_no = product_no AND record_date > o.order_date
                                            HAVING ph.record_date = MIN(record_date)) AND p.product_No = ph.product_no 
  WHERE TRUNC(SYSDATE - 1, 'DD') <= o.order_date AND o.order_date < TRUNC(SYSDATE, 'DD') AND o.cancel_type = 0 AND od.cancel_type = 0
  GROUP BY TRUNC(order_date, 'HH24'), TO_CHAR(order_date, 'DY'), TO_NUMBER(TO_CHAR(order_date, 'YYYY')), TO_NUMBER(TO_CHAR(order_date, 'MM')), TO_NUMBER(TO_CHAR(order_date, 'DD')), TO_NUMBER(TO_CHAR(order_date, 'HH24'))
  HAVING SUM(TRUNC((NVL(ph.price, p.price) + NVL(s.price, 0)) * 1.08) * od.quantity) IS NOT NULL;
  ORDER BY TRUNC(order_date, 'HH24')
END;
/

CREATE OR REPLACE PROCEDURE sum_sales_procedure
IS
BEGIN
  INSERT INTO sales_summary
  SELECT TRUNC(order_date, 'HH24'), SUM(TRUNC((NVL(ph.price, p.price) + NVL(s.price, 0)) * 1.08) * od.quantity) , TO_CHAR(order_date, 'DY'),
         TO_NUMBER(TO_CHAR(order_date, 'YYYY')), TO_NUMBER(TO_CHAR(order_date, 'MM')),
         TO_NUMBER(TO_CHAR(order_date, 'DD')), TO_NUMBER(TO_CHAR(order_date, 'HH24'))
  FROM orders o
  JOIN order_details od ON o.order_code = od.order_code
  JOIN products p ON od.product_no = p.product_no
  LEFT JOIN sizes s ON od.size_no = s.size_no
  LEFT JOIN product_histories ph ON EXISTS (SELECT 0
                                            FROM product_histories
                                            WHERE ph.product_no = product_no AND record_date > o.order_date
                                            HAVING ph.record_date = MIN(record_date)) AND p.product_No = ph.product_no 
  WHERE TRUNC(SYSDATE - 1, 'DD') <= o.order_date AND o.order_date < TRUNC(SYSDATE, 'DD') AND o.cancel_type = 0 AND od.cancel_type = 0 AND o.payment_date IS NOT NULL
  GROUP BY TRUNC(order_date, 'HH24'), TO_CHAR(order_date, 'DY'), TO_NUMBER(TO_CHAR(order_date, 'YYYY')), TO_NUMBER(TO_CHAR(order_date, 'MM')), TO_NUMBER(TO_CHAR(order_date, 'DD')), TO_NUMBER(TO_CHAR(order_date, 'HH24'))
  HAVING SUM(TRUNC((NVL(ph.price, p.price) + NVL(s.price, 0)) * 1.08) * od.quantity) IS NOT NULL;
  ORDER BY TRUNC(order_date, 'HH24')
END;
/
/**
 * その日の顧客の最頻注文商品番号を更新するプロシージャ
 * 0時0分0秒に実行される想定
 * Author:  20jz0105
 * Created: 2021/12/23
 */
DROP PROCEDURE upd_cust_frequently_procedure

CREATE OR REPLACE PROCEDURE upd_cust_frequently_procedure
IS
BEGIN
  UPDATE customers c
  SET c.frequently_product_no = (SELECT p.product_no FROM orders o
                                 JOIN order_details od ON o.order_code = od.order_code
                                 JOIN products p ON p.product_no = od.product_no
                                 WHERE c.customer_no = o.customer_no AND od.cancel_type = 0
                                       AND p.sales_start_date <= SYSDATE AND (SYSDATE <= p.sales_end_date OR p.sales_end_date IS NULL)
                                 GROUP BY p.product_no
                                 ORDER BY COUNT(*) DESC
                                 FETCH FIRST 1 ROW ONLY)
  WHERE EXISTS (SELECT o.customer_no FROM orders o
                WHERE o.order_date BETWEEN TRUNC(SYSDATE - 1, 'DD') AND TRUNC(SYSDATE, 'DD')
                AND c.customer_no = o.customer_no);
END;
/

package editEmployeeBC;

import DAO.DualDAO;
import DAO.EmployeeDAO;
import employeeListBC.ControlEmployeeList;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import model.Employee;

/**
 * 従業員確認・変更コントロール
 * @author 20jz0105
 */
public class ControlEditEmployee extends bcSuper.ControlSuper {
    private BoundaryEditEmployee boundaryEditEmployee;
    private ControlEmployeeList controlEmployeeList;
    private EmployeeDAO employeeDAO;
    private DualDAO dualDAO;
    private Employee employee;
    private Employee loginEmployee;

    public ControlEditEmployee() {
        boundaryEditEmployee = new BoundaryEditEmployee();
        employeeDAO = new EmployeeDAO();
        dualDAO = new DualDAO();
    }

    public void setControlEmployeeList(ControlEmployeeList controlEmployeeList) {
        this.controlEmployeeList = controlEmployeeList;
    }

    public void setLoginEmployee(Employee loginEmployee) {
        this.loginEmployee = loginEmployee;
    }

    public Employee getLoginEmployee() {
        return loginEmployee;
    }
    /**
     * 検索した従業員とログインしている従業員が等しいか判定する.
     * @return 判定結果 等しい -> true / 等しくない -> false
     */
    public boolean isEualsEmployee() {
        return employee.getEmployeeNo().equals(loginEmployee.getEmployeeNo());
    }
    
    
    /**
     * システムメニューに戻るボタンを表示し、従業員一覧画面に戻るボタンを非表示にする.
     */
    public void setReturnButtonVisble() {
        boundaryEditEmployee.setReturnButtonVisble();
    }
    /**
     * システムメニューに戻るボタンを非表示にし、従業員一覧画面に戻るボタンを表示する.
     */
    public void setReturnEmployeeListButtonVisble() {
        boundaryEditEmployee.setReturnOrderListButtonVisble();
        boundaryEditEmployee.setRemoveEnable(!isEualsEmployee());
    }    
    
    
    /**
     * 画面起動メソッド.
     */
    public void start() {
        boundaryEditEmployee.setControlRegisterEmployee(this);
        boundaryEditEmployee.setVisible(true);
    }
    /**
     * システムメニューへの帰還メソッド.
     */
    public void exit() {
        boundaryEditEmployee.setVisible(false);
        boundaryEditEmployee.clear();
        super.getControlSystemMenu().exitContents();
    }
    /**
     * ログイン画面への帰還メソッド.
     */
    public void exitLogout() {
        boundaryEditEmployee.setVisible(false);
        boundaryEditEmployee.clear();
        super.getControlSystemMenu().exit();
    }
    /**
     * 従業員番号をもとに従業員情報を取得する.
     * @param employeeNo 従業員番号
     */
    public void fetchEmployee(String employeeNo) {
        employee = employeeDAO.dbSearchEmployeeNo(employeeNo);
        if (employee != null) {
            boundaryEditEmployee.setEnableAll(false);
            boundaryEditEmployee.setRemoveEnable(false);
            boundaryEditEmployee.showEmployee(employee);            
        }
        else {
            boundaryEditEmployee.showErrorDialog("該当する従業員は存在しません");
            boundaryEditEmployee.focusEmployeeNumber();
        }
    }
    /**
     * 引数の情報を基に従業員情報を変更する.
     * @param name  名前
     * @param sex   性別
     * @param TEL   電話番号
     * @param address   住所
     * @param jobType   役職区分
     */
    public void updataEmployee(String name, int sex, String TEL, String address, boolean jobType) {        
        if (employeeDAO.dbUpdateEmployee(employee.getEmployeeNo(), name, sex, TEL, address, jobType) == 1) {
            employee = employeeDAO.dbSearchEmployeeNo(employee.getEmployeeNo());
            boundaryEditEmployee.showEmployee(employee);
            boundaryEditEmployee.showPlainDialog("変更が完了しました");
        }
        else {
            boundaryEditEmployee.showErrorDialog("変更に失敗しました");
        }
    }
    /**
     * 従業員を除名する.
     */
    public void updateContinue() {
        if (employeeDAO.dbUpdateContinueServiceType(employee.getEmployeeNo(), false) == 1) {
            boundaryEditEmployee.clear();
            employee = null;
            boundaryEditEmployee.showPlainDialog("従業員を除名をしました");
        }
        else {
            boundaryEditEmployee.showErrorDialog("除名に失敗しました");            
        }
    }
    /**
     * 従業員のパスワードを再生成する.
     */
    public void updatePassword() {
        try {
            String password = createPassword(12);//12桁のパスワード生成
            MessageDigest sha3_512 = MessageDigest.getInstance("SHA-512");    
            byte[] result = sha3_512.digest(password.getBytes());
            String hashPass = String.format("%040x", new BigInteger(1, result));
            if (employeeDAO.dbUpdatePassword(employee.getEmployeeNo(), hashPass) == 1) {
                boundaryEditEmployee.showPlainDialog(String.format("パスワード再生成しました%n新規パスワード：%s" , password));
            }
            else {
                boundaryEditEmployee.showErrorDialog("パスワードの生成に失敗しました");
            }            
        }
        catch (NoSuchAlgorithmException e) {
            boundaryEditEmployee.showErrorDialog("パスワードの生成に失敗しました");            
        }
    }
    /**
     * 指定された長さのパスワードを生成する.
     * @param size　長さ
     * @return パスワード
     */
    public String createPassword(int size) {
        final String STR = "01234567890123456789abcdefghijklmnopqrstuvwxyz0123456789";//0とOやIとlなどが紛らわしいのでこっちにしておく
        StringBuilder stringBuilder = new StringBuilder();
        SecureRandom secureRandom = new SecureRandom();
        byte[] randomByte = new byte[size];
        secureRandom.nextBytes(randomByte);
        for (byte b : randomByte) {
            stringBuilder.append(STR.charAt((b & 0x7F) % STR.length()));
        }    
        return stringBuilder.toString();
    }
    /**
     * 従業員リストへの帰還メソッド.
     * @author 20jz0105
     */
    public void exitEmployeeList() {
        boundaryEditEmployee.setVisible(false);
        boundaryEditEmployee.clear();
        controlEmployeeList.exitContents();
    }
    /**
     * 画面を編集可/不可にする
     * @param tf 
     */
    public void setEnableAll(boolean tf) {
        boundaryEditEmployee.setEnableAll(tf);
    }
    
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        new ControlEditEmployee().start();
    }
}

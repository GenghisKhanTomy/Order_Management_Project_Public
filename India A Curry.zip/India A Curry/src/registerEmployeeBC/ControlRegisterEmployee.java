package registerEmployeeBC;

import DAO.DualDAO;
import DAO.EmployeeDAO;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.Date;
import java.time.LocalDate;
import model.Employee;

/**
 * 従業員登録コントロール
 * @author 20jz0105
 */
public class ControlRegisterEmployee extends bcSuper.ControlSuper {
    private BoundaryRegisterEmployee boundaryRegisterEmployee;
    private EmployeeDAO employeeDAO;
    private DualDAO dualDAO;

    public ControlRegisterEmployee() {
        boundaryRegisterEmployee = new BoundaryRegisterEmployee();
        employeeDAO = new EmployeeDAO();
        dualDAO = new DualDAO();
    }
    /**
     * 画面起動メソッド.
     */
    public void start() {
        boundaryRegisterEmployee.setControlRegisterEmployee(this);
        boundaryRegisterEmployee.setVisible(true);
    }
    /**
     * システムメニューへの帰還メソッド.
     */
    public void exit() {
        boundaryRegisterEmployee.setVisible(false);
        boundaryRegisterEmployee.clear();
        super.getControlSystemMenu().exitContents();
    }
    /**
     * ログイン画面への帰還メソッド.
     */
    public void exitLogout() {
        boundaryRegisterEmployee.setVisible(false);
        boundaryRegisterEmployee.clear();
        super.getControlSystemMenu().exit();
    }
    /**
     * 引数の情報を基に従業員を登録する.
     * @param name  名前
     * @param sex   性別
     * @param birthDate 誕生日
     * @param TEL   電話番号
     * @param address   住所
     * @param jobType   役職区分
     */
    public void registerEmployee(String name, int sex, LocalDate birthDate, String TEL, String address, boolean jobType) {

        try {
            String password = createPassword(12);//12桁のパスワード生成
            MessageDigest sha3_512 = MessageDigest.getInstance("SHA-512");    
            byte[] result = sha3_512.digest(password.getBytes());
            String hashPass = String.format("%040x", new BigInteger(1, result));
            
            String employeeNo = dualDAO.dbSearchStrSeqEmployeeNextVal();
            
            Employee employee = new Employee(employeeNo, name, hashPass, sex, Date.valueOf(birthDate), TEL, address, jobType);
            if (employeeDAO.dbInsertEmployee(employee) == 1) {
                boundaryRegisterEmployee.showPlainDialog(String.format("登録が完了しました%n従業員番号：%s%nパスワード：%s", employeeNo, password));
            }
            else {
                boundaryRegisterEmployee.showErrorDialog("登録に失敗しました");
            }
        }
        catch (NoSuchAlgorithmException e) {
            boundaryRegisterEmployee.showErrorDialog("登録に失敗しました");
        }

    }
    /**
     * 指定された長さのパスワードを生成する.
     * @param size　長さ
     * @return パスワード
     */
    public String createPassword(int size) {
//        final String STR = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz0123456789";
        final String STR = "01234567890123456789abcdefghijklmnopqrstuvwxyz0123456789";//0とOやIとlなどが紛らわしいのでこっちにしておく
        StringBuilder stringBuilder = new StringBuilder();
        SecureRandom secureRandom = new SecureRandom();
        byte[] randomByte = new byte[size];
        secureRandom.nextBytes(randomByte);
        for (byte b : randomByte) {
            stringBuilder.append(STR.charAt((b & 0x7F) % STR.length()));
        }    
        return stringBuilder.toString();
    }
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        new ControlRegisterEmployee().start();
    }
}

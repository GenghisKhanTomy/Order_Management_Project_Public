package dateTimeLabel;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.TimerTask;
import java.util.Timer;
import javax.swing.*;


/**
 * DateTimeLabelクラス
 * 1秒ごとにフォーマットを合わせた形式で日付・時刻を表示するラベルクラス
 * @author 20jz0105
 */
public class DateTimeLabel extends JLabel {
    DateTimeFormatter format;
    /**
     * コンストラクタ.
     * @param format    LocalDateTimeの表示フォーマット
     * @param period    再描画周期　ミリ秒単位で指定
     */
    public DateTimeLabel(String format, int period) {
        this.format = DateTimeFormatter.ofPattern(format);
        Timer timer = new Timer();
        timer.schedule(new TimerTaskLabelInner(), 300, period);
//        timer.schedule(new TimerTaskLabel(this), 300, period);
    }
    public DateTimeLabel(String format) {
        this(format, 1000);
    }
    public DateTimeLabel() {
        this("yyyy-MM-dd HH:mm:ss");
    }
    
    public void showDateTime() {
        LocalDateTime now = LocalDateTime.now();
        this.setText(now.format(format));
    }
    /**
     * スケジュールされた間隔でメソッド呼び出しを行う.
     * 　インナークラス
     */
    class TimerTaskLabelInner extends TimerTask {
        @Override
        public void run() {
            showDateTime();
        }
    }
}
/**
 * スケジュールされた間隔でメソッド呼び出しを行うクラス
 * @author 20jz0105
 */
class TimerTaskLabel extends TimerTask {
    private DateTimeLabel dateTimeLabel;
    public TimerTaskLabel(DateTimeLabel dateTimeLabel) {
        this.dateTimeLabel = dateTimeLabel;
    }
    @Override
    public void run() {
        dateTimeLabel.showDateTime();
    }
}
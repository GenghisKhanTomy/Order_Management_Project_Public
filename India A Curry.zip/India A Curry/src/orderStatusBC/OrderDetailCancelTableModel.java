package orderStatusBC;

import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.table.DefaultTableModel;

/**
 * 注文取消用テーブル
 * @author 20jz0105
 */
public class OrderDetailCancelTableModel extends DefaultTableModel {
    private BoundaryCancelOrder boundaryCancelOrder;
    private int checkColumn;
    private int productNoColumn;
    private int categoryColumn;
    private int productNameColumn;
    private int priceColumn;
    private int quantityColumn;
    private int subTotalColumn;
    private int noteColumn;
    private Map<String, Integer> quantityMaxMap;//key 商品番号+サイズ番号, value 個数最大値
    private Map<String, Integer> updateMap;//key 商品番号+サイズ番号, value 個数
    
    public OrderDetailCancelTableModel(Object[] os, int i) {
        super(os, i);
        quantityMaxMap = new HashMap<>();
        updateMap = new HashMap<>();
        for (int column = 0; column < getColumnCount(); column++) {
            if ("".equals(getColumnName(column))) {
                setCheckColumn(column);
            }
            else if ("商品番号".equals(getColumnName(column))) {
                setProductNoColumn(column);
            }
            else if ("カテゴリ".equals(getColumnName(column))) {
                setCategoryColumn(column);
            }
            else if ("商品名".equals(getColumnName(column))) {
                setProductNameColumn(column);
            }
            else if ("単価".equals(getColumnName(column))) {
                setPriceColumn(column);
            }
            else if ("個数".equals(getColumnName(column))) {
                setQuantityColumn(column);
            }
            else if ("金額".equals(getColumnName(column))) {
                setSubTotalColumn(column);
            }
            else if ("備考ノート".equals(getColumnName(column))) {
                setNoteColumn(column);
            }        
        }
    }

    public int getCheckColumn() {
        return checkColumn;
    }

    public int getProductNoColumn() {
        return productNoColumn;
    }

    public int getCategoryColumn() {
        return categoryColumn;
    }

    public int getProductNameColumn() {
        return productNameColumn;
    }

    public int getPriceColumn() {
        return priceColumn;
    }

    public int getQuantityColumn() {
        return quantityColumn;
    }

    public int getSubTotalColumn() {
        return subTotalColumn;
    }

    public int getNoteColumn() {
        return noteColumn;
    }

    public Map<String, Integer> getQuantityMaxMap() {
        return quantityMaxMap;
    }

    public int getQuantityMax(int row) {
        return getQuantityMaxMap().getOrDefault(getValueAt(row, getProductNoColumn()).toString(), -1);
    }

    public Map<String, Integer> getUpdateMap() {
        return updateMap;
    }    
    
    public void setBoundaryCancelOrder(BoundaryCancelOrder boundaryCancelOrder) {
        this.boundaryCancelOrder = boundaryCancelOrder;
    }

    public void setCheckColumn(int checkColumn) {
        this.checkColumn = checkColumn;
    }

    public void setProductNoColumn(int productNoColumn) {
        this.productNoColumn = productNoColumn;
    }

    public void setCategoryColumn(int categoryColumn) {
        this.categoryColumn = categoryColumn;
    }

    public void setProductNameColumn(int productNameColumn) {
        this.productNameColumn = productNameColumn;
    }

    public void setPriceColumn(int priceColumn) {
        this.priceColumn = priceColumn;
    }

    public void setQuantityColumn(int quantityColumn) {
        this.quantityColumn = quantityColumn;
    }

    public void setSubTotalColumn(int subTotalColumn) {
        this.subTotalColumn = subTotalColumn;
    }

    public void setNoteColumn(int noteColumn) {
        this.noteColumn = noteColumn;
    }
    
    @Override
    public Class<?> getColumnClass(int column) {
         return column == getCheckColumn() ? Boolean.class : super.getColumnClass(column);
    }
    
    @Override
    public boolean isCellEditable(int row, int column) {
        return column == getQuantityColumn() || column == getCheckColumn();
    }

    public void addMaxMap(String key, int maxValue) {
        quantityMaxMap.put(key, maxValue);
    }
    
    public void putUpdateMap(String key, int value) {
        updateMap.put(key, value);
    }
    
    @Override
    public void addRow(Object[] rowData) {
        this.addRow(convertToVector(rowData));
    }
    
    @Override
    public void addRow(Vector rowData) {
        super.addRow(rowData);
        addMaxMap(rowData.get(getProductNoColumn()).toString(), (int)rowData.get(getQuantityColumn()));
        putUpdateMap(rowData.get(getProductNoColumn()).toString(), (int)rowData.get(getQuantityColumn()));
    }
    
    @Override
    public void removeRow(int row) {
        putUpdateMap(getValueAt(row, getProductNoColumn()).toString(), 0);
        super.removeRow(row);
    }
    
    @Override
    public void setValueAt(Object aValue, int row, int column) {
        if (column == getQuantityColumn()) {
            Pattern p = Pattern.compile("^[1-9]\\d*$");
            Matcher m = p.matcher(aValue.toString());
            if (m.matches()) {
                int val = Integer.parseInt(aValue.toString());
                if (val > getQuantityMax(row)) {
                    val = getQuantityMax(row);
                }
                if (val > 0) {
                    super.setValueAt(val, row, column);
                    super.setValueAt(val * (int)getValueAt(row, getPriceColumn()), row, getSubTotalColumn());
                    boundaryCancelOrder.calculateTotalAmount();
                    putUpdateMap(getValueAt(row, getProductNoColumn()).toString(), val);
                }
            }
        }
        else {
            super.setValueAt(aValue, row, column);
        }
    }
    
}

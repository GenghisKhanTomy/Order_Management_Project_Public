package orderStatusBC;

import DAO.OrderDetailDAO;
import DAO.OrderJoinViewDAO;
import DAO.OrderStatusDAO;
import DAO.OrderVoucherViewDAO;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import model.OrderJoinView;
import model.OrderVoucherDetail;
import model.OrderVoucherView;
import constant.OrderStatusList;
import model.Employee;
import orderListBC.ControlOrderList;
import paymentBC.ControlPayment;

/**
 * 注文状態確認コントロール
 * @author 20jz0105
 */
public class ControlOrderStatus extends bcSuper.ControlSuper{
    private BoundaryOrderStatus boundaryOrderStatus;
    private BoundaryEditOrderStatus boundaryEditOrderStatus;
    private BoundaryCancelOrder boundaryCancelOrder;
    private ControlOrderList controlOrderList;
    private ControlPayment controlPayment;
    private OrderJoinView orderJoinView;
    private OrderVoucherView orderVoucherView;
    private OrderJoinViewDAO orderJoinViewDAO;
    private OrderVoucherViewDAO orderVoucherViewDAO;
    private OrderStatusDAO orderStatusDAO;
    private OrderDetailDAO orderDetailDAO;
    private Map<String, Integer> orderDetailCodeMap;
    private Employee employee;
    
    public ControlOrderStatus() {
        boundaryOrderStatus = new BoundaryOrderStatus();
        orderJoinViewDAO = new OrderJoinViewDAO();
        orderVoucherViewDAO = new OrderVoucherViewDAO();
        orderStatusDAO = new OrderStatusDAO();
        orderDetailDAO = new OrderDetailDAO();
        orderDetailCodeMap = new HashMap<>();
        
        employee = new Employee();
        
    }

    public OrderJoinView getOrderJoinView() {
        return orderJoinView;
    }

    public void setControlOrderList(ControlOrderList controlOrderList) {
        this.controlOrderList = controlOrderList;
    }

    public void setControlPayment(ControlPayment controlPayment) {
        this.controlPayment = controlPayment;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }
    
    /**
     * システムメニューに戻るボタンを表示し、注文一覧画面に戻るボタンを非表示にする.
     */
    public void setReturnButtonVisble() {
        boundaryOrderStatus.setReturnButtonVisble();
    }
    /**
     * システムメニューに戻るボタンを非表示にし、注文一覧画面に戻るボタンを表示する.
     */
    public void setReturnOrderListButtonVisble() {
        boundaryOrderStatus.setReturnOrderListButtonVisble();
    }    
    
    /**
     * 画面起動メソッド.
     */   
    public void start() {
        boundaryOrderStatus.setControlOrderStatus(this);
        boundaryOrderStatus.setVisblePayment(employee.isJobType());
        boundaryOrderStatus.setVisible(true);
    }
    
    /**
     * システムメニューへの帰還メソッド.
     * @author 20jz0132
     */
    public void exit() {
        boundaryOrderStatus.setVisible(false);
        boundaryOrderStatus.clear();
        super.getControlSystemMenu().exitContents();
    }
    /**
     * 注文リストへの帰還メソッド.
     * @author 20jz0132
     */
    public void exitOrderList() {
        boundaryOrderStatus.setVisible(false);
        boundaryOrderStatus.clear();
        controlOrderList.exitContents();
    }
    /**
     * ログイン画面への帰還メソッド.
     */
    public void exitLogout() {
        boundaryOrderStatus.setVisible(false);
        boundaryOrderStatus.clear();
        super.getControlSystemMenu().exit();
    }
    /**
     * 注文伝票及び注文状態の取得.
     * @param orderCode 
     */
    public void fetchOrderStatus(int orderCode) {
        OrderJoinView tmpOrderJoinView = orderJoinViewDAO.dbSearchOrderJoinViewCode(orderCode);
        OrderVoucherView tmpOrderVoucherView = orderVoucherViewDAO.dbSearchOrderCode(orderCode);
        if (tmpOrderJoinView != null && tmpOrderVoucherView != null) {
            orderJoinView = tmpOrderJoinView;
            orderVoucherView = tmpOrderVoucherView;
            boundaryOrderStatus.showOrderJoinView(orderJoinView);
            boundaryOrderStatus.showOrderVoucherView(orderVoucherView);            
        }
        else {
            boundaryOrderStatus.showErrorDialog("注文[" + orderCode + "] は存在しません。もう一度ご確認ください。");
            boundaryOrderStatus.focusOrderNumber();
        }
    }
    /**
     * 注文状態変更ダイアログを表示し、受け取った結果によって注文状態を更新する.
     */
    public void storeOrderStatus() {
        if (boundaryEditOrderStatus == null) {
            boundaryEditOrderStatus = new BoundaryEditOrderStatus(boundaryOrderStatus, true);
            boundaryEditOrderStatus.setControlOrderStatus(this);
        }
        boundaryEditOrderStatus.initSpinner();
        boundaryEditOrderStatus.setRadio();
        boundaryEditOrderStatus.setSpinnerMin();
        boundaryEditOrderStatus.setState(false);
        boundaryEditOrderStatus.setVisible(true);
        if (boundaryEditOrderStatus.isState()) {
            switch (boundaryEditOrderStatus.getSelectedStatus()) {
                case OrderStatusList.COOKING_START:
                    orderStatusDAO.dbUpdateCookingStartTimestamp(orderJoinView.getOrderCode(), boundaryEditOrderStatus.getSpinnerTimestamp());
                    break;
                case OrderStatusList.COOKING_END:
                    orderStatusDAO.dbUpdateCookingEndTimestamp(orderJoinView.getOrderCode(), boundaryEditOrderStatus.getSpinnerTimestamp());
                    break;
                case OrderStatusList.DELIVERY_START:
                    orderStatusDAO.dbUpdateDeliveryStartTimestamp(orderJoinView.getOrderCode(), boundaryEditOrderStatus.getSpinnerTimestamp());
                    break;
                case OrderStatusList.DELIVERY_END:
                    orderStatusDAO.dbUpdateDeliveryEndTimestamp(orderJoinView.getOrderCode(), boundaryEditOrderStatus.getSpinnerTimestamp());
                    break;
            }
            orderJoinView = orderJoinViewDAO.dbSearchOrderJoinViewCode(orderJoinView.getOrderCode());
            boundaryOrderStatus.showOrderJoinView(orderJoinView);           
        }
    }
    /**
     * 注文リストから指定された行を削除.
     * 　複数削除可能
     * @param deleteRowList 削除する行番号が格納された配列
     */
    public void removeProductOrder(List<Integer> deleteRowList) {
        int size = deleteRowList.size();
        for (int i = size - 1; i >= 0; i--) {
            boundaryCancelOrder.removeProductOrder(deleteRowList.get(i));            
        }
        boundaryCancelOrder.reorganizationTaxMap();
        boundaryCancelOrder.calculateTotalAmount();
        
    }
    /**
     * 注文取消画面を表示し、注文を取消す.
     * 　取消後、注文伝票を再度表示する
     */
    public void cancelOrder() {
        if (boundaryCancelOrder == null) {
            boundaryCancelOrder = new BoundaryCancelOrder(boundaryOrderStatus, true);
            boundaryCancelOrder.setControlOrderStatus(this);
        }
        boundaryCancelOrder.setReward(orderVoucherView.getUsageReward());
        appendCancelTableOrderVoucher();
        boundaryCancelOrder.setOrderStatus();
        boundaryCancelOrder.calculateTotalAmount();
        boundaryCancelOrder.setState(false);
        boundaryCancelOrder.setVisible(true);
        if (boundaryCancelOrder.isState()) {
            /**
             * DB更新処理
             */
            int orderCode = orderVoucherView.getOrderCode();
            int orderDetailCode;
            OrderDetailCancelTableModel orderDetailCancelTableModel = boundaryCancelOrder.getOrderDetailCancelTableModel();
            for (Map.Entry<String, Integer> entry : orderDetailCancelTableModel.getUpdateMap().entrySet()) {
                orderDetailCode = orderDetailCodeMap.get(entry.getKey());
                if (0 == entry.getValue()) {
                    orderDetailDAO.dbUpdateCancelType(orderCode, orderDetailCode, true);                
                }
                else {
                    orderDetailDAO.dbUpdateQuantity(orderCode, orderDetailCode, entry.getValue());
                }
            }
            
            orderVoucherView = orderVoucherViewDAO.dbSearchOrderCode(orderCode);
            if (orderVoucherView != null) {
                boundaryOrderStatus.showOrderVoucherView(orderVoucherView);
            }
            else {
                boundaryOrderStatus.initOrderStatus();
                boundaryOrderStatus.initTexeArea();
                orderJoinView = null;
            }
        }        
    }
    
    /**
     * 注文伝票を注文取消テーブルに表示する.
     */
    public void appendCancelTableOrderVoucher() {
        boundaryCancelOrder.clearProductOrder();
        for (Map.Entry<String, List<OrderVoucherDetail>> entry : orderVoucherView.getOrderVoucherDetailMap().entrySet()) {
            for (OrderVoucherDetail orderVoucherDetail : entry.getValue()) {
                Object rowData[] = {false, orderVoucherDetail.getProductNo(), entry.getKey(), orderVoucherDetail.getProductName(), orderVoucherDetail.getTaxPrice(),
                                    orderVoucherDetail.getQuantity(), orderVoucherDetail.getTaxSubTotal(), orderVoucherDetail.getNote()};
                boundaryCancelOrder.appendProductOrder(rowData, orderVoucherDetail.getTax());
                orderDetailCodeMap.put(orderVoucherDetail.getProductNo(), orderVoucherDetail.getOrderDetailCode());
            }
        }
    }
    
    /**
     * 注文リストの個数の更新及び、それに伴う金額の更新を行う.
     * @param row               行番号
     * @param quantityColumn    個数列の列番号
     * @param quantity          個数
     */
    public void updateProductQuantityOrder(int row, int quantityColumn, int quantity) {
        boundaryCancelOrder.updateProductOrder(quantity, row, quantityColumn);
        boundaryCancelOrder.calculateTotalAmount();
    }
    
    /**
     * 入金画面の起動メソッド.
     */
    public void awakenPayment() {
        if (orderVoucherView.isCustomerType()) {
            controlPayment.fetchOrder(orderVoucherView.getOrderCode());
        }
        else {
            controlPayment.fetchInvoice(orderVoucherView.getCustomerTEL());
        }
        controlPayment.setRadioSelected(orderVoucherView.isCustomerType());
        boundaryOrderStatus.setVisible(false);
        controlPayment.setReturnOrderStatusButtonVisble();
        controlPayment.start();
    }    
    /**
     * 入金画面からの帰還メソッド.
     */
    public void exitContents() {
        fetchOrderStatus(orderJoinView.getOrderCode());
        boundaryOrderStatus.setVisible(true);
    }
    
    /**
     * テスト用メイン.
     * @param args 
     */
    public static void main(String[] args) {
        new ControlOrderStatus().start();
    }
}

package registerSpecialProductBC;

import DAO.ProductDAO;
import DAO.SpecialProductDAO;
import java.sql.Date;
import java.util.List;
import java.util.ArrayList;
import model.Product;
import model.SpecialProduct;

/**
 *
 * @author とよA
 */
public class ControlRegisterSpecialProduct extends bcSuper.ControlSuper {
    private BoundaryRegisterSpecialProduct boundaryRegisterSpecialProduct;
    private ProductDAO productDAO;
    private SpecialProductDAO specialProductDAO;
    private List<Product> productsList;

    public ControlRegisterSpecialProduct() {
        boundaryRegisterSpecialProduct = new BoundaryRegisterSpecialProduct();
        productDAO = new ProductDAO();
        specialProductDAO = new SpecialProductDAO();
        productsList = new ArrayList<>();
    }
    
    /**
     * 画面起動メソッド.
     */
    public void start() {
        boundaryRegisterSpecialProduct.setControl(this);
        boundaryRegisterSpecialProduct.setVisible(true);
        addToAllProductToComboBox();
    }
    
    /**
     * システムメニューへの帰還メソッド.
     */
    public void exit() {
        boundaryRegisterSpecialProduct.setVisible(false);
        boundaryRegisterSpecialProduct.clear();
        super.getControlSystemMenu().exitContents();
    }
    /**
     * ログイン画面への帰還メソッド.
     */
    public void exitLogout() {
        boundaryRegisterSpecialProduct.setVisible(false);
        boundaryRegisterSpecialProduct.clear();
        super.getControlSystemMenu().exit();
    }
    /**
     * 商品を部分検索し、結果を格納
     * @param searchWord 
     */
    void fetchProduct(String searchWord) {
        boundaryRegisterSpecialProduct.initComboBox();
        productsList.clear();
        
        productsList = productDAO.dbSearchSaleNoNameLike(searchWord);
        if (productsList.size() > 0) {
            for (Product product : productsList) {
                boundaryRegisterSpecialProduct.appendProductToCombBox(product);
            }
        }
        else {
            boundaryRegisterSpecialProduct.showErrorDialog("[" + searchWord + "] は存在しません。もう一度ご確認ください。");
        }
    }
    
    /**
     * 特別商品情報を登録.
     * @param productMagnification ポイント倍率
     * @param startYmd 開始日
     * @param endYmd 終了日
     * @param productNo 対象商品番号
     */
    void registerSpecialProduct(int productMagnification, String startYmd, String endYmd, Product product) {
        SpecialProduct specialProduct = new SpecialProduct(product, productMagnification, Date.valueOf(startYmd), Date.valueOf(endYmd));
        try {
            if (specialProductDAO.dbInsertSpecialProduct(specialProduct) != 1) {
                throw new Exception();
            }
            boundaryRegisterSpecialProduct.showPlainDialog("特別商品を登録しました");
            boundaryRegisterSpecialProduct.clear();
        }
        catch (Exception e) {
            boundaryRegisterSpecialProduct.showErrorDialog("注文の登録に失敗しました");
        }
    }
    

    boolean prepareSpecialProduct(Product product) {
        return specialProductDAO.dbUpdateSpecialEndDateUsingProductNo(product.getProductNo()) >= 0;
    }

    public void addToAllProductToComboBox() {
        productsList = productDAO.dbSearchSaleAllProduct();
        boundaryRegisterSpecialProduct.addedProduct(productsList);
    }
    
    public static void main(String[] args) {
        new ControlRegisterSpecialProduct().start();
    }
}

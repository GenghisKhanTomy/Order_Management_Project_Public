package loginBC;

import DAO.EmployeeDAO;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import model.Employee;
import systemMenuBC.ControlSystemMenu;


/**
 * ログインコントロール
 * @author 20jz0105
 */
public class ControlLogin {
    private BoundaryLogin boundaryLogin;
    private ControlSystemMenu controlSystemMenu;
    private EmployeeDAO employeeDAO;
    private Employee employee;

    
    public ControlLogin() {
        boundaryLogin = new BoundaryLogin();
        controlSystemMenu = new ControlSystemMenu();
        employeeDAO = new EmployeeDAO();
    }
    /**
     * 画面起動メソッド.
     */
    public void start() {
        boundaryLogin.setControlLogin(this);
        boundaryLogin.setVisible(true);
    }
    /**
     * システム終了メソッド.
     */
    public void exit() {
        System.exit(0);
    }
    /**
     * ログインID、パスワードを比較してログイン判定を行う.
     * @param loginId   ログインID
     * @param password  パスワード
     * @author 20jz0105
     */
    public void checkLogin(String loginId, String password) {
        if (checkLoginIdPassword(loginId, password)) {
            controlSystemMenu.setEmployee(employee);
            boundaryLogin.init();
            awakenSystemMenu();
        }
        else {
            boundaryLogin.showErrorDialog("従業員IDまたはパスワードが違います");
            boundaryLogin.clearPassword();
            boundaryLogin.focusOrderNumber();
        }
    }
    
   
    /**
     * データベース代わりにArrayListに登録したログイン情報に一致するか調べる.
     * @param loginId   ログインID
     * @param password  パスワード
     * @return          ログイン成否
     */
    public boolean checkLoginIdPassword(String loginId, String password) {
        boolean loginFlag = false;
        try {
            MessageDigest sha3_512 = MessageDigest.getInstance("SHA-512");    
            byte[] result = sha3_512.digest(password.getBytes());
            String hashPass = String.format("%040x", new BigInteger(1, result));
                        
            employee = employeeDAO.dbSearchEmployeeNoPass(loginId, hashPass);
            if (employee != null) {
                loginFlag = true;
            }
        }
        catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return loginFlag;
    }
    
    /**
     * システムメニュー起動メソッド.
     */
    void awakenSystemMenu() {
        boundaryLogin.setVisible(false);
        controlSystemMenu.setControlLogin(this);
        controlSystemMenu.start();
    }
    
    /**
     * システムメニュー用のexitメソッド.
     */   
    public void exitContents() {
        boundaryLogin.setVisible(true);
    }
    
    
    
    public static void main(String[] args) {
        new ControlLogin().start();
    }
}

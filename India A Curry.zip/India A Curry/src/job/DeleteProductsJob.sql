/**
 * 販売終了年月日を過ぎた商品を自動的に削除するジョブ
 * Author:  20jz0105
 * Created: 2021/12/26
 */
-- BEGIN
--   DBMS_SCHEDULER.DROP_JOB('delete_products_job');
-- END;
-- /
-- 
-- BEGIN
-- DBMS_SCHEDULER.CREATE_JOB
-- (
--   job_name           =>  'delete_products_job',
--   job_type           =>  'STORED_PROCEDURE',
--   job_action         =>  'delete_products_procedure',
--   start_date         =>  TO_DATE('2021/12/23 12:00:00','yyyy/mm/dd hh24:mi:ss'),
--   repeat_interval    =>  'FREQ=HOURLY',
--   enabled            =>  TRUE
-- );
-- END;
-- /


/**
 * 顧客テーブルの最頻注文商品番号を更新するプロシージャを定期実行するjob
 * Author:  20jz0105
 * Created: 2021/12/23
 */
BEGIN
  DBMS_SCHEDULER.DROP_JOB('update_customers_job');
END;
/

BEGIN
DBMS_SCHEDULER.CREATE_JOB
(
  job_name           =>  'update_customers_job',
  job_type           =>  'STORED_PROCEDURE',
  job_action         =>  'upd_cust_frequently_procedure',
  start_date         =>  TO_DATE('2021/12/23 00:00:00','yyyy/mm/dd hh24:mi:ss'),
  repeat_interval    =>  'FREQ=HOURLY',
  enabled            =>  TRUE
);
END;
/

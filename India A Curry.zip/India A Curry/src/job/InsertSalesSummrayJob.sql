/**
 * 1時間ごとにその1時間における注文金額の合計を集計して売上サマリーに挿入するジョブ
 * Author:  20jz0105
 * Created: 2021/12/23
 */
BEGIN
  DBMS_SCHEDULER.DROP_JOB('insert_sales_summary_job');
END;
/

BEGIN
DBMS_SCHEDULER.CREATE_JOB
(
  job_name           =>  'insert_sales_summary_job',
  job_type           =>  'STORED_PROCEDURE',
  job_action         =>  'sum_sales_procedure',
  start_date         =>  TO_DATE('2021/12/23 00:00:00','yyyy/mm/dd hh24:mi:ss'),
  repeat_interval    =>  'FREQ=DAILY',
  enabled            =>  TRUE
);
END;
/


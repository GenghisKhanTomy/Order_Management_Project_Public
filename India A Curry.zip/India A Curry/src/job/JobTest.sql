/**
 * Author:  20jz0105
 * Created: 2021/12/23
 */
CREATE TABLE test05(id NUMBER, note VARCHAR2(100));

DROP PROCEDURE PROC_A

CREATE OR REPLACE PROCEDURE PROC_A
IS
BEGIN
 INSERT INTO test05
 SELECT COUNT(*) + 1 , 'aa' FROM test05;
END;
/



BEGIN
 DBMS_SCHEDULER.DROP_JOB('JOB_PROC_A');
END;
/

BEGIN

DBMS_SCHEDULER.CREATE_JOB
(
  job_name           =>  'JOB_PROC_A',
  job_type           =>  'STORED_PROCEDURE',
  job_action         =>  'PROC_A',
  start_date         =>  TO_DATE('2018/08/01 00:00:00','yyyy/mm/dd hh24:mi:ss'),
  repeat_interval    =>  'FREQ=SECONDLY;INTERVAL=10',
  enabled            =>  TRUE
);

END;
/

